/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Publicacao;
import java.util.List;

/**
 *
 * @author user
 */
public interface PublicacaoDAO {
    
    
    public void add(Publicacao publicaco) throws DaoException;
    
    public void removeAll(String ISBN) throws DaoException;
    
    public void update(Publicacao publicacao) throws DaoException;
    
    public List<Publicacao> findAll() throws DaoException;
}
