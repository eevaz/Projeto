/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Revista;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public interface RevistaDAO {

    public void add(Revista revista) throws DaoException;

    public void removeAll(String ISBN) throws DaoException;

    public void update(Revista revista) throws DaoException;

    public List<Revista> findAll() throws DaoException;

    public List<Revista> findByISBN(String isbn) throws DaoException;

    public List<Revista> findByTitulo(String titulo) throws DaoException;

    public List<Revista> findByEditora(String editora) throws DaoException;

}
