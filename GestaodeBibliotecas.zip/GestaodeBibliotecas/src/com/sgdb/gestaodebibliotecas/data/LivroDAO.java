/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Livro;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public interface LivroDAO {
    
     public void add(Livro livro) throws DaoException;
    
    public void removeAll(String ISBN) throws DaoException;
    
    public void update(Livro livro) throws DaoException;
    
    public List<Livro> findAll() throws DaoException;
    
    public List<Livro> findByISBN(String isbn) throws DaoException;

    public List<Livro> findByTitulo(String titulo) throws DaoException;

    public List<Livro> findByAutor(String autor) throws DaoException;

}
    

