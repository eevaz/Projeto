/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Emprestimo;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author user
 */
public class EmprestimoDAOJdbc implements EmprestimoDAO {

    @Override
    public void add(Emprestimo emprestimo) throws DaoException {
        String sql = """
                     insert into Emprestimo(ID, UsuarioID,PublicacaoISBN,DataEmprestimo,DataDevolucao)
                 values(?, ?, ?, ?, ?);
                     insert into Notificacao(UsuarioID,PublicacaoISBN,DataNotificacao,FuncionarioID,TipoNotificacao)
                 values(?, ?, ?,222,'Devolva a Publicacao daqui a 7 dias')
                     """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);) {
            pstmt.setInt(1, emprestimo.getID());
            pstmt.setInt(2, emprestimo.getUsuarioID());
            pstmt.setString(3, emprestimo.getPublicacaoISBN());
            pstmt.setObject(4, emprestimo.getDataEmprestimo());
            pstmt.setObject(5, emprestimo.getDataDevolucao());
         
            pstmt.setInt(6, emprestimo.getUsuarioID());
            pstmt.setString(7, emprestimo.getPublicacaoISBN());
            pstmt.setObject(8, emprestimo.getDataEmprestimo());
            pstmt.executeUpdate();
//            ResultSet rs = pstmt.getGeneratedKeys();
//            if (rs.next()) {
//                int idd = rs.getInt(1);
//                emprestimo.setID(idd);
//            }
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------
    @Override
    public void remove(int id) throws DaoException {
        String sql = "delete from Emprestimo "
                + "where ID = ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------
    @Override
    public void update(Emprestimo emprestimo) throws DaoException {
       String sql = """
                    update Emprestimo set UsuarioID = ?, PublicacaoISBN = ?, DataDevolucao = ? 
                where ID = ?
                    
                    """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, emprestimo.getUsuarioID());
            pstmt.setString(2, emprestimo.getPublicacaoISBN());
            pstmt.setObject(3, emprestimo.getDataDevolucao());
            pstmt.setInt(4, emprestimo.getID());
           
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public Optional<Emprestimo> findById(int id) throws DaoException {
        String sql = "select * from Emprestimo "
                + "where ID = ?";
        Optional<Emprestimo> optionalEmprestimo = Optional.empty();
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery();) {
                if (rs.next()) {
                    Emprestimo emprestimo = new Emprestimo();
                    emprestimo.setID(rs.getInt("ID"));
                    emprestimo.setUsuarioID(rs.getInt("UsuarioID"));
                    emprestimo.setPublicacaoISBN(rs.getString("PublicacaoISBN"));
                    emprestimo.setDataEmprestimo(rs.getDate("DataEmprestimo").toLocalDate());
                    emprestimo.setDataDevolucao(rs.getDate("DataDevolucao").toLocalDate());
                    optionalEmprestimo = Optional.of(emprestimo);
                }
                return optionalEmprestimo;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------
    @Override
    public List<Emprestimo> findAll() throws DaoException {
        String sql = "select * from Emprestimo";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Emprestimo> listaEmprestimo = new ArrayList<>();
                while (rs.next()) {
                    Emprestimo emprestimo = new Emprestimo();
                    emprestimo.setID(rs.getInt("ID"));
                    emprestimo.setUsuarioID(rs.getInt("UsuarioID"));
                    emprestimo.setPublicacaoISBN(rs.getString("PublicacaoISBN"));
                    emprestimo.setDataEmprestimo(rs.getDate("DataEmprestimo").toLocalDate());
                    emprestimo.setDataDevolucao(rs.getDate("DataDevolucao").toLocalDate());
                    listaEmprestimo.add(emprestimo);
                }
                return listaEmprestimo;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------
    @Override
    public Optional<Emprestimo> findByDataEmprestimo(LocalDate dataemprestimo) throws DaoException {
          String sql = "select * from Emprestimo "
                + "where DataEmprestimo = ?";
        Optional<Emprestimo> optionalEmprestimo = Optional.empty();
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setObject(1, dataemprestimo);
            try (ResultSet rs = pstmt.executeQuery();) {
                if (rs.next()) {
                    Emprestimo emprestimo = new Emprestimo();
                    emprestimo.setID(rs.getInt("ID"));
                    emprestimo.setUsuarioID(rs.getInt("UsuarioID"));
                    emprestimo.setPublicacaoISBN(rs.getString("PublicacaoISBN"));
                    emprestimo.setDataEmprestimo(rs.getDate("DataEmprestimo").toLocalDate());
                    emprestimo.setDataDevolucao(rs.getDate("DataDevolucao").toLocalDate());
                    optionalEmprestimo = Optional.of(emprestimo);
                }
                return optionalEmprestimo;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
    //---------------------------------------------------------------------------------
}
