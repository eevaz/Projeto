/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Funcionario;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public interface FuncionarioDAO {
    
    public void add(Funcionario funcionario) throws DaoException;

    public void remove(int id) throws DaoException;

    public void update(Funcionario funcionario) throws DaoException;
    
    public Optional<Funcionario>  findById(int id) throws DaoException;

    public List<Funcionario>  findByCargo(String cargo) throws DaoException;
    
    public List<Funcionario> findByNome(String nome) throws DaoException;

    public List<Funcionario> findAll() throws DaoException;        

}
    

