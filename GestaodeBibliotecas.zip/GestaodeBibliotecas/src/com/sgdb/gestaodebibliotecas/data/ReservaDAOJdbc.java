/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Reserva;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author user
 */
public class ReservaDAOJdbc implements ReservaDAO {

    @Override
    public void add(Reserva reserva) throws DaoException {
        String sql = """
                     insert into Reserva(ID, UsuarioID,PublicacaoISBN,DataReserva)
                values(?, ?, ?, ?);
                      insert into Notificacao(UsuarioID,PublicacaoISBN,DataNotificacao,FuncionarioID,TipoNotificacao)
                                      values(?, ?, ?, 444,'Sua reserva foi efetuado com sucesso')
                     """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);) {
            pstmt.setInt(1, reserva.getID());
            pstmt.setInt(2, reserva.getUsuarioID());
            pstmt.setString(3, reserva.getPublicacaoISBN());
            pstmt.setObject(4, reserva.getDataReserva());
            
            pstmt.setInt(5, reserva.getUsuarioID());
            pstmt.setString(6, reserva.getPublicacaoISBN());
            pstmt.setObject(7, reserva.getDataReserva());
            pstmt.executeUpdate();
//            ResultSet rs = pstmt.getGeneratedKeys();
//            if (rs.next()) {
//                int idd = rs.getInt(1);
//                reserva.setID(idd);
//            }
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public void remove(int id) throws DaoException {
        String sql = """
                     delete from Reserva 
                where ID = ?
                delete from Notificacao 
                     where ID = ?
                """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public void update(Reserva reserva) throws DaoException {
        String sql = """
               update Reserva set UsuarioID = ?, PublicacaoISBN = ? 
                where ID = ?
                     update Notificacao set UsuarioID = ?, PublicacaoISBN = ?
                     where ID = ?
                  """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, reserva.getUsuarioID());
            pstmt.setString(2, reserva.getPublicacaoISBN());
            pstmt.setInt(3, reserva.getID());
            pstmt.setInt(4, reserva.getUsuarioID());
            pstmt.setString(5, reserva.getPublicacaoISBN());
            pstmt.setInt(6, reserva.getID());
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public Optional<Reserva> findById(int id) throws DaoException {
       String sql = "select * from Reserva "
                + "where ID = ?";
        Optional<Reserva> optionalReserva = Optional.empty();
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery();) {
                if (rs.next()) {
                    Reserva reserva = new Reserva();
                    reserva.setID(rs.getInt("ID"));
                    reserva.setUsuarioID(rs.getInt("UsuarioID"));
                    reserva.setPublicacaoISBN(rs.getString("PublicacaoISBN"));
                    reserva.setDataReserva(rs.getDate("DataReserva").toLocalDate());
                    optionalReserva = Optional.of(reserva);
                }
                return optionalReserva;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public List<Reserva> findAll() throws DaoException {
       String sql = "select * from Reserva";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Reserva> listaReserva = new ArrayList<>();
                while (rs.next()) {
                    Reserva reserva = new Reserva();
                    reserva.setID(rs.getInt("ID"));
                    reserva.setUsuarioID(rs.getInt("UsuarioID"));
                    reserva.setPublicacaoISBN(rs.getString("PublicacaoISBN"));
                    reserva.setDataReserva(rs.getDate("DataReserva").toLocalDate());
                    listaReserva.add(reserva);
                }
                return listaReserva;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

}
