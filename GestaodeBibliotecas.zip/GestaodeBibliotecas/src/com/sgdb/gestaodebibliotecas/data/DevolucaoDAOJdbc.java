/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Devolucao;
import java.util.List;
import java.util.Optional;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;
import java.sql.ResultSet;
import java.util.ArrayList;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;

/**
 *
 * @author user
 */
public class DevolucaoDAOJdbc implements DevolucaoDAO{

    @Override
    public void add(Devolucao devolucao) throws DaoException {
        String sql = """
                     insert into Devolucao(EmprestimoID,DataDevolucao)
                values(?, ?)
                     """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);) {
            pstmt.setInt(1, devolucao.getEmprestimoID());
            pstmt.setObject(2, devolucao.getDataDevolucao());
            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                devolucao.setID(id);
            }

            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public void remove(int id) throws DaoException {
         String sql = """
                     delete from Devolucao 
                 where ID = ?
                     """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public void update(Devolucao devolucao) throws DaoException {
         String sql = """
                      update Devolucao set DataDevolucao = ?
                where ID= ?
                           """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setObject(1, devolucao.getDataDevolucao());
            pstmt.setInt(2, devolucao.getID());
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public Optional<Devolucao> findById(int id) throws DaoException {
        String sql = "select * from Devolucao "
                + "where ID = ?";
        Optional<Devolucao> optionalDevolucao = Optional.empty();
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery();) {
                if (rs.next()) {
                    Devolucao devolucao = new Devolucao();
                     devolucao.setID(rs.getInt("ID"));
                    devolucao.setEmprestimoID(rs.getInt("EmprestimoID"));
                    devolucao.setDataDevolucao(rs.getDate("DataDevolucao").toLocalDate());
                    optionalDevolucao = Optional.of(devolucao);
                }
                return optionalDevolucao;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public List<Devolucao> findAll() throws DaoException {
        String sql = "select * from Devolucao";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Devolucao> listaDevolucao = new ArrayList<>();
                while (rs.next()) {
                    Devolucao devolucao = new Devolucao();
                    devolucao.setID(rs.getInt("ID"));
                    devolucao.setEmprestimoID(rs.getInt("EmprestimoID"));
                    devolucao.setDataDevolucao(rs.getDate("DataDevolucao").toLocalDate());
                    listaDevolucao.add(devolucao);
                }
                return listaDevolucao;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
    
}
