/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Multa;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class MultaDAOJdbc implements MultaDAO {

    @Override
    public void add(Multa multa) throws DaoException {
        String sql = """
                     insert into Multa(ID, Valor,UsuarioID,FuncionarioID,PublicacaoISBN,DataAplicacao)
                 values(? ,?, ?, ?, ?, ?);
                     insert into Notificacao(UsuarioID,PublicacaoISBN,DataNotificacao,FuncionarioID,TipoNotificacao)
                 values(?, ?, ?, ?,'Multa por exceder os 7 dias')
                     """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);) {
            pstmt.setInt(1, multa.getID());
            pstmt.setInt(2, multa.getValor());
            pstmt.setInt(3, multa.getUsuarioID());
            pstmt.setInt(4, multa.getFuncionarioID());
            pstmt.setString(5, multa.getPublicacaoISBN());
            pstmt.setObject(6, multa.getDataAplicacao());

            pstmt.setInt(7, multa.getUsuarioID());
            pstmt.setString(8, multa.getPublicacaoISBN());
            pstmt.setObject(9, multa.getDataAplicacao());
            pstmt.setInt(10, multa.getFuncionarioID());
            pstmt.executeUpdate();

            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public void remove(int id) throws DaoException {
        String sql = """
                     delete from Multa 
                 where ID = ?
                     delete from Notificacao
                 where ID = ? 
                     """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public void update(Multa multa) throws DaoException {
        String sql = """
                     update Multa set UsuarioID = ?,Valor = ?, PublicacaoISBN=?
                 where ID = ?
   
                     """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, multa.getUsuarioID());
            pstmt.setInt(2, multa.getValor());
            pstmt.setString(3, multa.getPublicacaoISBN());
            pstmt.setInt(4, multa.getID());
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public Optional<Multa> findById(int id) throws DaoException {
        String sql = "select * from Multa "
                + "where ID = ?";
        Optional<Multa> optionalMulta = Optional.empty();
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery();) {
                if (rs.next()) {
                    Multa multa = new Multa();
                    multa.setID(rs.getInt("ID"));
                    multa.setValor(rs.getInt("Valor"));
                    multa.setUsuarioID(rs.getInt("UsuarioID"));
                    multa.setFuncionarioID(rs.getInt("FuncionarioID"));
                    multa.setPublicacaoISBN(rs.getString("PublicacaoISBN"));
                    multa.setDataAplicacao(rs.getDate("DataAplicacao").toLocalDate());
                    optionalMulta = Optional.of(multa);
                }
                return optionalMulta;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public List<Multa> findAll() throws DaoException {
        String sql = "select * from Multa";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Multa> listaMulta = new ArrayList<>();
                while (rs.next()) {
                    Multa multa = new Multa();
                    multa.setID(rs.getInt("ID"));
                    multa.setValor(rs.getInt("Valor"));
                    multa.setUsuarioID(rs.getInt("UsuarioID"));
                    multa.setFuncionarioID(rs.getInt("FuncionarioID"));
                    multa.setPublicacaoISBN(rs.getString("PublicacaoISBN"));
                    multa.setDataAplicacao(rs.getDate("DataAplicacao").toLocalDate());
                    listaMulta.add(multa);
                }
                return listaMulta;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

//    @Override
//    public Optional<Multa> findByValor(int valor) throws DaoException {
//         String sql = "select * from Multa "
//                + "where Valor = ?";
//        Optional<Multa> optionalMulta = Optional.empty();
//        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
//            pstmt.setInt(1, valor);
//            try (ResultSet rs = pstmt.executeQuery();) {
//                if (rs.next()) {
//                    Multa multa = new Multa();
//                    multa.setID(rs.getInt("ID"));
//                    multa.setValor(rs.getInt("Valor"));
//                    multa.setUsuarioID(rs.getInt("UsuarioID"));
//                    multa.setFuncionarioID(rs.getInt("FuncionarioID"));
//                    multa.setPublicacaoISBN(rs.getString("PublicacaoISBN"));
//                    multa.setDataAplicacao(rs.getDate("DataDevolucao").toLocalDate());
//                    optionalMulta = Optional.of(multa);
//                }
//                return optionalMulta;
//            }
//        } catch (SQLException ex) {
//            throw new DaoException(ex);
//        }
//    }
}
