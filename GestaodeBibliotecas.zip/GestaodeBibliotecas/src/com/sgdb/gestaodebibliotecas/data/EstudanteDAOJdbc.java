package com.sgdb.gestaodebibliotecas.data;

import java.sql.*;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Estudante;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public class EstudanteDAOJdbc implements EstudanteDAO {

    // Inserir nas tabelas "Usuario" e "Estudante"
    //String sqlEstudante = "INSERT INTO Estudante (ID, UsuarioID, NomeDaEscola) VALUES (?, ?, ?)";
//     PreparedStatement pstmtEstudante = conn.prepareStatement(sqlEstudante, Statement.RETURN_GENERATED_KEYS)) {
//    
//    @Override
//    public void add(Estudante estudante) throws DaoException {
//
//        String sqlEstudante = """
//                              --insert into Usuario (ID, TipoUsuario, Nome, Email, Telefone, Morada, CNI)"
//                              --VALUES (?,'Estudante', ?, ?, ?, ?, ?)
//                              
//                           insert into Estudante (ID, UsuarioID, NomeDaEscola)
//                           VALUES (?, ?, ?)
//                              """;
//
//        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmtEstudante = conn.prepareStatement(sqlEstudante, Statement.RETURN_GENERATED_KEYS);) {
//
////            // Atualização na tabela "Usuario"
////            pstmtEstudante.setInt(1, estudante.getUsuarioID());
////            pstmtEstudante.setString(2, estudante.getNome());
////            pstmtEstudante.setString(3, estudante.getEmail());
////            pstmtEstudante.setString(4, estudante.getTelefone());
////            pstmtEstudante.setString(5, estudante.getMorada());
////            pstmtEstudante.setInt(6, estudante.getCNI());
//
////            // Inserção na tabela "Estudante"
//            pstmtEstudante.setInt(1, estudante.getID());
//            pstmtEstudante.setInt(2, estudante.getUsuarioID());
//            pstmtEstudante.setString(3, estudante.getNomeDaEscola());
//            pstmtEstudante.executeUpdate();
//
//            ResultSet rsEstudante = pstmtEstudante.getGeneratedKeys();
//            if (rsEstudante.next()) {
////                int idd = rsEstudante.getInt(1);
////                estudante.setUsuarioID(idd);
//
//                int idd1 = rsEstudante.getInt(1);
//                estudante.setID(idd1);
//            }
//
//    
//    
    //---------------------------------------------------------------
    @Override
    public void add(Estudante estudante) throws DaoException {

        String sqlUsuario = "insert into Usuario (ID, Nome, Email, Telefone, Morada, CNI, TipoUsuario)"
                + "VALUES (?, ?, ?, ?, ?, ?,'Estudante')";

        String sqlEstudante = "insert into Estudante (ID, UsuarioID, NomeDaEscola)"
                + " VALUES (?, ?, ?)";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmtUsuario = conn.prepareStatement(sqlUsuario); PreparedStatement pstmtEstudante = conn.prepareStatement(sqlEstudante, Statement.RETURN_GENERATED_KEYS);) {

            // Atualização na tabela "Usuario"
            pstmtUsuario.setInt(1, estudante.getUsuarioID());
            pstmtUsuario.setString(2, estudante.getNome());
            pstmtUsuario.setString(3, estudante.getEmail());
            pstmtUsuario.setString(4, estudante.getTelefone());
            pstmtUsuario.setString(5, estudante.getMorada());
            pstmtUsuario.setInt(6, estudante.getCNI());
            pstmtUsuario.executeUpdate();

            // Inserção na tabela "Estudante"
            pstmtEstudante.setInt(1, estudante.getID());
            pstmtEstudante.setInt(2, estudante.getUsuarioID());
            pstmtEstudante.setString(3, estudante.getNomeDaEscola());
            pstmtEstudante.executeUpdate();

//            ResultSet rsEstudante = pstmtEstudante.getGeneratedKeys();
//            if (rsEstudante.next()) {
//                int idd = rsEstudante.getInt(1);
//                estudante.setID(idd);
//                int idd1 = rsEstudante.getInt(2);
//                estudante.setUsuarioID(idd1);
//            }
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
    //---------------------------------------------------------------
//        String sqlEstudante = "INSERT INTO Estudante (ID, UsuarioID, NomeDaEscola) VALUES (?, ?, ?)";
//        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmtEstudante = conn.prepareStatement(sqlEstudante);) {
//        pstmtEstudante.setInt(1, estudante.getID());
//        pstmtEstudante.setInt(2, estudante.getUsuarioID());
//        pstmtEstudante.setString(3, estudante.getNomeDaEscola());
//        pstmtEstudante.executeUpdate();
//
//        ResultSet rsEstudante = pstmtEstudante.getGeneratedKeys();
//        if (rsEstudante.next()) {
//            int idd = rsEstudante.getInt(1);
//            estudante.setID(idd);
//
//            int idd1 = rsEstudante.getInt(2);
//            estudante.setUsuarioID(idd1);
//        }
//            conn.commit();
//        }catch (SQLException ex) {
////            throw new DaoException(ex);         
//        }
    //---------------------------------------------------------------

    @Override
    public void remove(int id) throws DaoException {
//            String sqlUsuario = "delete from Usuario "
//                + "where ID = ?";
        String sqlEstudante = """
                                 delete from Estudante 
                                  where UsuarioID = ?
                                 
                                 delete from Usuario
                                   where ID = ?
                                 """;

        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmtEstudante = conn.prepareStatement(sqlEstudante);) {
            //deletar na tabela usuario
//            pstmt.setInt(1, id);
//            pstmt.executeUpdate();
//            
//            //deletar na tabela Estudante
            pstmtEstudante.setInt(1, id);
            //deletar na tabela Usuario
            pstmtEstudante.setInt(2, id);
            pstmtEstudante.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
    //---------------------------------------------------------------
//PreparedStatement pstmtEstudante = conn.prepareStatement(sqlEstudante);
    //---------------------------------------------------------------

    @Override
    public void update(Estudante estudante) throws DaoException {
        String sql = """ 
                        update Usuario set Nome = ?, Email = ?, Telefone = ?, Morada = ?, CNI = ?
                      where ID = ?
                   
                      update Estudante set NomeDaEscola = ?
                       where ID = ?
                        """;

        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
//            
            pstmt.setString(1, estudante.getNome());
            pstmt.setString(2, estudante.getEmail());
            pstmt.setString(3, estudante.getTelefone());
            pstmt.setString(4, estudante.getMorada());
            pstmt.setInt(5, estudante.getCNI());
            pstmt.setInt(6, estudante.getUsuarioID());

            pstmt.setString(7, estudante.getNomeDaEscola());
            pstmt.setInt(8, estudante.getID());

            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
    //---------------------------------------------------------------

    @Override
    public List<Estudante> findAll() throws DaoException {
        String sql = """
                     SELECT e.ID, e.UsuarioID, u.Nome, e.NomeDaEscola, u.Email, u.Telefone, u.Morada, u.CNI
                     FROM Usuario u
                     JOIN Estudante e ON u.ID = e.UsuarioID""";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Estudante> listaEstudante = new ArrayList<>();
                while (rs.next()) {
                    Estudante estudante = new Estudante();
                    estudante.setID(rs.getInt("ID"));
                    estudante.setUsuarioID(rs.getInt("UsuarioID"));
                    estudante.setNome(rs.getString("Nome"));
                    estudante.setNomeDaEscola(rs.getString("NomeDaEscola"));
                    estudante.setEmail(rs.getString("Email"));
                    estudante.setTelefone(rs.getString("Telefone"));
                    estudante.setMorada(rs.getString("Morada"));
                    estudante.setCNI(rs.getInt("CNI"));

                    listaEstudante.add(estudante);
                }
                return listaEstudante;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    //---------------------------------------------------------------
    @Override
    public Optional<Estudante> findById(int id) throws DaoException {
        String sql = """
                     SELECT e.ID, e.UsuarioID, u.Nome, e.NomeDaEscola, u.Email, u.Telefone, u.Morada, u.CNI
                     FROM Usuario u
                     JOIN Estudante e ON u.ID = e.UsuarioID
                     where e.ID = ?
                         """;
        Optional<Estudante> optionalEstudante = Optional.empty();
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery();) {
                if (rs.next()) {
                    Estudante estudante = new Estudante();
                    estudante.setID(rs.getInt("ID"));
                    estudante.setUsuarioID(rs.getInt("UsuarioID"));
                    estudante.setNome(rs.getString("Nome"));
                    estudante.setNomeDaEscola(rs.getString("NomeDaEscola"));
                    estudante.setEmail(rs.getString("Email"));
                    estudante.setTelefone(rs.getString("Telefone"));
                    estudante.setMorada(rs.getString("Morada"));
                    estudante.setCNI(rs.getInt("CNI"));
                    optionalEstudante = Optional.of(estudante);
                }
                return optionalEstudante;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
    //---------------------------------------------------------------

    @Override
    public List<Estudante> findByNome(String nome) throws DaoException {
        String sql = """ 
                     SELECT e.ID, e.UsuarioID, u.Nome, e.NomeDaEscola, u.Email, u.Telefone, u.Morada, u.CNI
                     FROM Usuario u
                     JOIN Estudante e ON u.ID = e.UsuarioID
                     where u.Nome like ?
                      """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, nome + "%");
          
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Estudante> listaEstudante = new ArrayList<>();
                while (rs.next()) {
                    Estudante estudante = new Estudante();
                    estudante.setID(rs.getInt("ID"));
                    estudante.setUsuarioID(rs.getInt("UsuarioID"));
                    estudante.setNome(rs.getString("Nome"));
                    estudante.setNomeDaEscola(rs.getString("NomeDaEscola"));
                    estudante.setEmail(rs.getString("Email"));
                    estudante.setTelefone(rs.getString("Telefone"));
                    estudante.setMorada(rs.getString("Morada"));
                    estudante.setCNI(rs.getInt("CNI"));
                    listaEstudante.add(estudante);
                }
                return listaEstudante;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }

    }
    //---------------------------------------------------------------

    @Override
    public List<Estudante> findByNomeDaEscola(String nomedaescola) throws DaoException {
        String sql = """ 
                     SELECT e.ID, e.UsuarioID, u.Nome, e.NomeDaEscola, u.Email, u.Telefone, u.Morada, u.CNI
                     FROM Usuario u
                     JOIN Estudante e ON u.ID = e.UsuarioID
                     where e.NomeDaEscola like ?
                     """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, nomedaescola + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Estudante> listaEstudante = new ArrayList<>();
                while (rs.next()) {
                    Estudante estudante = new Estudante();
                    estudante.setID(rs.getInt("ID"));
                    estudante.setUsuarioID(rs.getInt("UsuarioID"));
                    estudante.setNome(rs.getString("Nome"));
                    estudante.setNomeDaEscola(rs.getString("NomeDaEscola"));
                    estudante.setEmail(rs.getString("Email"));
                    estudante.setTelefone(rs.getString("Telefone"));
                    estudante.setMorada(rs.getString("Morada"));
                    estudante.setCNI(rs.getInt("CNI"));
                    listaEstudante.add(estudante);
                }
                return listaEstudante;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
    //---------------------------------------------------------------

}
