/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Reserva;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author user
 */
public interface ReservaDAO {

    public void add(Reserva reserva) throws DaoException;

    public void remove(int id) throws DaoException;

    public void update(Reserva reserva) throws DaoException;

    public Optional<Reserva> findById(int id) throws DaoException;

    public List<Reserva> findAll() throws DaoException;

}
