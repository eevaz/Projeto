/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Artigo;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public interface ArtigoDAO {
    
     public void add(Artigo artigo) throws DaoException;
    
    public void removeAll(String ISBN) throws DaoException;
    
    public void update(Artigo artigo) throws DaoException;
    
    public List<Artigo> findAll() throws DaoException;
    
     public List<Artigo> findByISBN(String isbn) throws DaoException;

    public List<Artigo> findByTitulo(String titulo) throws DaoException;

    public List<Artigo> findByArbitro(String arbitro) throws DaoException;

}
    

