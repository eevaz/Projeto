/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Usuario;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public interface UsuarioDAO {
    
    public void add(Usuario usuario) throws DaoException;
    
    public void remove(int id) throws DaoException;

    public void update(Usuario usuario) throws DaoException;
    
    public List<Usuario> findAll() throws DaoException;        
}
