/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Publicacao;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.SQLException;


/**
 *
 * @author user
 */
public class PublicacaoDAOJdbc implements PublicacaoDAO {

//---------------------------------------------------------------------------------  

    @Override
    public List<Publicacao> findAll() {
        String sql = "select * from Publicacao";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Publicacao> listaPublicacaos = new ArrayList<>();
                while (rs.next()) {
                    Publicacao publicacao = new Publicacao();
                    publicacao.setISBN(rs.getString("ISBN"));
                    publicacao.setTipo(rs.getString("Tipo"));
                    listaPublicacaos.add(publicacao);
                }
                return listaPublicacaos;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------  

    @Override
    public void add(Publicacao publicacao) {
        String sql = "insert into Publicacao(ISBN, Tipo)"
                + "values(?, ?)";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, publicacao.getISBN());
            pstmt.setString(2, publicacao.getTipo());
            pstmt.executeUpdate();

            conn.commit();
        } catch (SQLException ex) {
//            throw new DaoException(ex);         
        }
    }
//---------------------------------------------------------------------------------  

    @Override
    public void removeAll(String ISBN)throws DaoException {
        String sql = """
                                delete from Livro 
                                where ISBN = ?
                                
                            delete from Revista 
                             where ISBN = ?
                     
                            delete from Artigo 
                              where ISBN = ?
                            
                                delete from Publicacao
                                 where ISBN = ?
                                """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, ISBN);
            pstmt.setString(2, ISBN);
            pstmt.setString(3, ISBN);
            pstmt.setString(4, ISBN);
            pstmt.executeUpdate();
            
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------  

    @Override
    public void update(Publicacao publicacao) throws DaoException {
             String sql = "update Publicacao set Tipo = ? "
                + "where ISBN = ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, publicacao.getTipo());
            pstmt.setString(2, publicacao.getISBN());
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
    //---------------------------------------------------------------
}
