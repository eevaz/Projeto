/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;


import java.sql.*;
import java.util.ArrayList;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Funcionario;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.util.List;
import java.util.Optional;

/*
 *
 * @author EIDDSON VAZ
 */
public class FuncionarioDAOJdbc implements FuncionarioDAO{
    
    @Override
    public void add(Funcionario funcionario) throws DaoException {
       String sql = "insert into Funcionario(ID, Nome,Cargo)"
                + "values(?, ?, ?)";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);) {
            pstmt.setInt(1, funcionario.getID());
            pstmt.setString(2, funcionario.getNome());
            pstmt.setString(3, funcionario.getCargo());
            pstmt.executeUpdate();
//            ResultSet rs = pstmt.getGeneratedKeys();
//            if (rs.next()) {
//                int idd = rs.getInt(1);
////                funcionario.setID(idd);
//            }
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);         
        }
    }

//---------------------------------------------------------------
    @Override
    public void remove(int id) throws DaoException {
       String sql = "delete from Funcionario "
                + "where ID = ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
    
    //---------------------------------------------------------------
    @Override
    public void update(Funcionario funcionario) throws DaoException {
   String sql = "update Funcionario set Nome = ?, Cargo = ? "
                + "where ID = ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
//            pstmt.setInt(1, funcionario.getID());
            pstmt.setString(1, funcionario.getNome());
            pstmt.setString(2, funcionario.getCargo());
            pstmt.setInt(3, funcionario.getID());
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    //---------------------------------------------------------------
    @Override
    public Optional<Funcionario> findById(int id) throws DaoException {
       String sql = "select * from Funcionario "
                + "where ID = ?";
        Optional<Funcionario> optionalFuncionario = Optional.empty();
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery();) {
                if (rs.next()) {
                    Funcionario funcionario = new Funcionario();
                    funcionario.setID(rs.getInt("ID"));
                    funcionario.setNome(rs.getString("Nome"));
                    funcionario.setCargo(rs.getString("Cargo"));
                    optionalFuncionario = Optional.of(funcionario);
                }
                return optionalFuncionario;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    //---------------------------------------------------------------
    @Override
    public List<Funcionario> findByCargo(String cargo) throws DaoException {
     String sql = "select * from Funcionario "
                + "where Cargo like ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, cargo + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Funcionario> listaFuncionario = new ArrayList<>();
                while (rs.next()) {
                    Funcionario funcionario = new Funcionario();
                    funcionario.setID(rs.getInt("ID"));
                    funcionario.setNome(rs.getString("Nome"));
                    funcionario.setCargo(rs.getString("Cargo"));
                    listaFuncionario.add(funcionario);
                }
                return listaFuncionario;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
    
    //---------------------------------------------------------------
    @Override
    public List<Funcionario> findByNome(String nome) throws DaoException {
     String sql = "select * from Funcionario "
                + "where Nome like ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, nome + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Funcionario> listaFuncionario = new ArrayList<>();
                while (rs.next()) {
                    Funcionario funcionario = new Funcionario();
                    funcionario.setID(rs.getInt("ID"));
                    funcionario.setNome(rs.getString("Nome"));
                    funcionario.setCargo(rs.getString("Cargo"));
                    listaFuncionario.add(funcionario);
                }
                return listaFuncionario;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }

    }

    //---------------------------------------------------------------
    @Override
    public List<Funcionario> findAll() throws DaoException {
      String sql = "select * from Funcionario";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Funcionario> listaFuncionario = new ArrayList<>();
                while (rs.next()) {
                    Funcionario funcionario = new Funcionario();
                    funcionario.setID(rs.getInt("ID"));
                    funcionario.setNome(rs.getString("Nome"));
                    funcionario.setCargo(rs.getString("Cargo"));
                    listaFuncionario.add(funcionario);
                }
                return listaFuncionario;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

}
