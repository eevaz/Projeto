
package com.sgdb.gestaodebibliotecas.data;

import java.sql.*;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Trabalhador;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public class TrabalhadorDAOJdbc implements TrabalhadorDAO {

    //---------------------------------------------------------------
    @Override
    public void add(Trabalhador trabalhador) throws DaoException {
      
        String sqlUsuario = "insert into Usuario (ID, Nome, Email, Telefone, Morada, CNI, TipoUsuario)"
                + "VALUES (?, ?, ?, ?, ?, ?,'Trabalhador')";

        String sqlTrabalhador = "insert into Trabalhador (ID, UsuarioID, Cargo, CentroDeTrabalho)"
                + " VALUES (?, ?, ?, ?)";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmtUsuario = conn.prepareStatement(sqlUsuario); PreparedStatement pstmtTrabalhador = conn.prepareStatement(sqlTrabalhador, Statement.RETURN_GENERATED_KEYS);) {

            // Atualização na tabela "Usuario"
            pstmtUsuario.setInt(1, trabalhador.getUsuarioID());
            pstmtUsuario.setString(2, trabalhador.getNome());
            pstmtUsuario.setString(3, trabalhador.getEmail());
            pstmtUsuario.setString(4, trabalhador.getTelefone());
            pstmtUsuario.setString(5, trabalhador.getMorada());
            pstmtUsuario.setInt(6, trabalhador.getCNI());

            pstmtUsuario.executeUpdate();

            // Inserção na tabela "Trabalhador"
            pstmtTrabalhador.setInt(1, trabalhador.getID());
            pstmtTrabalhador.setInt(2, trabalhador.getUsuarioID());
            pstmtTrabalhador.setString(3, trabalhador.getCargo());
            pstmtTrabalhador.setString(4, trabalhador.getCentroDeTrabalho());
            pstmtTrabalhador.executeUpdate();

//            ResultSet rsTrabalhador = pstmtTrabalhador.getGeneratedKeys();
//            if (rsTrabalhador.next()) {
//                int idd = rsTrabalhador.getInt(1);
//                trabalhador.setID(idd);
//
////                int idd1 = rsEstudante.getInt(2);
////                estudante.setUsuarioID(idd1);
//            }

            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------
    @Override
    public void remove(int id) throws DaoException {
       String sqlTrabalhador = """
                                 delete from Trabalhador 
                                  where UsuarioID = ?
                                 
                                 delete from Usuario
                                   where ID = ?
                                 """;

        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmtTrabalhador = conn.prepareStatement(sqlTrabalhador);) {
            //deletar na tabela usuario
//            pstmt.setInt(1, id);
//            pstmt.executeUpdate();
//            
//            //deletar na tabela Trabalhador
            pstmtTrabalhador.setInt(1, id);
             //deletar na tabela Usuario
            pstmtTrabalhador.setInt(2, id);
            pstmtTrabalhador.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------
    @Override
    public void update(Trabalhador trabalhador) throws DaoException {
          String sql = """ 
                        update Usuario set Nome = ?, Email = ?, Telefone = ?, Morada = ?, CNI = ?
                      where ID = ?
                   
                      update Trabalhador set Cargo = ?, CentroDeTrabalho = ? 
                       where ID = ?
                        """;

        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
//           
            pstmt.setString(1, trabalhador.getNome());
            pstmt.setString(2, trabalhador.getEmail());
            pstmt.setString(3, trabalhador.getTelefone());
            pstmt.setString(4, trabalhador.getMorada());
            pstmt.setInt(5, trabalhador.getCNI());
            pstmt.setInt(6, trabalhador.getUsuarioID());

            pstmt.setString(7, trabalhador.getCargo());
            pstmt.setString(8, trabalhador.getCentroDeTrabalho());
            pstmt.setInt(9, trabalhador.getID());

            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------
    @Override
    public List<Trabalhador> findAll() throws DaoException {
        String sql = """
                   SELECT t.ID, t.UsuarioID, u.Nome, t.Cargo, t.CentroDeTrabalho, u.Email, u.Telefone, u.Morada, u.CNI
                   FROM Usuario u
                   JOIN Trabalhador t ON u.ID = t.UsuarioID""";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Trabalhador> listaTrabalhador = new ArrayList<>();
                while (rs.next()) {
                    Trabalhador trabalhador = new Trabalhador();
                    trabalhador.setID(rs.getInt("ID"));
                    trabalhador.setUsuarioID(rs.getInt("UsuarioID"));
                    trabalhador.setNome(rs.getString("Nome"));
                    trabalhador.setCargo(rs.getString("Cargo"));
                    trabalhador.setCentroDeTrabalho(rs.getString("CentroDeTrabalho"));
                    trabalhador.setEmail(rs.getString("Email"));
                    trabalhador.setTelefone(rs.getString("Telefone"));
                    trabalhador.setMorada(rs.getString("Morada"));
                    trabalhador.setCNI(rs.getInt("CNI"));

                    listaTrabalhador.add(trabalhador);
                }
                return listaTrabalhador;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------
    @Override
    public Optional<Trabalhador> findById(int id) throws DaoException {
        String sql = """
                     SELECT t.ID, t.UsuarioID, u.Nome, t.Cargo, t.CentroDeTrabalho, u.Email, u.Telefone, u.Morada, u.CNI
                     FROM Usuario u
                     JOIN Trabalhador t ON u.ID = t.UsuarioID
                     where t.ID = ?
                         """;
        Optional<Trabalhador> optionalTrabalhador = Optional.empty();
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery();) {
                if (rs.next()) {
                    Trabalhador trabalhador = new Trabalhador();
                     trabalhador.setID(rs.getInt("ID"));
                    trabalhador.setUsuarioID(rs.getInt("UsuarioID"));
                    trabalhador.setNome(rs.getString("Nome"));
                    trabalhador.setCargo(rs.getString("Cargo"));
                    trabalhador.setCentroDeTrabalho(rs.getString("CentroDeTrabalho"));
                    trabalhador.setEmail(rs.getString("Email"));
                    trabalhador.setTelefone(rs.getString("Telefone"));
                    trabalhador.setMorada(rs.getString("Morada"));
                    trabalhador.setCNI(rs.getInt("CNI"));
                    optionalTrabalhador = Optional.of(trabalhador);
                }
                return optionalTrabalhador;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------  
@Override
    public List<Trabalhador> findByNome(String nome) throws DaoException {
       String sql = """ 
                     SELECT t.ID, t.UsuarioID, u.Nome, t.Cargo, t.CentroDeTrabalho, u.Email, u.Telefone, u.Morada, u.CNI
                     FROM Usuario u
                     JOIN Trabalhador t ON u.ID = t.UsuarioID
                     where u.Nome like ?
                      """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, nome + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Trabalhador> listaTrabalhador = new ArrayList<>();
                while (rs.next()) {
                    Trabalhador trabalhador = new Trabalhador();
                    trabalhador.setID(rs.getInt("ID"));
                    trabalhador.setUsuarioID(rs.getInt("UsuarioID"));
                    trabalhador.setNome(rs.getString("Nome"));
                    trabalhador.setCargo(rs.getString("Cargo"));
                    trabalhador.setCentroDeTrabalho(rs.getString("CentroDeTrabalho"));
                    trabalhador.setEmail(rs.getString("Email"));
                    trabalhador.setTelefone(rs.getString("Telefone"));
                    trabalhador.setMorada(rs.getString("Morada"));
                    trabalhador.setCNI(rs.getInt("CNI"));
                    listaTrabalhador.add(trabalhador);
                }
                return listaTrabalhador;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }

    }
//------------------------------------------------------
    @Override
    public List<Trabalhador> findByCargo(String cargo) throws DaoException {
         String sql = """ 
                    SELECT t.ID, t.UsuarioID, u.Nome, t.Cargo, t.CentroDeTrabalho, u.Email, u.Telefone, u.Morada, u.CNI
                    FROM Usuario u
                    JOIN Trabalhador t ON u.ID = t.UsuarioID
                    where t.Cargo like ?
                     """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, cargo + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Trabalhador> listaTrabalhador = new ArrayList<>();
                while (rs.next()) {
                    Trabalhador trabalhador = new Trabalhador();
                      trabalhador.setID(rs.getInt("ID"));
                    trabalhador.setUsuarioID(rs.getInt("UsuarioID"));
                    trabalhador.setNome(rs.getString("Nome"));
                    trabalhador.setCargo(rs.getString("Cargo"));
                    trabalhador.setCentroDeTrabalho(rs.getString("CentroDeTrabalho"));
                    trabalhador.setEmail(rs.getString("Email"));
                    trabalhador.setTelefone(rs.getString("Telefone"));
                    trabalhador.setMorada(rs.getString("Morada"));
                    trabalhador.setCNI(rs.getInt("CNI"));
                    listaTrabalhador.add(trabalhador);
                }
                return listaTrabalhador;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------    
    @Override
    public List<Trabalhador> findByCentroDeTrabalho(String centrodetrabalho) throws DaoException {
        String sql = """ 
                    SELECT t.ID, t.UsuarioID, u.Nome, t.Cargo, t.CentroDeTrabalho, u.Email, u.Telefone, u.Morada, u.CNI
                    FROM Usuario u
                    JOIN Trabalhador t ON u.ID = t.UsuarioID
                    where t.CentroDeTrabalho like ?
                     """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, centrodetrabalho + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Trabalhador> listaTrabalhador = new ArrayList<>();
                while (rs.next()) {
                    Trabalhador trabalhador = new Trabalhador();
                    trabalhador.setID(rs.getInt("ID"));
                    trabalhador.setUsuarioID(rs.getInt("UsuarioID"));
                    trabalhador.setNome(rs.getString("Nome"));
                    trabalhador.setCargo(rs.getString("Cargo"));
                    trabalhador.setCentroDeTrabalho(rs.getString("CentroDeTrabalho"));
                    trabalhador.setEmail(rs.getString("Email"));
                    trabalhador.setTelefone(rs.getString("Telefone"));
                    trabalhador.setMorada(rs.getString("Morada"));
                    trabalhador.setCNI(rs.getInt("CNI"));
                    listaTrabalhador.add(trabalhador);
                }
                return listaTrabalhador;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------
    

    

}
