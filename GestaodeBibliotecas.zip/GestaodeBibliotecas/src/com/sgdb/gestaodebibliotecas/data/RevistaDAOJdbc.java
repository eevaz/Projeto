/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import java.sql.*;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Revista;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public class RevistaDAOJdbc implements RevistaDAO {

    @Override
    public void add(Revista revista) throws DaoException {

        String sqlPublicacao = " insert into Publicacao(ISBN, Tipo)"
                + "values(?, 'Revista')";

        String sqlRevista = "INSERT INTO Revista (ISBN, Categoria, Titulo, AnoPublicacao, Editora, Numero, N_Exemplar, N_Exemplar_Emprestado)"
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmtPublicacao = conn.prepareStatement(sqlPublicacao); PreparedStatement pstmtRevista = conn.prepareStatement(sqlRevista, Statement.RETURN_GENERATED_KEYS);) {

            // Inserção na tabela "Publicacao"
            pstmtPublicacao.setString(1, revista.getISBN());
            pstmtPublicacao.executeUpdate();

            // Inserção na tabela "Revista"
            pstmtRevista.setString(1, revista.getISBN());
            pstmtRevista.setString(2, revista.getCategoria());
            pstmtRevista.setString(3, revista.getTitulo());
            pstmtRevista.setInt(4, revista.getAnoPublicacao());
            pstmtRevista.setString(5, revista.getEditora());
            pstmtRevista.setInt(6, revista.getNumero());
            pstmtRevista.setInt(7, revista.getNumero_exemplar());
            pstmtRevista.setInt(8, revista.getNumero_exemplar_emprestado());
            pstmtRevista.executeUpdate();

//            ResultSet rsLivro = pstmtLivro.getGeneratedKeys();
//            if (rsLivro.next()) {
//                String isbn = rsLivro.getString(1);
//                livro.setISBN(isbn);
//
////                int idd1 = rsEstudante.getInt(2);
////                estudante.setUsuarioID(idd1);
//            }
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public void removeAll(String ISBN) throws DaoException {
     String sqlRevista = """
                                 delete from Revista 
                                  where ISBN = ?
                                 
                                 delete from Publicacao
                                   where ISBN = ?
                                 """;

        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmtRevista = conn.prepareStatement(sqlRevista);) {
           
//            //deletar na tabela Revista
            pstmtRevista.setString(1, ISBN);
              //deletar na tabela Publicacao
            pstmtRevista.setString(2, ISBN);
            pstmtRevista.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public void update(Revista revista) throws DaoException {
       String sql = "update Revista set Categoria = ?, Titulo = ?, AnoPublicacao = ?, Editora = ?,  Numero = ?, N_Exemplar = ?, N_Exemplar_Emprestado = ? "
                + "where ISBN = ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, revista.getCategoria());
            pstmt.setString(2, revista.getTitulo());
            pstmt.setInt(3, revista.getAnoPublicacao());
            pstmt.setString(4, revista.getEditora());
            pstmt.setInt(5, revista.getNumero());
            pstmt.setInt(6, revista.getNumero_exemplar());
            pstmt.setInt(7, revista.getNumero_exemplar_emprestado());
            pstmt.setString(8, revista.getISBN());
            pstmt.executeUpdate();

            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Revista> findAll() throws DaoException {
        String sql = """
                     select r.isbn,r.Categoria, r.titulo, r.AnoPublicacao, r.editora, r.Numero, r.n_exemplar, r.n_exemplar_emprestado from  Revista r
                   order by r.CategoriaID asc """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Revista> listaRevista = new ArrayList<>();
                while (rs.next()) {
                    Revista revista = new Revista();
                    revista.setISBN(rs.getString("ISBN"));
                    revista.setCategoria(rs.getString("Categoria"));
                    revista.setTitulo(rs.getString("Titulo"));
                    revista.setAnoPublicacao(rs.getInt("AnoPublicacao"));
                    revista.setEditora(rs.getString("Editora"));
                    revista.setNumero(rs.getInt("Numero"));
                    revista.setNumero_exemplar(rs.getInt("N_Exemplar"));
                    revista.setNumero_exemplar_emprestado(rs.getInt("N_Exemplar_Emprestado"));

                    listaRevista.add(revista);
                }
                return listaRevista;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------
 
    @Override
    public List<Revista> findByISBN(String isbn) throws DaoException {
          String sql = """
                    select r.isbn,r.Categoria, r.titulo, r.AnoPublicacao, r.editora, r.Numero, r.n_exemplar, r.n_exemplar_emprestado from  Revista r
                     where r.isbn like ? 
                       order by r.CategoriaID asc
                   
                    """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
           pstmt.setString(1, isbn + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Revista> listaRevista = new ArrayList<>();
                while (rs.next()) {
                     Revista revista = new Revista();
                    revista.setISBN(rs.getString("ISBN"));
                    revista.setCategoria(rs.getString("Categoria"));
                    revista.setTitulo(rs.getString("Titulo"));
                    revista.setAnoPublicacao(rs.getInt("AnoPublicacao"));
                    revista.setEditora(rs.getString("Editora"));
                    revista.setNumero(rs.getInt("Numero"));
                    revista.setNumero_exemplar(rs.getInt("N_Exemplar"));
                    revista.setNumero_exemplar_emprestado(rs.getInt("N_Exemplar_Emprestado"));

                    listaRevista.add(revista);
                }
                return listaRevista;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Revista> findByTitulo(String titulo) throws DaoException {
        String sql = """
                    select r.isbn,r.Categoria, r.titulo, r.AnoPublicacao, r.editora, r.Numero, r.n_exemplar, r.n_exemplar_emprestado from  Revista r
                     where r.titulo like ? 
                       order by r.CategoriaID asc
                   
                    """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
           pstmt.setString(1, titulo + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Revista> listaRevista = new ArrayList<>();
                while (rs.next()) {
                     Revista revista = new Revista();
                    revista.setISBN(rs.getString("ISBN"));
                    revista.setCategoria(rs.getString("Categoria"));
                    revista.setTitulo(rs.getString("Titulo"));
                    revista.setAnoPublicacao(rs.getInt("AnoPublicacao"));
                    revista.setEditora(rs.getString("Editora"));
                    revista.setNumero(rs.getInt("Numero"));
                    revista.setNumero_exemplar(rs.getInt("N_Exemplar"));
                    revista.setNumero_exemplar_emprestado(rs.getInt("N_Exemplar_Emprestado"));

                    listaRevista.add(revista);
                }
                return listaRevista;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------


    @Override
    public List<Revista> findByEditora(String editora) throws DaoException {
       String sql = """
                    select r.isbn,r.Categoria, r.titulo, r.AnoPublicacao, r.editora, r.Numero, r.n_exemplar, r.n_exemplar_emprestado from  Revista r
                     where r.editora like ? 
                       order by r.CategoriaID asc
                   
                    """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
           pstmt.setString(1, editora + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Revista> listaRevista = new ArrayList<>();
                while (rs.next()) {
                     Revista revista = new Revista();
                    revista.setISBN(rs.getString("ISBN"));
                    revista.setCategoria(rs.getString("Categoria"));
                    revista.setTitulo(rs.getString("Titulo"));
                    revista.setAnoPublicacao(rs.getInt("AnoPublicacao"));
                    revista.setEditora(rs.getString("Editora"));
                    revista.setNumero(rs.getInt("Numero"));
                    revista.setNumero_exemplar(rs.getInt("N_Exemplar"));
                    revista.setNumero_exemplar_emprestado(rs.getInt("N_Exemplar_Emprestado"));

                    listaRevista.add(revista);
                }
                return listaRevista;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------


}
