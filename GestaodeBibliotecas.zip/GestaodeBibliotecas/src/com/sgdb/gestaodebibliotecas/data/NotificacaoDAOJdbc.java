/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Notificacao;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author user
 */
public class NotificacaoDAOJdbc implements NotificacaoDAO {

    @Override
    public List<Notificacao> findAll() throws DaoException {
        String sql = "select * from Notificacao";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Notificacao> listaNotificacao = new ArrayList<>();
                while (rs.next()) {
                    Notificacao notificacao = new Notificacao();
                    notificacao.setID(rs.getInt("ID"));
                    notificacao.setUsuarioID(rs.getInt("UsuarioID"));
                    notificacao.setFuncionarioID(rs.getInt("FuncionarioID"));
                    notificacao.setPublicacaoISBN(rs.getString("PublicacaoISBN"));
                    notificacao.setTipoNotificacao(rs.getString("TipoNotificacao"));
                    notificacao.setDataNotificacao(rs.getDate("DataNotificacao").toLocalDate());
                    listaNotificacao.add(notificacao);
                }
                return listaNotificacao;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }

    @Override
    public void add(Notificacao notificacao) {
        String sql = "insert into Notificacao(ID, UsuarioID,FuncionarioID,PublicacaoISBN,TipoNotificacao,DataNotificacao)"
                + "values(?, ?, ?, ?, ?, ?)";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, notificacao.getID());
            pstmt.setInt(2, notificacao.getUsuarioID());
            pstmt.setInt(3, notificacao.getFuncionarioID());
            pstmt.setString(4, notificacao.getPublicacaoISBN());
            pstmt.setString(5, notificacao.getTipoNotificacao());
            pstmt.setObject(6, notificacao.getDataNotificacao());
            pstmt.executeUpdate();

            conn.commit();
        } catch (SQLException ex) {
//            throw new DaoException(ex);         
        }
    }

    @Override
    public void update(Notificacao notificacao) throws DaoException {

        String sql = "update Notificacao set TipoNotificacao = ?, DataNotificacao = ? "
                + "where ID = ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, notificacao.getTipoNotificacao());
            pstmt.setObject(2, notificacao.getDataNotificacao());
            pstmt.setInt(3, notificacao.getID());
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public void remove(int ID) throws DaoException {
        String sql = "DELETE FROM Notificacao "
                + "WHERE ID = ? ";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, ID);
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public Optional<Notificacao> findById(int id) throws DaoException {
        String sql = "select * from Notificacao "
                + "where ID = ?";
        Optional<Notificacao> optionalNotificacao = Optional.empty();
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery();) {
                if (rs.next()) {
                    Notificacao notificacao = new Notificacao();
                    notificacao.setID(rs.getInt("ID"));
                    notificacao.setUsuarioID(rs.getInt("UsuarioID"));
                    notificacao.setFuncionarioID(rs.getInt("FuncionarioID"));
                    notificacao.setPublicacaoISBN(rs.getString("PublicacaoISBN"));
                    notificacao.setTipoNotificacao(rs.getString("TipoNotificacao"));
                    notificacao.setDataNotificacao(rs.getDate("DataNotificacao").toLocalDate());
                    optionalNotificacao = Optional.of(notificacao);
                }
                return optionalNotificacao;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public List<Notificacao> findByTipoNotificacao(String tiponotificacao) throws DaoException {
        String sql = "select * from Notificacao "
                + "where TipoNotificacao like ? ";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, tiponotificacao + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Notificacao> listaNotificacao = new ArrayList<>();
                while (rs.next()) {
                    Notificacao notificacao = new Notificacao();
                    notificacao.setID(rs.getInt("ID"));
                    notificacao.setUsuarioID(rs.getInt("UsuarioID"));
                    notificacao.setFuncionarioID(rs.getInt("FuncionarioID"));
                    notificacao.setPublicacaoISBN(rs.getString("PublicacaoISBN"));
                    notificacao.setTipoNotificacao(rs.getString("TipoNotificacao"));
                    notificacao.setDataNotificacao(rs.getDate("DataNotificacao").toLocalDate());
                    listaNotificacao.add(notificacao);
                }
                return listaNotificacao;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    @Override
    public List<Notificacao> findByDataNotificacao(LocalDate datanotificacao) throws DaoException {
        String sql = "select * from Notificacao "
                + "where DataNotificacao like ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, datanotificacao + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Notificacao> listaNotificacao = new ArrayList<>();
                while (rs.next()) {
                    Notificacao notificacao = new Notificacao();
                    notificacao.setID(rs.getInt("ID"));
                    notificacao.setUsuarioID(rs.getInt("UsuarioID"));
                    notificacao.setFuncionarioID(rs.getInt("FuncionarioID"));
                    notificacao.setPublicacaoISBN(rs.getString("PublicacaoISBN"));
                    notificacao.setTipoNotificacao(rs.getString("TipoNotificacao"));
                    notificacao.setDataNotificacao(rs.getDate("DataNotificacao").toLocalDate());
                }
                return listaNotificacao;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }

    }

}
