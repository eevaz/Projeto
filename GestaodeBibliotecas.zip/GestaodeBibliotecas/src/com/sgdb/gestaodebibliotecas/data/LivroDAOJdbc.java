/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import java.sql.*;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Livro;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public class LivroDAOJdbc implements LivroDAO {

    @Override
    public void add(Livro livro) throws DaoException {

        String sqlPublicacao = " insert into Publicacao(ISBN, Tipo)"
                + "values(?, 'Livro')";

        String sqlLivro = "INSERT INTO Livro (ISBN, Categoria, Titulo, AnoPublicacao, Editora, Autor, N_Exemplar, N_Exemplar_Emprestado)"
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmtPublicacao = conn.prepareStatement(sqlPublicacao); PreparedStatement pstmtLivro = conn.prepareStatement(sqlLivro, Statement.RETURN_GENERATED_KEYS);) {

            // Inserção na tabela "Publicacao"
            pstmtPublicacao.setString(1, livro.getISBN());
            pstmtPublicacao.executeUpdate();

            // Inserção na tabela "Livro"
            pstmtLivro.setString(1, livro.getISBN());
            pstmtLivro.setString(2, livro.getCategoria());
            pstmtLivro.setString(3, livro.getTitulo());
            pstmtLivro.setInt(4, livro.getAnoPublicacao());
            pstmtLivro.setString(5, livro.getEditora());
            pstmtLivro.setString(6, livro.getAutor());
            pstmtLivro.setInt(7, livro.getNumero_exemplar());
            pstmtLivro.setInt(8, livro.getNumero_exemplar_emprestado());
            pstmtLivro.executeUpdate();

//            ResultSet rsLivro = pstmtLivro.getGeneratedKeys();
//            if (rsLivro.next()) {
//                String isbn = rsLivro.getString(1);
//                livro.setISBN(isbn);
//
////                int idd1 = rsEstudante.getInt(2);
////                estudante.setUsuarioID(idd1);
//            }
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//     String sql = "insert into Publicacao(ISBN, Tipo)"
//                + "values(?, ?)";
//        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
//            pstmt.setString(1, publicacao.getISBN());
//            pstmt.setString(2, publicacao.getTipo());
//            pstmt.executeUpdate();
//
//            conn.commit();
//        } catch (SQLException ex) {
////            throw new DaoException(ex);         
//        }
//    }
//---------------------------------------------------------------------------------  

    @Override
    public void removeAll(String ISBN) throws DaoException {
        String sqlLivro = """
                                 delete from Livro 
                                  where ISBN = ?

                                 delete from Publicacao
                                   where ISBN = ?
                                 """;

        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmtLivro = conn.prepareStatement(sqlLivro);) {

//            //deletar na tabela Livro
            pstmtLivro.setString(1, ISBN);
            //deletar na tabela Publicacao
            pstmtLivro.setString(2, ISBN);
            pstmtLivro.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public void update(Livro livro) throws DaoException {
        String sql = "update Livro set Categoria = ?, Titulo = ?, AnoPublicacao = ?, Editora = ?, Autor = ?, N_Exemplar = ?, N_Exemplar_Emprestado = ? "
                + "where ISBN = ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, livro.getCategoria());
            pstmt.setString(2, livro.getTitulo());
            pstmt.setInt(3, livro.getAnoPublicacao());
            pstmt.setString(4, livro.getEditora());
            pstmt.setString(5, livro.getAutor());
            pstmt.setInt(6, livro.getNumero_exemplar());
            pstmt.setInt(7, livro.getNumero_exemplar_emprestado());
            pstmt.setString(8, livro.getISBN());
            pstmt.executeUpdate();

            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Livro> findAll() throws DaoException {
        String sql = """
                    select l.isbn,l.Categoria, l.titulo, l.AnoPublicacao, l.editora,l.Autor , l.n_exemplar, l.n_exemplar_emprestado from  livro l
                     order by l.CategoriaID asc """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
                try (ResultSet rs = pstmt.executeQuery();) {
                List<Livro> listaLivro = new ArrayList<>();
                while (rs.next()) {
                    Livro livro = new Livro();
                    livro.setISBN(rs.getString("ISBN"));
                    livro.setCategoria(rs.getString("Categoria"));
                    livro.setTitulo(rs.getString("Titulo"));
                    livro.setAnoPublicacao(rs.getInt("AnoPublicacao"));
                    livro.setEditora(rs.getString("Editora"));
                    livro.setAutor(rs.getString("Autor"));
                    livro.setNumero_exemplar(rs.getInt("N_Exemplar"));
                    livro.setNumero_exemplar_emprestado(rs.getInt("N_Exemplar_Emprestado"));

                    listaLivro.add(livro);
                }
                return listaLivro;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Livro> findByISBN(String isbn) throws DaoException {
       String sql = """
                    select l.isbn,l.Categoria, l.titulo, l.AnoPublicacao, l.editora,l.Autor , l.n_exemplar, l.n_exemplar_emprestado from  livro l
                     where l.isbn like ? 
                    order by l.CategoriaID asc 
                   
                    """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
           pstmt.setString(1, isbn + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Livro> listaLivro = new ArrayList<>();
                while (rs.next()) {
                    Livro livro = new Livro();
                    livro.setISBN(rs.getString("ISBN"));
                    livro.setCategoria(rs.getString("Categoria"));
                    livro.setTitulo(rs.getString("Titulo"));
                    livro.setAnoPublicacao(rs.getInt("AnoPublicacao"));
                    livro.setEditora(rs.getString("Editora"));
                    livro.setAutor(rs.getString("Autor"));
                    livro.setNumero_exemplar(rs.getInt("N_Exemplar"));
                    livro.setNumero_exemplar_emprestado(rs.getInt("N_Exemplar_Emprestado"));
                    listaLivro.add(livro);
                }
                return listaLivro;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Livro> findByTitulo(String titulo) throws DaoException {
        String sql = """
                    select l.isbn,l.Categoria, l.titulo, l.AnoPublicacao, l.editora,l.Autor , l.n_exemplar, l.n_exemplar_emprestado from  livro l
                      where l.titulo like ?
                     order by l.CategoriaID asc 
                   
                    """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
           pstmt.setString(1, titulo + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Livro> listaLivro = new ArrayList<>();
                while (rs.next()) {
                    Livro livro = new Livro();
                    livro.setISBN(rs.getString("ISBN"));
                    livro.setCategoria(rs.getString("Categoria"));
                    livro.setTitulo(rs.getString("Titulo"));
                    livro.setAnoPublicacao(rs.getInt("AnoPublicacao"));
                    livro.setEditora(rs.getString("Editora"));
                    livro.setAutor(rs.getString("Autor"));
                    livro.setNumero_exemplar(rs.getInt("N_Exemplar"));
                    livro.setNumero_exemplar_emprestado(rs.getInt("N_Exemplar_Emprestado"));
                    listaLivro.add(livro);
                }
                return listaLivro;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Livro> findByAutor(String autor) throws DaoException {
      String sql = """
                    select l.isbn,l.Categoria, l.titulo, l.AnoPublicacao, l.editora,l.Autor , l.n_exemplar, l.n_exemplar_emprestado from  livro l
                   where l.Autor like ? 
                   order by l.CategoriaID asc 
                   """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
           pstmt.setString(1, autor + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Livro> listaLivro = new ArrayList<>();
                while (rs.next()) {
                    Livro livro = new Livro();
                    livro.setISBN(rs.getString("ISBN"));
                    livro.setCategoria(rs.getString("Categoria"));
                    livro.setTitulo(rs.getString("Titulo"));
                    livro.setAnoPublicacao(rs.getInt("AnoPublicacao"));
                    livro.setEditora(rs.getString("Editora"));
                    livro.setAutor(rs.getString("Autor"));
                    livro.setNumero_exemplar(rs.getInt("N_Exemplar"));
                    livro.setNumero_exemplar_emprestado(rs.getInt("N_Exemplar_Emprestado"));
                    listaLivro.add(livro);
                }
                return listaLivro;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------
}
