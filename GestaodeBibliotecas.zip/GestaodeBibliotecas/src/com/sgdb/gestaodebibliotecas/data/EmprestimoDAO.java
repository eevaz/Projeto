/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Emprestimo;
import java.time.LocalDate;
import java.util.List;

import java.util.Optional;

/**
 *
 * @author user
 */
public interface EmprestimoDAO {
     public void add(Emprestimo emprestimo) throws DaoException;

    public void remove(int id) throws DaoException;

    public void update(Emprestimo emprestimo) throws DaoException;
    
    public Optional<Emprestimo>  findById(int id) throws DaoException;
    
    public Optional<Emprestimo> findByDataEmprestimo(LocalDate dataemprestimo) throws DaoException ;
    
     public List<Emprestimo> findAll() throws DaoException;  

}
