/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Estudante;
;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */


public interface EstudanteDAO {

    public void add(Estudante estudante) throws DaoException;

    public void remove(int id) throws DaoException;

    public void update(Estudante estudante) throws DaoException;

    public List<Estudante> findAll() throws DaoException;

    public Optional<Estudante> findById(int id) throws DaoException;

    public List<Estudante> findByNome(String nome) throws DaoException;

    public List<Estudante> findByNomeDaEscola(String nomedaescola) throws DaoException;

}
