/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Multa;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author user
 */
public interface MultaDAO {
    
     public void add(Multa multa) throws DaoException;

    public void remove(int id) throws DaoException;

    public void update(Multa multa) throws DaoException;
    
    public Optional<Multa>  findById(int id) throws DaoException;
    
     public List<Multa> findAll() throws DaoException;  
}

//    public List<Multa>  findByValor(int valor) throws DaoException;
//    
