/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Trabalhador;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public interface TrabalhadorDAO {

    public void add(Trabalhador trabalhador) throws DaoException;

    public void remove(int id) throws DaoException;

    public void update(Trabalhador trabalhador) throws DaoException;

    public List<Trabalhador> findAll() throws DaoException;

    public Optional<Trabalhador> findById(int id) throws DaoException;

    public List<Trabalhador> findByNome(String nome) throws DaoException;

    public List<Trabalhador> findByCargo(String cargo) throws DaoException;

    public List<Trabalhador> findByCentroDeTrabalho(String centrodetrabalho) throws DaoException;

}
