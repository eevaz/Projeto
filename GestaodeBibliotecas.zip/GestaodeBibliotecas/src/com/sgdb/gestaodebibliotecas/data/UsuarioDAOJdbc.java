/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import java.sql.*;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Usuario;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public class UsuarioDAOJdbc implements UsuarioDAO {

    @Override
    public void add(Usuario usuario) throws DaoException {
        String sql = "insert into Usuario(ID, TipoUsuario)"
                + "values(?, ?)";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);) {
            pstmt.setInt(1, usuario.getUsuarioID());
            pstmt.setString(2, usuario.getTipoUsuario());
            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
//            if (rs.next()) {
//                int idd = rs.getInt(1);
//                usuario.setUsuarioID(idd);
//            }
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    //---------------------------------------------------------------
    @Override
    public void remove(int id) throws DaoException {
        String sqlUsuario = """
                                delete from estudante 
                                where UsuarioID = ?
                                
                            delete from trabalhador 
                             where UsuarioID = ?
                            
                                delete from Usuario
                                 where ID = ?
                                """;
//            String sqlEstudante ="delete from Estudante "
//                + "where ID = ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sqlUsuario);) {
            //deletar na tabela usuario
            pstmt.setInt(1, id);
            pstmt.setInt(2, id);
            pstmt.setInt(3, id);
            pstmt.executeUpdate();

            //deletar na tabela estudante
//            pstmtEstudante.setInt(1,id );
//            pstmtEstudante.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//    PreparedStatement pstmtEstudante = conn.prepareStatement(sqlEstudante);

    //---------------------------------------------------------------
    @Override
    public void update(Usuario usuario) throws DaoException {
          String sql = "update Usuario set TipoUsuario = ? "
                + "where ID = ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, usuario.getTipoUsuario());
            pstmt.setInt(2, usuario.getUsuarioID());
            pstmt.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }

    //---------------------------------------------------------------
    @Override
    public List<Usuario> findAll() throws DaoException {
        String sql = "SELECT ID, TipoUsuario FROM Usuario ";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Usuario> listaUsuario = new ArrayList<>();
                while (rs.next()) {
                    Usuario usuario = new Usuario();
                    usuario.setUsuarioID(rs.getInt("ID"));
                    usuario.setTipoUsuario(rs.getString("TipoUsuario"));
                    listaUsuario.add(usuario);
                }
                return listaUsuario;
            }
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
 //---------------------------------------------------------------
}
