/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;
import java.sql.*;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Categoria;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public class CategoriaDAOJdbc implements CategoriaDAO{

    @Override
    public List<Categoria> findAll() throws DaoException {
       String sql = "select * from Categoria";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Categoria> listaCategoria = new ArrayList<>();
                while (rs.next()) {
                    Categoria categoria = new Categoria();
                    categoria.setNomeCategoria(rs.getString("Nome"));
                              listaCategoria.add(categoria);
                }
                return listaCategoria;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
}
