/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Notificacao;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author user
 */
public interface NotificacaoDAO {
    public List<Notificacao> findAll() throws DaoException;
    
    public void update(Notificacao notificacao) throws DaoException;
    
     public void add(Notificacao notificacao) throws DaoException;
     
     public void remove(int ID) throws DaoException;
     
     public Optional<Notificacao> findById(int id) throws DaoException;
     
     public List<Notificacao> findByTipoNotificacao(String tiponotificacao) throws DaoException;
     
     public List<Notificacao> findByDataNotificacao(LocalDate datanotificacao) throws DaoException;
}
