/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.data;

import java.sql.*;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Artigo;
import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public class ArtigoDAOJdbc implements ArtigoDAO {

    @Override
    public void add(Artigo artigo) throws DaoException {

        String sqlPublicacao = " insert into Publicacao(ISBN, Tipo)"
                + "values(?, 'Artigo')";

        String sqlArtigo = "INSERT INTO Artigo (ISBN, Categoria, Titulo, AnoPublicacao, Arbitro, N_Exemplar, N_Exemplar_Emprestado)"
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmtPublicacao = conn.prepareStatement(sqlPublicacao); PreparedStatement pstmtArtigo = conn.prepareStatement(sqlArtigo, Statement.RETURN_GENERATED_KEYS);) {

            // Inserção na tabela "Publicacao"
            pstmtPublicacao.setString(1, artigo.getISBN());
            pstmtPublicacao.executeUpdate();

            // Inserção na tabela "Artigo"
            pstmtArtigo.setString(1, artigo.getISBN());
            pstmtArtigo.setString(2, artigo.getCategoria());
            pstmtArtigo.setString(3, artigo.getTitulo());
            pstmtArtigo.setInt(4, artigo.getAnoPublicacao());
            pstmtArtigo.setString(5, artigo.getArbitro());
            pstmtArtigo.setInt(6, artigo.getNumero_exemplar());
            pstmtArtigo.setInt(7, artigo.getNumero_exemplar_emprestado());
            pstmtArtigo.executeUpdate();

//            ResultSet rsLivro = pstmtLivro.getGeneratedKeys();
//            if (rsLivro.next()) {
//                String isbn = rsLivro.getString(1);
//                livro.setISBN(isbn);
//
////                int idd1 = rsEstudante.getInt(2);
////                estudante.setUsuarioID(idd1);
//            }
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public void removeAll(String ISBN) throws DaoException {
        String sqlArtigo = """
                                 delete from Artigo 
                                  where ISBN = ?
                                 
                                 delete from Publicacao
                                   where ISBN = ?
                                 """;

        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmtArtigo = conn.prepareStatement(sqlArtigo);) {

//            //deletar na tabela Artigo
            pstmtArtigo.setString(1, ISBN);
            //deletar na tabela Publicacao
            pstmtArtigo.setString(2, ISBN);
            pstmtArtigo.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public void update(Artigo artigo) throws DaoException {
        String sql = "update Artigo set Categoria = ?, Titulo = ?, AnoPublicacao = ?, Arbitro = ?, N_Exemplar = ?, N_Exemplar_Emprestado = ? "
                + "where ISBN = ?";
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            pstmt.setString(1, artigo.getCategoria());
            pstmt.setString(2, artigo.getTitulo());
            pstmt.setInt(3, artigo.getAnoPublicacao());
            pstmt.setString(4, artigo.getArbitro());
            pstmt.setInt(5, artigo.getNumero_exemplar());
            pstmt.setInt(6, artigo.getNumero_exemplar_emprestado());
            pstmt.setString(7, artigo.getISBN());
            pstmt.executeUpdate();

            conn.commit();
        } catch (SQLException ex) {
            throw new DaoException(ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Artigo> findAll() throws DaoException {
        String sql = """
                     select a.isbn, a.Categoria, a.titulo, a.AnoPublicacao, a.Arbitro, a.n_exemplar, a.n_exemplar_emprestado from  artigo a
                    order by a.CategoriaID asc """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Artigo> listaArtigo = new ArrayList<>();
                while (rs.next()) {
                    Artigo artigo = new Artigo();
                    artigo.setISBN(rs.getString("ISBN"));
                    artigo.setCategoria(rs.getString("Categoria"));
                    artigo.setTitulo(rs.getString("Titulo"));
                    artigo.setAnoPublicacao(rs.getInt("AnoPublicacao"));
                    artigo.setArbitro(rs.getString("Arbitro"));
                    artigo.setNumero_exemplar(rs.getInt("N_Exemplar"));
                    artigo.setNumero_exemplar_emprestado(rs.getInt("N_Exemplar_Emprestado"));

                    listaArtigo.add(artigo);
                }
                return listaArtigo;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Artigo> findByISBN(String isbn) throws DaoException {
         String sql = """
                      select a.isbn, a.Categoria, a.titulo, a.AnoPublicacao, a.Arbitro, a.n_exemplar, a.n_exemplar_emprestado from  artigo a
                      where a.isbn like ? 
                      order by a.CategoriaID asc 
                                """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
           pstmt.setString(1, isbn + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Artigo> listaArtigo = new ArrayList<>();
                while (rs.next()) {
                    Artigo artigo = new Artigo();
                    artigo.setISBN(rs.getString("ISBN"));
                    artigo.setCategoria(rs.getString("Categoria"));
                    artigo.setTitulo(rs.getString("Titulo"));
                    artigo.setAnoPublicacao(rs.getInt("AnoPublicacao"));
                    artigo.setArbitro(rs.getString("Arbitro"));
                    artigo.setNumero_exemplar(rs.getInt("N_Exemplar"));
                    artigo.setNumero_exemplar_emprestado(rs.getInt("N_Exemplar_Emprestado"));

                    listaArtigo.add(artigo);
                }
                return listaArtigo;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------


    @Override
    public List<Artigo> findByTitulo(String titulo) throws DaoException {
         String sql = """
                     select a.isbn, a.Categoria, a.titulo, a.AnoPublicacao, a.Arbitro, a.n_exemplar, a.n_exemplar_emprestado from  artigo a
                     where a.titulo like ? 
                     order by a.CategoriaID asc 
                    """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
           pstmt.setString(1, titulo + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Artigo> listaArtigo = new ArrayList<>();
                while (rs.next()) {
                      Artigo artigo = new Artigo();
                    artigo.setISBN(rs.getString("ISBN"));
                    artigo.setCategoria(rs.getString("Categoria"));
                    artigo.setTitulo(rs.getString("Titulo"));
                    artigo.setAnoPublicacao(rs.getInt("AnoPublicacao"));
                    artigo.setArbitro(rs.getString("Arbitro"));
                    artigo.setNumero_exemplar(rs.getInt("N_Exemplar"));
                    artigo.setNumero_exemplar_emprestado(rs.getInt("N_Exemplar_Emprestado"));

                    listaArtigo.add(artigo);
                }
                return listaArtigo;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Artigo> findByArbitro(String arbitro) throws DaoException {
     String sql = """
                     select a.isbn, a.Categoria, a.titulo, a.AnoPublicacao, a.Arbitro, a.n_exemplar, a.n_exemplar_emprestado from  artigo a
                     where a.Arbitro like ? 
                     order by a.CategoriaID asc 
                    """;
        try (Connection conn = JDBCUtil.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
           pstmt.setString(1, arbitro + "%");
            try (ResultSet rs = pstmt.executeQuery();) {
                List<Artigo> listaArtigo = new ArrayList<>();
                while (rs.next()) {
                     Artigo artigo = new Artigo();
                    artigo.setISBN(rs.getString("ISBN"));
                    artigo.setCategoria(rs.getString("Categoria"));
                    artigo.setTitulo(rs.getString("Titulo"));
                    artigo.setAnoPublicacao(rs.getInt("AnoPublicacao"));
                    artigo.setArbitro(rs.getString("Arbitro"));
                    artigo.setNumero_exemplar(rs.getInt("N_Exemplar"));
                    artigo.setNumero_exemplar_emprestado(rs.getInt("N_Exemplar_Emprestado"));

                    listaArtigo.add(artigo);
                }
                return listaArtigo;
            }
        } catch (SQLException ex) {
//            throw new DaoException(ex);
        }
        return null;
    }
//---------------------------------------------------------------------------------
}

