/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas;

import com.sgdb.gestaodebibliotecas.utils.JDBCUtil;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import static javafx.application.Application.launch;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.stage.Stage;

/**
 *
 * @author EDSON VAZ
 */
public class GestaodeBibliotecasFXMain extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException {
        
        //Login 
         Parent root = FXMLLoader.load(getClass().getResource("vistas/LoginVistas.fxml"));//caminho onde se encontra o arquivo //
        Scene scene = new Scene(root);
        primaryStage.setTitle("Página Login");
        primaryStage.setScene(scene);
        primaryStage.show();


//compilar para GERIR PUBLIACOES
//                
//        Parent root = FXMLLoader.load(getClass().getResource("vistas/ListarComecoVistas.fxml"));//caminho onde se encontra o arquivo //
//        Scene scene = new Scene(root);
//        primaryStage.setTitle("Pagina Começo");
//        primaryStage.setScene(scene);
//        primaryStage.show();
//        
//          Parent root = FXMLLoader.load(getClass().getResource("vistas/ListarEmprestimoVistas.fxml"));//caminho onde se encontra o arquivo //
//        Scene scene = new Scene(root);
//        primaryStage.setTitle("Listar Emprestimo");
//        primaryStage.setScene(scene);
//        primaryStage.show();
    }
          /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {

            JDBCUtil.getConnection();
            System.out.println("Conectado com a base de dados");

            //DriverManager é uma classe; getConnection é um método estático
        } catch (SQLException ex) {
            System.out.println("Erro na conexao com a base de dados");
            Logger.getLogger(GestaodeBibliotecasFXMain.class.getName()).log(Level.SEVERE, null, ex);

        }
        launch(args);
    }

}
                     
                
                
                
                
//        Parent root =FXMLLoader.load(getClass().getResource( "vistas/ListarPublicacaoVistas.fxml"));
//        Scene scene = new Scene(root);
//        primaryStage.setTitle("Lista de Publicacao");
//        primaryStage.setScene(scene);
//        primaryStage.show();


//compilar para GERIR LIVROS
// Parent root = FXMLLoader.load(getClass().getResource("vistas/ListarLivroVistas.fxml"));//caminho onde se encontra o arquivo //
////        Scene scene = new Scene(root);
////        primaryStage.setTitle("Lista de Livro");
////        primaryStage.setScene(scene);
////        primaryStage.show();



//                compilar para GERIR Artigo
//        Parent root = FXMLLoader.load(getClass().getResource("vistas/ListarRevistaVistas.fxml"));//caminho onde se encontra o arquivo //
//        Scene scene = new Scene(root);
//        primaryStage.setTitle("Lista de Revista");
//        primaryStage.setScene(scene);
//        primaryStage.show();

//                //compilar para GERIR ESTUDANTES
//        Parent root = FXMLLoader.load(getClass().getResource("vistas/ListarEstudanteVistas.fxml"));//caminho onde se encontra o arquivo //
//        Scene scene = new Scene(root);
//        primaryStage.setTitle("Lista de Estudante");
//        primaryStage.setScene(scene);
//        primaryStage.show();
    
////    
////              compilar para GERIR TRABALHADORES
//        Parent root = FXMLLoader.load(getClass().getResource("vistas/ListarTrabalhadorVistas.fxml"));//caminho onde se encontra o arquivo //
//        Scene scene = new Scene(root);
//        primaryStage.setTitle("Lista de Trabalhador");
//        primaryStage.setScene(scene);
//        primaryStage.show();
   
    
