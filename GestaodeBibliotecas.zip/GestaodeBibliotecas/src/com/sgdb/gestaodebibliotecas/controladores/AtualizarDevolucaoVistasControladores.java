/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.DevolucaoDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Devolucao;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AtualizarDevolucaoVistasControladores implements Initializable {

    private Devolucao devolucao;

    @FXML
    private DatePicker txtDataDevolucao;

    @FXML
    private TextField txtEmprestimoID;

    
     public void setDevolucao(Devolucao devolucao) {
        this.devolucao = devolucao;
        txtEmprestimoID.setText(Integer.toString(devolucao.getEmprestimoID()));
        txtDataDevolucao.setValue(devolucao.getDataDevolucao());
     }
     
     public void onActionAceitar(ActionEvent event) throws DaoException {
    // Verificação de campos vazios
    if ( txtEmprestimoID.getText().isEmpty()) {
        // Exibir mensagem de aviso informando que algum campo está vazio
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Campos vazios");
        alert.setContentText("Preencha todos os campos antes de aceitar.");
        alert.showAndWait();
        return;
    }

    // Verificação de números inteiros

    boolean isEmprestimoIDValido = true;

    int emprestimoID = 0;

    try {
        emprestimoID = Integer.parseInt(txtEmprestimoID.getText());
    } catch (NumberFormatException e) {
        isEmprestimoIDValido = false;
    }

    // Verificar a validade dos campos individualmente
    if ( !isEmprestimoIDValido) {
        // Exibir mensagem de alerta informando que os campos estão inválidos
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Valores inválidos");
        alert.setContentText("Os campos ID e Empréstimo ID devem conter números inteiros.");
        alert.showAndWait();
        return;
    } else {
        if (!isEmprestimoIDValido) {
            // Exibir mensagem de alerta informando que o campo Empréstimo ID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo Empréstimo ID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }
    }

    // Verificar se houve alguma alteração nos dados antes de atualizar
boolean isAtualizacaoSucesso = false;

// Verificar se algum dado da devolução foi alterado
if (devolucao.getEmprestimoID() != emprestimoID || !devolucao.getDataDevolucao().equals(txtDataDevolucao.getValue())) {
    // Atualizar os dados da devolução
    DevolucaoDAOJdbc devolva = new DevolucaoDAOJdbc();
    devolucao.setEmprestimoID(emprestimoID);
    devolucao.setDataDevolucao(txtDataDevolucao.getValue());
    devolva.update(devolucao);

    isAtualizacaoSucesso = true;
}

    // Exibir mensagem de sucesso ou informação
    if (isAtualizacaoSucesso) {
        // Exibir mensagem de atualização da devolução com sucesso
        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
        successAlert.setTitle("Sucesso");
        successAlert.setHeaderText(null);
        successAlert.setContentText("Atualização da devolução realizada com sucesso!");
        successAlert.showAndWait();
    } else {
        // Exibir mensagem informando que nenhum dado foi atualizado
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informação");
        alert.setHeaderText(null);
        alert.setContentText("Nenhum dado da devolução foi atualizado.");
        alert.showAndWait();
    }

    // Fechar a janela atual
    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    stage.close();
}

    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma publicacao que nao quer adicionar  
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
