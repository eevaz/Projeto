/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.LivroDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Livro;
import com.sgdb.gestaodebibliotecas.service.ILivroService;
import com.sgdb.gestaodebibliotecas.service.LivroService;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
//Listar um Livro-------------------------------------------------------------------------------
public class ListarLivroVistasControladores implements Initializable {

    @FXML
    private ImageView livro2;

//    private final ObservableList<Livro> listaLivro = FXCollections.observableArrayList();
    @FXML
    private TableView<Livro> tblListaLivro;

    @FXML
    private TableColumn<Livro, String> isbnColumn;

    @FXML
    private TableColumn<Livro, String> categoriaColumn;

    @FXML
    private TableColumn<Livro, String> tituloColumn;

    @FXML
    private TableColumn<Livro, Integer> anopublicacaoColumn;

    @FXML
    private TableColumn<Livro, String> editoraColumn;

    @FXML
    private TableColumn<Livro, String> autorColumn;

    @FXML
    private TableColumn<Livro, Integer> numeroexemplarColumn;

    @FXML
    private TableColumn<Livro, Integer> numeroexemplaremprestadoColumn;

    @FXML
    private RadioButton rbAutor;

    @FXML
    private RadioButton rbISBN;

    @FXML
    private RadioButton rbTitulo;

    @FXML
    private RadioButton rbTodos;
    
    @FXML
    private TextField txtBuscar;

    //------------------------------------------------------------------------------------
    private ObservableList<Livro> listaLivro;

    private final List<Livro> oldListaLivro = new ArrayList<>();

    private final List<Livro> toRemoveListaLivro = new ArrayList<>();

    private ILivroService livroService;

    public void handleRadioButtonAction() {
        txtBuscar.clear();
    }

//    @FXML
//    private TableColumn<Livro, String> tipoColumn;
    //------------------------------------------------------------------------------------
//Buscar um Livro-------------------------------------------------------------------------------
    public void handleBuscarLivroButtonAction() {
        try {
            listaLivro.clear();
            if (rbTodos.isSelected()) {
                txtBuscar.clear();
                oldListaLivro.clear();
                listaLivro.setAll(livroService.findAll());
                oldListaLivro.addAll(listaLivro);
            } else if (!txtBuscar.getText().isBlank()) {
                if (rbISBN.isSelected()) {
                    listaLivro.setAll(livroService.findByISBN(txtBuscar.getText()));
                } else if (rbTitulo.isSelected()) {
                    listaLivro.setAll(livroService.findByTitulo(txtBuscar.getText()));
                } else if (rbAutor.isSelected())  { 
                    listaLivro.setAll(livroService.findByAutor(txtBuscar.getText()));
                } 
            }
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando o livro", ex.getMessage());
        }
    }


//Adicionar um Livro-------------------------------------------------------------------------------
    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AdicionarLivroVistas.fxml"));
        Parent root = loader.load();
        AdicionarLivroVistasControladores controller = loader.getController();
        controller.setListaLivro(listaLivro);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Adicionar Um Livro");
        stage.setScene(scene);
        stage.showAndWait();

    }

    //eliminar um Livro-------------------------------------------------------------------------------
    public void onActionExcluir() {
        if (tblListaLivro.getSelectionModel().isEmpty()) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro ao excluir o livro", "Selecione o livro que desejas eliminar");
        } else {
            Livro livroSelecionado = tblListaLivro.getSelectionModel().getSelectedItem();

            try {
                livroService.removeAll(livroSelecionado.getISBN());

                listaLivro.remove(livroSelecionado);
                toRemoveListaLivro.add(livroSelecionado);

                showAlertMessage(Alert.AlertType.INFORMATION, "Sucesso",
                        "Livro excluído", " O Livro foi excluído com sucesso");
            } catch (ServiceException ex) {
                showAlertMessage(Alert.AlertType.ERROR, "Erro",
                        "Erro ao excluir  o Livro", ex.getMessage());
            }
        }
    }

    //Atualizar um Livro-------------------------------------------------------------------------------
    public void onActionAtualizar() throws IOException {
        if (tblListaLivro.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona Livro que deseja Atualizar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AtualizarLivroVistas.fxml"));
            Parent root = loader.load();
            AtualizarLivroVistasControladores controller = loader.getController();
            Livro livro = tblListaLivro.getSelectionModel().getSelectedItem();
            controller.setLivro(livro);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Atualizar Um Livro");
            stage.setScene(scene);
            stage.showAndWait();
        }
    }

    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarPublicacaoVistas.fxml"));
        Parent root = loader.load();
        ListarPublicacaoVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de publicacoes");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    //----------------------------------------------------------------------------
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

//        //------------Permite aparecer dados na tabela de lista Livro--------------------
        livroService = new LivroService(new LivroDAOJdbc());
        listaLivro = FXCollections.emptyObservableList();
        try {
            listaLivro = FXCollections.observableList(livroService.findAll());
            oldListaLivro.addAll(listaLivro);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os livros", ex.getMessage());
        }

        isbnColumn.setCellValueFactory(new PropertyValueFactory<>("ISBN"));
        categoriaColumn.setCellValueFactory(new PropertyValueFactory<>("Categoria"));
        tituloColumn.setCellValueFactory(new PropertyValueFactory<>("Titulo"));
        anopublicacaoColumn.setCellValueFactory(new PropertyValueFactory<>("AnoPublicacao"));
        editoraColumn.setCellValueFactory(new PropertyValueFactory<>("Editora"));
        autorColumn.setCellValueFactory(new PropertyValueFactory<>("Autor"));
        numeroexemplarColumn.setCellValueFactory(new PropertyValueFactory<>("Numero_exemplar"));
        numeroexemplaremprestadoColumn.setCellValueFactory(new PropertyValueFactory<>("Numero_exemplar_emprestado"));
        tblListaLivro.setItems(listaLivro);

        //--------IMAGENS-----------------------
        String imag2Path = "../vistas/Livrol.jpg"; // Especifique o caminho correto da imagem

        Image liv2 = new Image(getClass().getResourceAsStream(imag2Path));
        livro2.setImage(liv2);
        //-------------------------------
    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }
}

//        
////        //------------Permite aparecer dados na tabela de lista Estudante--------------------
//        estudanteService = new EstudanteService(new EstudanteDAOJdbc());
//        listaEstudante = FXCollections.emptyObservableList();
//        try {
//            listaEstudante = FXCollections.observableList(estudanteService.findAll());
//            oldListaEstudante.addAll(listaEstudante);
//        } catch (ServiceException ex) {
//            showAlertMessage(Alert.AlertType.ERROR, "Erro",
//                    "Erro carregando os estudantes", ex.getMessage());
//        }
//        
//        idColumn.setCellValueFactory(new PropertyValueFactory<Estudante, Integer>("ID"));
//        usuarioidColumn.setCellValueFactory(new PropertyValueFactory<>("UsuarioID"));
//        nomeColumn.setCellValueFactory(new PropertyValueFactory<>("Nome"));
//        nomeescolaColumn.setCellValueFactory(new PropertyValueFactory<>("NomeDaEscola"));
//        emailColumn.setCellValueFactory(new PropertyValueFactory<>("Email"));
//        telefoneColumn.setCellValueFactory(new PropertyValueFactory<>("Telefone"));
//        moradaColumn.setCellValueFactory(new PropertyValueFactory<>("Morada"));
//        cniColumn.setCellValueFactory(new PropertyValueFactory<>("CNI"));
//        tblListaEstudante.setItems(listaEstudante);
// 
//        populateListaLivro();
//        isbnColumn.setCellValueFactory(new PropertyValueFactory<Livro, String>("ISBN"));
//        categoriaColumn.setCellValueFactory(new PropertyValueFactory("Categoria"));
//        tituloColumn.setCellValueFactory(new PropertyValueFactory("Titulo"));
//        anopublicacaoColumn.setCellValueFactory(new PropertyValueFactory("AnoPublicacao"));
//        editoraColumn.setCellValueFactory(new PropertyValueFactory("Editora"));
//        autorColumn.setCellValueFactory(new PropertyValueFactory("Autor"));
//        numeroexemplarColumn.setCellValueFactory(new PropertyValueFactory("Numero_exemplar"));
//        numeroexemplaremprestadoColumn.setCellValueFactory(new PropertyValueFactory("Numero_exemplar_emprestado"));
//        tipoColumn.setCellValueFactory(new PropertyValueFactory("Tipo"));
//
//        tblListaLivro.setItems(listaLivro);
//        tblListaLivro.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//    }
//
//    ----------------------------------------------------------------------------
//    private void populateListaLivro() {
//
//        listaLivro.add(new Livro("9788535920400", "Generalidades", "O Poder do Hábito", 2012, "Objetiva", "Charles Duhigg", 11, 2, "Livro"));
//        listaLivro.add(new Livro("9788530939755", "Filosofia", "O Mundo de Sofia", 1995, "Companhia das Letras", "Jostein Gaarder", 11, 3, "Livro"));
//        listaLivro.add(new Livro("9788573256139", "Religião", "O Monge e o Executivo", 2004, "Sextante", "James C. Hunter", 11, 0, "Livro"));
//        listaLivro.add(new Livro("9788535921063", "Ciências Sociais", "Sapiens: Uma Breve História da Humanidade", 2015, "L&PM Editores", "Yuval Noah Harari", 11, 2, "Livro"));
//        listaLivro.add(new Livro("9788535932820", "Filologia", "1984", 1949, "Companhia das Letras", "George Orwell", 11, 2, "Livro"));
//        listaLivro.add(new Livro("9788533936642", "Ciências naturais", "Uma Breve História do Tempo", 1988, "Intrínseca", "Stephen Hawking", 11, 0, "Livro"));
//        listaLivro.add(new Livro("9788525066262", "Ciências Técnicas e Práticas", "O Ponto da Virada", 2000, "Cultrix", "Malcolm Gladwell", 11, 0, "Livro"));
//        listaLivro.add(new Livro("9788539004116", "Arte e Literatura", "Dom Quixote", 1605, "Zahar", "Miguel de Cervantes", 11, 0, "Livro"));
//        listaLivro.add(new Livro("9788556510170", "História", "1491: Uma Nova História da América Antes de Colombo", 2005, "Objetiva", "Charles C. Mann", 11, 0, "Livro"));
//
//      
//
//
//    }

