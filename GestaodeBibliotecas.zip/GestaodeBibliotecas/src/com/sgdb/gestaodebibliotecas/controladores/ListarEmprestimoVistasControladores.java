/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.EmprestimoDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Emprestimo;
import com.sgdb.gestaodebibliotecas.service.EmprestimoService;
import com.sgdb.gestaodebibliotecas.service.IEmprestimoService;
import java.io.IOException;
import java.time.LocalDate;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
//Listar um Emprestimo------------------------------------------------------------------------------
public class ListarEmprestimoVistasControladores implements Initializable {

    private ObservableList<Emprestimo> listaEmprestimo;//= FXCollections.observableArrayList();

    private final List<Emprestimo> oldListaEmprestimo = new ArrayList<>();

    private final List<Emprestimo> toRemoveListaEmprestimo = new ArrayList<>();

    private IEmprestimoService emprestimoService;

    @FXML
    private RadioButton rbdataempestimo;

    @FXML
    private RadioButton rbId;

    @FXML
    private RadioButton rbTodos;

    @FXML
    private TextField txtBuscar;

    @FXML
    private DatePicker dtpBuscar;

    @FXML
    private TableView<Emprestimo> tblListaEmprestimo;

    @FXML
    private TableColumn<Emprestimo, Integer> idColumn;

    @FXML
    private TableColumn<Emprestimo, Integer> usuarioidColumn;

    @FXML
    private TableColumn<Emprestimo, String> publicacaoisbnColumn;

    @FXML
    private TableColumn<Emprestimo, LocalDate> dataemprestimoColumn;

    @FXML
    private TableColumn<Emprestimo, LocalDate> datadevolucaoColumn;

    public void handleRadioButtonAction() {
        txtBuscar.clear();
        dtpBuscar.setValue(null);
        
    }
    

//    @FXML
//    private TableColumn<Estudante, String> tipousuarioColumn;
    //------------------------------------------------------------------------------------
    public void handleBuscarEmprestimoButtonAction() {
        try {
            listaEmprestimo.clear();
            if (rbTodos.isSelected()) {
                txtBuscar.clear();
                oldListaEmprestimo.clear();
                listaEmprestimo.setAll(emprestimoService.findAll());
                oldListaEmprestimo.addAll(listaEmprestimo);
            } else if (rbdataempestimo.isSelected()) {

                LocalDate data = dtpBuscar.getValue();

                Optional<Emprestimo> OptionaEmprestimo = emprestimoService.findByDataEmprestimo(data);

                if (OptionaEmprestimo.isPresent()) {

                    listaEmprestimo.add(OptionaEmprestimo.get());

                }

            } else {
                int id = Integer.parseInt(txtBuscar.getText());
                Optional<Emprestimo> optionalEmprestimo = emprestimoService.findById(id);
                optionalEmprestimo.ifPresent((emprestimo) -> {
                    listaEmprestimo.add(emprestimo);

                });
            }
        } catch (NumberFormatException ex) {
            String mssg = "O valor inserido não tem o formato correto";
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando um Emprestimo", mssg);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando um Emprestimo", ex.getMessage());
        }

    }

    //Adicionar um Estudante-------------------------------------------------------------------------------
    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AdicionarEmprestimoVistas.fxml"));
        Parent root = loader.load();
        AdicionarEmprestimoVistasControladores controller = loader.getController();
        controller.setListaEmprestimo(listaEmprestimo);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Registar um Emprestimo");
        stage.setScene(scene);
        stage.showAndWait();

    }

    //eliminar um Estudante-------------------------------------------------------------------------------
    public void onActionExcluir() {
        if (tblListaEmprestimo.getSelectionModel().isEmpty()) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro ao excluir o Emprestimo", "Selecione um Emprestimo que deseja eliminar");
        } else {
            Emprestimo emprestimoSelecionado = tblListaEmprestimo.getSelectionModel().getSelectedItem();

            try {
                emprestimoService.remove(emprestimoSelecionado.getID());

                listaEmprestimo.remove(emprestimoSelecionado);
                toRemoveListaEmprestimo.add(emprestimoSelecionado);

                showAlertMessage(Alert.AlertType.INFORMATION, "Sucesso",
                        "Emprestimo excluído", "O Emprestimo foi excluído com sucesso");
            } catch (ServiceException ex) {
                showAlertMessage(Alert.AlertType.ERROR, "Erro",
                        "Erro ao excluir o Emprestimo", ex.getMessage());
            }
        }
    }

    //Atualizar um Emprestimo-------------------------------------------------------------------------------
    public void onActionAtualizar() throws IOException {
        if (tblListaEmprestimo.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona o Emprestimo que deseja Atualizar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AtualizarEmprestimoVistas.fxml"));
            Parent root = loader.load();
            AtualizarEmprestimoVistasControladores controller = loader.getController();
            Emprestimo emprestimo = tblListaEmprestimo.getSelectionModel().getSelectedItem();
            controller.setEmprestimo(emprestimo);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Atualizar Emprestimo Registado");
            stage.setScene(scene);
            stage.showAndWait();
        }

    }

    //----------------------------------------------------------------------------
    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarInicialVistas.fxml"));
        Parent root = loader.load();
        ListarInicialVistasControladores controller = loader.getController();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Pagina Inicial");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    /**
     *
     *
     *
     *
     *
     *
     *
     *  * Initializes the controller class.
     */
    @Override
    @SuppressWarnings("unchecked")
    public void initialize(URL url, ResourceBundle rb) {

        //------------Permite aparecer dados na tabela de lista Funcionarios--------------------
        emprestimoService = new EmprestimoService(new EmprestimoDAOJdbc());
        listaEmprestimo = FXCollections.emptyObservableList();
        try {
            listaEmprestimo = FXCollections.observableList(emprestimoService.findAll());
            oldListaEmprestimo.addAll(listaEmprestimo);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os Emprestimos", ex.getMessage());
        }

        idColumn.setCellValueFactory(new PropertyValueFactory<>("ID"));
        usuarioidColumn.setCellValueFactory(new PropertyValueFactory("UsuarioID"));
        publicacaoisbnColumn.setCellValueFactory(new PropertyValueFactory("PublicacaoISBN"));
        dataemprestimoColumn.setCellValueFactory(new PropertyValueFactory("DataEmprestimo"));
        datadevolucaoColumn.setCellValueFactory(new PropertyValueFactory("DataDevolucao"));
        tblListaEmprestimo.setItems(listaEmprestimo);
        tblListaEmprestimo.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }
//        tipousuarioColumn.setCellValueFactory(new PropertyValueFactory("TipoUsuario"));
}
