/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.DevolucaoDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Devolucao;
import com.sgdb.gestaodebibliotecas.modelo.Emprestimo;
import com.sgdb.gestaodebibliotecas.service.DevolucaoService;
import com.sgdb.gestaodebibliotecas.service.IDevolucaoService;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ListarDevolucaoVistasControladores implements Initializable {

    private ObservableList<Devolucao> listaDevolucao;//= FXCollections.observableArrayList();

    private final List<Devolucao> oldListaDevolucao = new ArrayList<>();

    private final List<Devolucao> toRemoveListaEmprestimo = new ArrayList<>();

   

    @FXML
    private RadioButton rbId;

    @FXML
    private RadioButton rbTodos;

    @FXML
    private TextField txtBuscar;

    @FXML
    private TableColumn<Devolucao, LocalDate> datadevolucaoColumn;

    @FXML
    private TableColumn<Devolucao, Integer> emprestimoidColumn;

    @FXML
    private TableColumn<Devolucao, Integer> idColumn;

    @FXML
    private TableView<Devolucao> tblListaDevolucao;
    
    private IDevolucaoService devolucaoService;

    public void handleRadioButtonAction() {
        txtBuscar.clear();
    }

    public void handleBuscarDevolucaoButtonAction() {
        try {
            listaDevolucao.clear();
            if (rbTodos.isSelected()) {
                txtBuscar.clear();
                oldListaDevolucao.clear();
                listaDevolucao.setAll(devolucaoService.findAll());
                oldListaDevolucao.addAll(listaDevolucao);
            } else {
                int id = Integer.parseInt(txtBuscar.getText());
                Optional<Devolucao> optionalDevolucao = devolucaoService.findById(id);
                optionalDevolucao.ifPresent((devolucao) -> {
                    listaDevolucao.add(devolucao);

                });
            }
        } catch (NumberFormatException ex) {
            String mssg = "O valor inserido não tem o formato correto";
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando Devolucao", mssg);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando Devolucao", ex.getMessage());
        }

    }

    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AdicionarDevolucaoVistas.fxml"));
        Parent root = loader.load();
        AdicionarDevolucaoVistasControladores controller = loader.getController();
        controller.setListaDevolucao(listaDevolucao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Dados da Devolucao ");
        stage.setScene(scene);
        stage.showAndWait();

    }

    //Atualizar uma Devolucao-------------------------------------------------------------------------------
    public void onActionAtualizar() throws IOException {
        if (tblListaDevolucao.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona Devolucao que deseja Atualizar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AtualizarDevolucaoVistas.fxml"));
            Parent root = loader.load();
            AtualizarDevolucaoVistasControladores controller = loader.getController();
            Devolucao devolucao = tblListaDevolucao.getSelectionModel().getSelectedItem();
            controller.setDevolucao(devolucao);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Dados da Devolucao");
            stage.setScene(scene);
            stage.showAndWait();
        }
    }

    public void onActionExcluir() throws DaoException {
       if (tblListaDevolucao.getSelectionModel().isEmpty()) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro ao excluir a Devolucao", "Selecione uma Devolucao que desejas eliminar");
        } else {
            Devolucao devolucaoSelecionado = tblListaDevolucao.getSelectionModel().getSelectedItem();

            try {
                devolucaoService.remove(devolucaoSelecionado.getID());
                listaDevolucao.remove(devolucaoSelecionado);
                toRemoveListaEmprestimo.add(devolucaoSelecionado);

                showAlertMessage(Alert.AlertType.INFORMATION, "Sucesso",
                        "Devolucao excluído", "A Devolucao foi excluído com sucesso");
            } catch (ServiceException ex) {
                showAlertMessage(Alert.AlertType.ERROR, "Erro",
                        "Erro ao excluir a Devolucao", ex.getMessage());
            }
        }
    }

    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarInicialVistas.fxml"));
        Parent root = loader.load();
        ListarInicialVistasControladores controller = loader.getController();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Pagina Inicial");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 0
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        //------------Permite aparecer dados na tabela de lista Funcionarios--------------------
        devolucaoService = new DevolucaoService(new DevolucaoDAOJdbc());
        listaDevolucao = FXCollections.emptyObservableList();
        try {
            listaDevolucao = FXCollections.observableList(devolucaoService.findAll());
            oldListaDevolucao.addAll(listaDevolucao);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando as devolucoes", ex.getMessage());
        }
        // TODO
        idColumn.setCellValueFactory(new PropertyValueFactory<>("ID"));
        emprestimoidColumn.setCellValueFactory(new PropertyValueFactory<>("EmprestimoID"));
        datadevolucaoColumn.setCellValueFactory(new PropertyValueFactory<>("DataDevolucao"));

        tblListaDevolucao.setItems(listaDevolucao);
        tblListaDevolucao.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }

}
