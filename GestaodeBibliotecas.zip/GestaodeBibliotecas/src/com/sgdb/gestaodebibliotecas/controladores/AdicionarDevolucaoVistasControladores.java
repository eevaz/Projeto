/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.DevolucaoDAO;
import com.sgdb.gestaodebibliotecas.data.DevolucaoDAOJdbc;
import com.sgdb.gestaodebibliotecas.data.EmprestimoDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Devolucao;
import com.sgdb.gestaodebibliotecas.modelo.Emprestimo;
import com.sgdb.gestaodebibliotecas.modelo.Multa;
import com.sgdb.gestaodebibliotecas.service.DevolucaoService;
import com.sgdb.gestaodebibliotecas.service.EmprestimoService;
import com.sgdb.gestaodebibliotecas.service.IDevolucaoService;
import com.sgdb.gestaodebibliotecas.service.IEmprestimoService;
import com.sgdb.gestaodebibliotecas.service.IMultaService;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AdicionarDevolucaoVistasControladores implements Initializable {

    private ObservableList<Devolucao> listaDevolucao;

    @FXML
    private DatePicker txtDataDevolucao;

    @FXML
    private TextField txtEmprestimoID;

    public void setListaDevolucao(ObservableList<Devolucao> listaDevolucao) {
        this.listaDevolucao = listaDevolucao;
    }

    private final List<Devolucao> oldListaDevolucao = new ArrayList<>();

    private final List<Integer> listaDevolucaoExistente = new ArrayList<>();

    private IDevolucaoService devolucaoService;
    //-----------------------------------------
    
        private ObservableList<Emprestimo> listaEmprestimo;

    private final List<Emprestimo> oldListaEmprestimo = new ArrayList<>();

    private final List<Integer> listaEmprestimoExistente = new ArrayList<>();

    private IEmprestimoService emprestimoService;

    //-----------------------------------------
    public void onActionAceitar(ActionEvent event) throws DaoException {
        boolean isEmprestimoIdValid = true;


        int emprestimoID = 0;


        if (txtEmprestimoID.getText().isEmpty()||txtDataDevolucao.getValue()==null) {
            // Exibir mensagem de aviso informando que algum campo está vazio
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha todos os campos antes de aceitar.");
            alert.showAndWait();
            return;
        }
        
        

        try {
            emprestimoID = Integer.parseInt(txtEmprestimoID.getText());
        } catch (NumberFormatException e) {
            isEmprestimoIdValid = false;
        }

        // Verificar a validade dos campos individualmente
        if (!isEmprestimoIdValid) {
            // Exibir mensagem de alerta informando que ambos os campos estão inválidos
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valores inválidos");
            alert.setContentText("O campo EmpréstimoID deve conter números inteiros.");
            alert.showAndWait();
            return;
        } else if (!isEmprestimoIdValid) {
            // Exibir mensagem de alerta informando que o campo EmpréstimoID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo EmpréstimoID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }
// Verificar se a Emprestimo com o ID informado existe
              boolean devolucaoExiste = listaDevolucaoExistente.contains(emprestimoID);
              if(!devolucaoExiste){
              boolean emprestimoExiste = listaEmprestimoExistente.contains(emprestimoID);
           if (emprestimoExiste){
                // Emprestimo com este ID informado nao existe
        // Adicionar a devolução apenas se os campos forem válidos
        DevolucaoDAOJdbc devolve = new DevolucaoDAOJdbc();
        Devolucao devolucao = new Devolucao();
        devolucao.setEmprestimoID(emprestimoID);
        devolucao.setDataDevolucao(txtDataDevolucao.getValue());
        listaDevolucao.add(devolucao);
        devolve.add(devolucao);

        // Exibir mensagem de Adição de Devolução com sucesso
        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
        successAlert.setTitle("Sucesso");
        successAlert.setHeaderText(null);
        successAlert.setContentText("Registo de devolução realizada com sucesso!");
        successAlert.showAndWait();
        
        } else {
            // Emprestimo já Existe
            // Exibir mensagem de alerta informando que o Emprestimo foi encontrado e que este ID existe
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("ID do Emprestimo nao existe");
            alert.setContentText("Nenhum Emprestimo com este ID informado foi efetuado antes. Só podes Registar a Devolução com ID de Empréstimo que já foi efetuado antes. Introduza um outro ID e tente novamente.");
            alert.showAndWait();
            return;
        }
           
              } else {
            // Emprestimo já Existe
            // Exibir mensagem de alerta informando que o Emprestimo foi encontrado e que este ID existe
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("ID do Emprestimo ja existe");
            alert.setContentText("A devolucao com este EmprestimoID informado já existe. Introduza um outro ID e tente novamente.");
            alert.showAndWait();
            return;
        }
           
             

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para fechar a tela depois de aceitar uma devolução que se quer adicionar
    }

    //        Node source = (Node) event.getSource();
//        Scene scene = source.getScene();
//        Stage stage = (Stage)scene.getWindow();
    //        Node source = (Node) event.getSource();
//        Scene scene = source.getScene();
//        Stage stage = (Stage)scene.getWindow();
    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma 1 que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        populateListaDevolucaoExistente();
        populateListaEmprestimoExistente();
        // TODO
    }
       private void populateListaDevolucaoExistente() {
    //------------Permite aparecer dados na tabela de lista Funcionarios--------------------
        devolucaoService = new DevolucaoService(new DevolucaoDAOJdbc());
        listaDevolucao = FXCollections.emptyObservableList();
        try {
            listaDevolucao = FXCollections.observableList(devolucaoService.findAll());
            oldListaDevolucao.addAll(listaDevolucao);

            // Preencher a lista de Publicacoes existentes com os ISBN
            for (Devolucao devolucao : listaDevolucao) {
                listaDevolucaoExistente.add(devolucao.getEmprestimoID());
            }
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando as Devolucao", ex.getMessage());
        }
        
    }
       
        private void populateListaEmprestimoExistente() {

        //------------Permite aparecer dados na tabela de lista Funcionarios--------------------
        emprestimoService = new EmprestimoService(new EmprestimoDAOJdbc());
        listaEmprestimo = FXCollections.emptyObservableList();
        try {
            listaEmprestimo = FXCollections.observableList(emprestimoService.findAll());
            oldListaEmprestimo.addAll(listaEmprestimo);

            // Preencher a lista de Publicacoes existentes com os ISBN
            for (Emprestimo emprestimo : listaEmprestimo) {
                listaEmprestimoExistente.add(emprestimo.getID());
            }
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os Emprestimos", ex.getMessage());
        }
        
    }

            private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }
}
