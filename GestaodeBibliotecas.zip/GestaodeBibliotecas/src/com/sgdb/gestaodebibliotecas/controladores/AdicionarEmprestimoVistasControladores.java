/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.EmprestimoDAO;
import com.sgdb.gestaodebibliotecas.data.EmprestimoDAOJdbc;
import com.sgdb.gestaodebibliotecas.data.PublicacaoDAOJdbc;
import com.sgdb.gestaodebibliotecas.data.UsuarioDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Emprestimo;
import com.sgdb.gestaodebibliotecas.modelo.Publicacao;
import com.sgdb.gestaodebibliotecas.modelo.Usuario;
import com.sgdb.gestaodebibliotecas.service.EmprestimoService;
import com.sgdb.gestaodebibliotecas.service.IEmprestimoService;
import com.sgdb.gestaodebibliotecas.service.IPublicacaoService;
import com.sgdb.gestaodebibliotecas.service.IUsuarioService;
import com.sgdb.gestaodebibliotecas.service.PublicacaoService;
import com.sgdb.gestaodebibliotecas.service.UsuarioService;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AdicionarEmprestimoVistasControladores implements Initializable {

    private ObservableList<Emprestimo> listaEmprestimo;

    @FXML
    private DatePicker txtDataDevolucao;

    @FXML
    private DatePicker txtDataEmprestimo;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtPublicacaoISBN;

    @FXML
    private TextField txtUsuarioID;

    public void setListaEmprestimo(ObservableList<Emprestimo> listaEmprestimo) {
        this.listaEmprestimo = listaEmprestimo;
    }

    private final List<Emprestimo> oldListaEmprestimo = new ArrayList<>();

    private final List<Integer> listaEmprestimoExistente = new ArrayList<>();

    private IEmprestimoService emprestimoService;
    //-----------------------------------------

    private ObservableList<Usuario> listaUsuario;

    private final List<Usuario> oldListaUsuario = new ArrayList<>();

    private final List<Integer> listaUsuarioExistente = new ArrayList<>();

    private IUsuarioService usuarioService;

//-----------------------------------------
     private ObservableList<Publicacao> listaPublicacao;

    private final List<Publicacao> oldListaPublicacao = new ArrayList<>();
    
    private final List<String> listaPublicacaoExistente = new ArrayList<>();

        private IPublicacaoService publicacaoService;
    //----------------------------------------------------------
    //acao para aceitar um emprestimo que se quer adicionar
    public void onActionAceitar(ActionEvent event) throws DaoException {
        boolean isIdValid = true;
        boolean isUsuarioIdValid = true;
        boolean isPublicacaoISBNIdValid = true;

        int id = 0;
        int usuarioID = 0;
        String publicacaoISBN = null;

        if (txtID.getText().isEmpty() || txtUsuarioID.getText().isEmpty() || txtPublicacaoISBN.getText().isEmpty()|| txtDataEmprestimo.getValue() == null || txtDataDevolucao.getValue() == null) {
            // Exibir mensagem de aviso informando que algum campo está vazio
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha todos os campos antes de aceitar.");
            alert.showAndWait();
            return;
        }

        try {
            id = (Integer.parseInt(txtID.getText()));
        } catch (NumberFormatException e) {
            isIdValid = false;
        }

        try {
            usuarioID = (Integer.parseInt(txtUsuarioID.getText()));
        } catch (NumberFormatException e) {
            isUsuarioIdValid = false;
        }

        try {
            publicacaoISBN = (txtPublicacaoISBN.getText());
        } catch (NumberFormatException e) {
            isPublicacaoISBNIdValid = false;
        }

        // Verificar a validade dos campos individualmente
        if (!isIdValid && !isUsuarioIdValid && !isPublicacaoISBNIdValid) {
            // Exibir mensagem de alerta informando que todos os campos estão inválidos
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valores inválidos");
            alert.setContentText("Os campos ID, UsuarioID e PublicacaoISBN devem conter números inteiros.");
            alert.showAndWait();
            return;
        } else if (!isIdValid) {
            // Exibir mensagem de alerta informando que o campo ID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo ID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isUsuarioIdValid) {
            // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo UsuarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isPublicacaoISBNIdValid) {
            // Exibir mensagem de alerta informando que o campo PublicacaoISBN está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo PublicacaoISBN deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }
        // Verificar se a Emprestimo com o ID informado existe
        boolean emprestimoExiste = listaEmprestimoExistente.contains(id);
       
        if (!emprestimoExiste) {
                // Emprestimo com este ID informado nao existe
        
            // Verificar se o usuário com o UsuarioID informado existe
             boolean usuarioExiste = listaUsuarioExistente.contains(usuarioID);
             if(usuarioExiste){
                 
             
             // Verificar se a Publicacao com o ISBN informado existe
            boolean publicacaoExiste = listaPublicacaoExistente.contains(publicacaoISBN);
            if (publicacaoExiste) {
    
                 
            // Adicionar o empréstimo apenas se os campos forem válidos
            EmprestimoDAOJdbc empresta = new EmprestimoDAOJdbc();
            Emprestimo emprestimo = new Emprestimo();
            emprestimo.setID(id);
            emprestimo.setUsuarioID(usuarioID);
            emprestimo.setPublicacaoISBN(publicacaoISBN);
            emprestimo.setDataEmprestimo(txtDataEmprestimo.getValue());
            emprestimo.setDataDevolucao(txtDataDevolucao.getValue());
            listaEmprestimo.add(emprestimo);
            empresta.add(emprestimo);

            // Exibir mensagem de registro de empréstimo com sucesso
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Sucesso");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Registro de empréstimo realizado com sucesso!");
            successAlert.showAndWait();
            
            
            } else {
                // Publicacao  não Existe
                // Exibir mensagem de alerta informando que A Publicacao foi encontrado e que este isbn existe
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText("ISBN da Publicacão não existe");
                alert.setContentText("A Publicacão com este ISBN informado não existe. Crie um novo ISBN ou utilize o ISBN que já existe tente novamente");
                alert.showAndWait();
                return;
            }

            
            } else {
                // Usuário  não Existe
                // Exibir mensagem de alerta informando que o usuário NAO foi encontrado e que este id  não existe
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText("ID de Usuário não existe");
                alert.setContentText("O usuário com este UsuarioID informado não existe.  Crie um novo UsuarioID ou utilize o UsuarioId que já existe tente novamente.");
                alert.showAndWait();
                return;
            }
             
             
             
        } else {
            // Emprestimo já Existe
            // Exibir mensagem de alerta informando que o Emprestimo foi encontrado e que este ID existe
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("ID do Emprestimo Já existe");
            alert.setContentText("O Emprestimo com este ID informado já existe. Introduza um outro ID e tente novamente.");
            alert.showAndWait();
            return;
        }
             
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    //----------------------------------------------------------
    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma 1 que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        populateListaEmprestimoExistente();
        populateListaUsuarioExistente();
      populateListaPublicacoExistente();
    }

    private void populateListaEmprestimoExistente() {

        //------------Permite aparecer dados na tabela de lista Funcionarios--------------------
        emprestimoService = new EmprestimoService(new EmprestimoDAOJdbc());
        listaEmprestimo = FXCollections.emptyObservableList();
        try {
            listaEmprestimo = FXCollections.observableList(emprestimoService.findAll());
            oldListaEmprestimo.addAll(listaEmprestimo);

            // Preencher a lista de Publicacoes existentes com os ISBN
            for (Emprestimo emprestimo : listaEmprestimo) {
                listaEmprestimoExistente.add(emprestimo.getID());
            }
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os Emprestimos", ex.getMessage());
        }
        
    }

    private void populateListaUsuarioExistente() {
        usuarioService = new UsuarioService(new UsuarioDAOJdbc());
        listaUsuario = FXCollections.emptyObservableList();
        try {
            listaUsuario = FXCollections.observableList(usuarioService.findAll());
            oldListaUsuario.addAll(listaUsuario);

            // Preencher a lista de usuários existentes com os IDs
            for (Usuario usuario : listaUsuario) {
                listaUsuarioExistente.add(usuario.getUsuarioID());
            }

        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os usuários", ex.getMessage());

        }
        
        
    }
    
    private void populateListaPublicacoExistente() {
        //------------Permite aparecer dados na tabela de lista Livro--------------------
        publicacaoService = new PublicacaoService(new PublicacaoDAOJdbc());
        listaPublicacao = FXCollections.emptyObservableList();
        try {
            listaPublicacao = FXCollections.observableList(publicacaoService.findAll());
            oldListaPublicacao.addAll(listaPublicacao);
//------------------------------------------------------------
            // Preencher a lista de Publicacoes existentes com os ISBN
            for (Publicacao publicacao : listaPublicacao) {
                listaPublicacaoExistente.add(publicacao.getISBN());
            }
                
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando as Publicacoes", ex.getMessage());
        }
 }
 //------------------------------------------------------------------------           
     

//         listaUsuarioExistente.add(new Usuario(2001, "João Silva", "joao.silva@gmail.com", "Estudante"));
//        listaUsuarioExistente.add(new Usuario(2002, "Maria Santos", "maria.santos@gmail.com", "Estudante"));
//        listaUsuarioExistente.add(new Usuario(2003, "Pedro Almeida", "pedro.almeida@gmail.com", "Estudante"));
//        listaUsuarioExistente.add(new Usuario(2004, "Ana Oliveira", "ana.oliveira@gmail.com", "Estudante"));
//        listaUsuarioExistente.add(new Usuario(2005, "Rafaela Costa", "rafaela.costa@gmail.com", "Estudante"));
//        listaUsuarioExistente.add(new Usuario(2006, "Daniel Pereira", "daniel.pereira@gmail.com", "Estudante"));
//        listaUsuarioExistente.add(new Usuario(2007, "Carolina Santos", "carolina.santos@gmail.com", "Estudante"));
//        listaUsuarioExistente.add(new Usuario(2008, "Guilherme Ferreira", "guilherme.ferreira@gmail.com", "Estudante"));
//        listaUsuarioExistente.add(new Usuario(2009, "Lúcia Sousa", "lucia.sousa@gmail.com", "Estudante"));
//        listaUsuarioExistente.add(new Usuario(2010, "Fernando Mendes", "fernando.mendes@gmail.com", "Estudante"));
//        listaUsuarioExistente.add(new Usuario(2011, "André Costa", "andre.costa@gmail.com", "Trabalhador"));
//        listaUsuarioExistente.add(new Usuario(2012, "Mariana Santos", "mariana.santos@gmail.com", "Trabalhador"));
//        listaUsuarioExistente.add(new Usuario(2013, "Ricardo Pereira", "ricardo.pereira@gmail.com", "Trabalhador"));
//        listaUsuarioExistente.add(new Usuario(2014, "Sofia Fernandes", "sofia.fernandes@gmail.com", "Trabalhador"));
//        listaUsuarioExistente.add(new Usuario(2015, "Gustavo Silva", "gustavo.silva@gmail.com", "Trabalhador"));
//         listaUsuarioExistente.add(new Usuario(2016, "Isabel Santos", "isabel.santos@gmail.com", "Trabalhador"));
//        // TODO
    

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }

}
