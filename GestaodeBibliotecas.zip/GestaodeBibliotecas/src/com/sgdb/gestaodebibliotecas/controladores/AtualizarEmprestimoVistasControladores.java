/*
/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.EmprestimoDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Emprestimo;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AtualizarEmprestimoVistasControladores implements Initializable {
    
    private Emprestimo emprestimo;
    
     private ObservableList<Emprestimo> listaEmprestimo;

    @FXML
    private DatePicker txtDataDevolucao;

    @FXML
    private DatePicker txtDataEmprestimo;
    
    @FXML
    private TextField txtID;
    
    @FXML
    private TextField txtPublicacaoISBN;
    
    @FXML
    private TextField txtUsuarioID;
    
    public void setEmprestimo(Emprestimo emprestimo) {
        this.emprestimo = emprestimo;
        txtID.setText(Integer.toString(emprestimo.getID()));
        txtUsuarioID.setText(Integer.toString(emprestimo.getUsuarioID()));
        txtPublicacaoISBN.setText(emprestimo.getPublicacaoISBN());
        txtDataEmprestimo.setValue(emprestimo.getDataEmprestimo());
        txtDataDevolucao.setValue(emprestimo.getDataDevolucao());
        
    }

    //----------------------------------------------------------
    public void onActionAceitar(ActionEvent event) throws DaoException {
        boolean isIdValid = true;
        boolean isUsuarioIdValid = true;
        boolean isAtualizacaoSucesso = false;
        
        int id = 0;
        int usuarioID = 0;
        
        if (txtID.getText().isEmpty() || txtUsuarioID.getText().isEmpty() || txtPublicacaoISBN.getText().isEmpty() || txtDataEmprestimo.getValue() == null || txtDataDevolucao.getValue() == null) {
            // Exibir mensagem de aviso informando que algum campo está vazio
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha todos os campos antes de aceitar.");
            alert.showAndWait();
            return;
        }
        
        try {
            id = Integer.parseInt(txtID.getText());
        } catch (NumberFormatException e) {
            isIdValid = false;
        }
        
        try {
            usuarioID = Integer.parseInt(txtUsuarioID.getText());
        } catch (NumberFormatException e) {
            isUsuarioIdValid = false;
        }

        // Verificar a validade dos campos individualmente
        if (!isIdValid && !isUsuarioIdValid) {
            // Exibir mensagem de alerta informando que ambos os campos estão inválidos
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valores inválidos");
            alert.setContentText("Os campos ID e UsuarioID devem conter números inteiros.");
            alert.showAndWait();
            return;
        } else if (!isIdValid) {
            // Exibir mensagem de alerta informando que o campo ID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo ID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isUsuarioIdValid) {
            // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo UsuarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

        //emprestimo.getID() != id || emprestimo.getUsuarioID() != usuarioID no objeto do tipo int se usa o == para comparar nao se usa iquals()que é para objeto do tipo string
        // Verificar se houve alguma alteração nos dados antes de atualizar
        if (!emprestimo.getDataEmprestimo().equals(txtDataEmprestimo.getValue()) || !emprestimo.getDataDevolucao().equals(txtDataDevolucao.getValue())) {
            // Atualizar os dados do empréstimo
            EmprestimoDAOJdbc empresta = new EmprestimoDAOJdbc();
            emprestimo.setDataEmprestimo(txtDataEmprestimo.getValue());
            emprestimo.setDataDevolucao(txtDataDevolucao.getValue());
            empresta.update(emprestimo);
            isAtualizacaoSucesso = true;
        }
        
        if (isAtualizacaoSucesso) {
            // Exibir mensagem de atualização de empréstimo com sucesso
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Sucesso");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Atualização de empréstimo realizado com sucesso!");
            successAlert.showAndWait();
        } else {
            // Exibir mensagem informando que nenhum dado foi atualizado
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Informação");
            alert.setHeaderText(null);
            alert.setContentText("Nenhum dado de empéstimo foi atualizado.");
            alert.showAndWait();
        }
        
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para fechar a tela depois de aceitar um empréstimo que se quer atualizar
    }
    //----------------------------------------------------------

    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma emprestimo que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
    
}
