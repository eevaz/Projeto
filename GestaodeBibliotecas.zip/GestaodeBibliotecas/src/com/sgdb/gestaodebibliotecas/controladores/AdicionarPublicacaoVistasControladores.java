/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.PublicacaoDAOJdbc;
import com.sgdb.gestaodebibliotecas.modelo.Publicacao;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AdicionarPublicacaoVistasControladores implements Initializable {

    private ObservableList<Publicacao> listaPublicacao;

    @FXML
    private TextField txtISBN;

    @FXML
    private TextField txtTipo;

    public void setListaPublicacao(ObservableList<Publicacao> listaPublicacao) {
        this.listaPublicacao = listaPublicacao;
    }

    //acao para aceitar uma publicacao que se quer adicionar
    public void onActionAceitar(ActionEvent event) {
        if (txtISBN.getText().isEmpty() || txtTipo.getText().isEmpty()) {
            // Exibir mensagem de aviso informando que algum campo está vazio
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha todos os campos antes de aceitar.");
            alert.showAndWait();
            return;
        }

        // Adicionar a publicação apenas se os campos forem válidos
        Publicacao publicacao = new Publicacao();
        PublicacaoDAOJdbc p = new PublicacaoDAOJdbc();
        publicacao.setISBN(txtISBN.getText());
        publicacao.setTipo(txtTipo.getText());
        listaPublicacao.add(publicacao);
        p.add(publicacao);
        // Exibir mensagem de Adição de Publicação com sucesso
        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
        successAlert.setTitle("Sucesso");
        successAlert.setHeaderText(null);
        successAlert.setContentText("Adição de Publicação realizado com sucesso!");
        successAlert.showAndWait();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para fechar a tela depois de aceitar uma publicação que se quer adicionar
    }

    //--------------------------------------------------

    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma 1 que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
