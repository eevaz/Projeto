/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.FuncionarioDAOJdbc;
import com.sgdb.gestaodebibliotecas.data.MultaDAOJdbc;
import com.sgdb.gestaodebibliotecas.data.PublicacaoDAOJdbc;
import com.sgdb.gestaodebibliotecas.data.UsuarioDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Funcionario;
import com.sgdb.gestaodebibliotecas.modelo.Multa;
import com.sgdb.gestaodebibliotecas.modelo.Publicacao;
import com.sgdb.gestaodebibliotecas.modelo.Usuario;
import com.sgdb.gestaodebibliotecas.service.FuncionarioService;
import com.sgdb.gestaodebibliotecas.service.IFuncionarioService;
import com.sgdb.gestaodebibliotecas.service.IMultaService;
import com.sgdb.gestaodebibliotecas.service.IPublicacaoService;
import com.sgdb.gestaodebibliotecas.service.IUsuarioService;
import com.sgdb.gestaodebibliotecas.service.MultaService;
import com.sgdb.gestaodebibliotecas.service.PublicacaoService;
import com.sgdb.gestaodebibliotecas.service.UsuarioService;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;


/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AdicionarMultaVistasControladores implements Initializable {

    private ObservableList<Multa> listaMulta;

    @FXML
    private DatePicker txtDataAplicacao;

    @FXML
    private TextField txtFuncionarioID;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtPublicacaoISBN;

    @FXML
    private TextField txtUsuarioID;

    @FXML
    private TextField txtValor;

    public void setListaMulta(ObservableList<Multa> listaMulta) {
        this.listaMulta = listaMulta;
    }
    //-----------------------------------------

    private final List<Multa> oldListaMulta = new ArrayList<>();

    private final List<Integer> listaMultaExistente = new ArrayList<>();

    private IMultaService multaService;

//-----------------------------------------
    private ObservableList<Funcionario> listaFuncionario;

    private final List<Funcionario> oldListaFuncionario = new ArrayList<>();

    private final List<Integer> listaFuncionarioExistente = new ArrayList<>();

    private IFuncionarioService funcionarioService;

//-----------------------------------------
    private ObservableList<Usuario> listaUsuario;

    private final List<Usuario> oldListaUsuario = new ArrayList<>();

    private final List<Integer> listaUsuarioExistente = new ArrayList<>();

    private IUsuarioService usuarioService;

//-----------------------------------------
    private ObservableList<Publicacao> listaPublicacao;

    private final List<Publicacao> oldListaPublicacao = new ArrayList<>();

    private final List<String> listaPublicacaoExistente = new ArrayList<>();

    private IPublicacaoService publicacaoService;
    //----------------------------------------------------------

    //--------------------------------------------------------------
    public void onActionAceitar(ActionEvent event) throws DaoException {
        boolean isUsuarioIdValid = true;
        boolean isIdValid = true;
        boolean isValorValid = true;
        boolean isFuncionarioIdValid = true;
        boolean isPublicacaoISBNIdValid = true;

        int usuarioID = 0;
        int id = 0;
        int valor = 0;
        int funcionarioID = 0;
        String publicacaoISBN = null;

// ...

// Verifica se algum campo está vazio
if (txtUsuarioID.getText().isEmpty() || txtID.getText().isEmpty() || txtValor.getText().isEmpty() || txtFuncionarioID.getText().isEmpty() || txtDataAplicacao.getValue() == null) {
    // Exibir mensagem de aviso informando que algum campo está vazio
    Alert alert = new Alert(Alert.AlertType.WARNING);
    alert.setTitle("Aviso");
    alert.setHeaderText("Campos vazios");
    alert.setContentText("Preencha todos os campos antes de aceitar.");
    alert.showAndWait();
    return;
}

//// Verifica se o campo DataAplicacao está preenchido corretamente
//DateTimeFormatter dateFormatter  = DateTimeFormatter.ofPattern("yyyy-MM-dd");
////DateTimeFormatter dataAplicacao = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//try {
//    LocalDate dataAplicacao = txtDataAplicacao.getValue(); 
//    String dataplicacaoFormatada = dataAplicacao.format(dateFormatter);
//} catch (DateTimeParseException e) {
//    // Exibir mensagem de aviso informando que o formato do campo DataAplicacao está incorreto
//    Alert alert = new Alert(Alert.AlertType.WARNING);
//    alert.setTitle("Aviso");
//    alert.setHeaderText("Formato incorreto");
//    alert.setContentText("O campo DataAplicacao tem formato incorreto, o formato correto da data é dd/MM/yyyy.");
//    alert.showAndWait();
//    return;
//}

//        if (txtUsuarioID.getText().isEmpty() || txtID.getText().isEmpty() || txtValor.getText().isEmpty() || txtFuncionarioID.getText().isEmpty() || txtDataAplicacao.getValue() == null) {
//            // Exibir mensagem de aviso informando que algum campo está vazio
//            Alert alert = new Alert(Alert.AlertType.WARNING);
//            alert.setTitle("Aviso");
//            alert.setHeaderText("Campos vazios");
//            alert.setContentText("Preencha todos os campos antes de aceitar.");
//            alert.showAndWait();
//            return;
//        }
//        else if(txtDataAplicacao.getValue() != null){
//            // Exibir mensagem de aviso informando que campo DataAplicacao tem formato incorreto  está vazio
//            Alert alert = new Alert(Alert.AlertType.WARNING);
//            alert.setTitle("Aviso");
//            alert.setHeaderText("Campo DataAplicacao ");
//            alert.setContentText(" O campo DataAplicacao tem formato incorreto, o formato coreto é dd/MM/YYY.");
//            alert.showAndWait();
//            return;
//        }
//        

        try {
            usuarioID = Integer.parseInt(txtUsuarioID.getText());
        } catch (NumberFormatException e) {
            isUsuarioIdValid = false;
        }

        try {
            id = Integer.parseInt(txtID.getText());
        } catch (NumberFormatException e) {
            isIdValid = false;
        }

        try {
            valor = Integer.parseInt(txtValor.getText());
        } catch (NumberFormatException e) {
            isValorValid = false;
        }

        try {
            funcionarioID = Integer.parseInt(txtFuncionarioID.getText());
        } catch (NumberFormatException e) {
            isFuncionarioIdValid = false;
        }

        try {
            publicacaoISBN = (txtPublicacaoISBN.getText());
        } catch (NumberFormatException e) {
            isPublicacaoISBNIdValid = false;
        }

        // Verificar a validade dos campos individualmente
        if (!isIdValid) {
            // Exibir mensagem de alerta informando que o campo ID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo ID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isValorValid) {
            // Exibir mensagem de alerta informando que o campo Valor está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo Valor deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isFuncionarioIdValid) {
            // Exibir mensagem de alerta informando que o campo FuncionarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo FuncionarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isUsuarioIdValid) {
            // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo UsuarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isPublicacaoISBNIdValid) {
            // Exibir mensagem de alerta informando que o campo PublicacaoISBN está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo PublicacaoISBN deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

        // Verificar se a Multa com o ID informado existe
        boolean multaExiste = listaMultaExistente.contains(id);
        if (!multaExiste) {
            // Multa com este ID informado nao existe

            // Verificar se o Funcionario com o ID informado existe
            boolean funcionarioExiste = listaFuncionarioExistente.contains(funcionarioID);
            if (funcionarioExiste) {

                // Verificar se o usuário com o UsuarioID informado existe
                boolean usuarioExiste = listaUsuarioExistente.contains(usuarioID);
                if (usuarioExiste) {

                    // Verificar se a Publicacao com o ISBN informado existe
                    boolean publicacaoExiste = listaPublicacaoExistente.contains(publicacaoISBN);
                    if (publicacaoExiste) {

                        // Adicionar a multa apenas se os campos forem válidos
                        MultaDAOJdbc multar = new MultaDAOJdbc();
                        Multa multa = new Multa();
                        multa.setUsuarioID(usuarioID);
                        multa.setPublicacaoISBN(txtPublicacaoISBN.getText());
                        multa.setID(id);
                        multa.setValor(valor);
                        multa.setFuncionarioID(funcionarioID);
                        multa.setDataAplicacao(txtDataAplicacao.getValue());
                        listaMulta.add(multa);
                        multar.add(multa);

                        // Exibir mensagem de Adição de Multa com sucesso
                        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                        successAlert.setTitle("Sucesso");
                        successAlert.setHeaderText(null);
                        successAlert.setContentText("Multa aplicado com sucesso!");
                        successAlert.showAndWait();

                    } else {
                        // Publicacao  não Existe
                        // Exibir mensagem de alerta informando que A Publicacao foi encontrado e que este isbn existe
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Aviso");
                        alert.setHeaderText("ISBN da Publicacão não existe");
                        alert.setContentText("A Publicacão com este ISBN informado não existe. Crie um novo ISBN ou utilize o ISBN que já existe e tente novamente");
                        alert.showAndWait();
                        return;
                    }
                } else {
                    // Usuário  não Existe
                    // Exibir mensagem de alerta informando que o usuário NAO foi encontrado e que este id  não existe
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Aviso");
                    alert.setHeaderText("ID de Usuário não existe");
                    alert.setContentText("O usuário com este UsuarioID informado não existe.  Crie um novo UsuarioID ou utilize o UsuarioId que já existe e tente novamente.");
                    alert.showAndWait();
                    return;
                }
            } else {
                // Funcionario não Existe
                // Exibir mensagem de alerta informando que o Funcionario NAO foi encontrado e que este id  não existe
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText("ID de Funcionario não existe");
                alert.setContentText("O Funcionario com este ID informado não existe.  Crie um novo ID ou utilize o ID de Funcionario que já existe e  tente novamente.");
                alert.showAndWait();
                return;
            }

        } else {
            // Multa já Existe
            // Exibir mensagem de alerta informando que a Multa foi encontrado e que este ID existe
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("ID da Multa Já existe");
            alert.setContentText("A Multa com este ID informado já existe. Introduza um outro ID e tente novamente.");
            alert.showAndWait();
            return;
        }

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para fechar a tela depois de aceitar uma multa que se quer adicionar
    }
    //        Node source = (Node) event.getSource();
    //        Scene scene = source.getScene();
    //        Stage stage = (Stage)scene.getWindow();
    //--------------------------------------------------------------

    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma 1 que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        populateListaMultaExistente();
        populateListaFuncionarioExistente();
        populateListaUsuarioExistente();
        populateListaPublicacoExistente();

        // TODO
    }
    //----------------------------------------------------------------------

    private void populateListaMultaExistente() {

        //------------Permite aparecer dados na tabela de lista Funcionarios--------------------
        multaService = new MultaService(new MultaDAOJdbc());
        listaMulta = FXCollections.emptyObservableList();
        try {
            listaMulta = FXCollections.observableList(multaService.findAll());
            oldListaMulta.addAll(listaMulta);

            // Preencher a lista de Publicacoes existentes com os ISBN
            for (Multa multa : listaMulta) {
                listaMultaExistente.add(multa.getID());
            }
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os Emprestimos", ex.getMessage());
        }

    }

    //----------------------------------------------------------------------
    private void populateListaUsuarioExistente() {
        usuarioService = new UsuarioService(new UsuarioDAOJdbc());
        listaUsuario = FXCollections.emptyObservableList();
        try {
            listaUsuario = FXCollections.observableList(usuarioService.findAll());
            oldListaUsuario.addAll(listaUsuario);

            // Preencher a lista de usuários existentes com os IDs
            for (Usuario usuario : listaUsuario) {
                listaUsuarioExistente.add(usuario.getUsuarioID());
            }

        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os usuários", ex.getMessage());

        }

    }

    //----------------------------------------------------------------------
    private void populateListaPublicacoExistente() {
        //------------Permite aparecer dados na tabela de lista Livro--------------------
        publicacaoService = new PublicacaoService(new PublicacaoDAOJdbc());
        listaPublicacao = FXCollections.emptyObservableList();
        try {
            listaPublicacao = FXCollections.observableList(publicacaoService.findAll());
            oldListaPublicacao.addAll(listaPublicacao);
//------------------------------------------------------------
            // Preencher a lista de Publicacoes existentes com os ISBN
            for (Publicacao publicacao : listaPublicacao) {
                listaPublicacaoExistente.add(publicacao.getISBN());
            }

        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando as Publicacoes", ex.getMessage());
        }
    }
    //----------------------------------------------------------------------

    private void populateListaFuncionarioExistente() {
        //------------Permite aparecer dados na tabela de lista Funcionario
        funcionarioService = new FuncionarioService(new FuncionarioDAOJdbc());
        listaFuncionario = FXCollections.emptyObservableList();
        try {
            listaFuncionario = FXCollections.observableList(funcionarioService.findAll());
            oldListaFuncionario.addAll(listaFuncionario);
//------------------------------------------------------------
            // Preencher a lista de Funcionarios existentes com os ID
            for (Funcionario funcionario : listaFuncionario) {
                listaFuncionarioExistente.add(funcionario.getID());
            }

        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os Funcionarios", ex.getMessage());
        }
    }
//----------------------------------------------------------------------

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }
}
