/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.RevistaDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Revista;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class AtualizarRevistaVistasControladores implements Initializable {

    private Revista revista;

    @FXML
    private TextField txtISBN;

    @FXML
    private TextField txtAnoPublicacao;

    @FXML
    private TextField txtCategoria;

    @FXML
    private TextField txtEditora;

    @FXML
    private TextField txtNumero;

    @FXML
    private TextField txtNumeroexemplar;

    @FXML
    private TextField txtNumeroexemplaremprestado;

    @FXML
    private TextField txtTitulo;

    /**
     * @param Revista the publicacao to set
     */
    public void setRevista(Revista revista) {
        this.revista = revista;
        txtISBN.setText(revista.getISBN());
        txtCategoria.setText(revista.getCategoria());
        txtTitulo.setText(revista.getTitulo());
        txtAnoPublicacao.setText(Integer.toString(revista.getAnoPublicacao()));
        txtEditora.setText(revista.getEditora());
        txtNumero.setText(Integer.toString(revista.getNumero()));
        txtNumeroexemplar.setText(Integer.toString(revista.getNumero_exemplar()));
        txtNumeroexemplaremprestado.setText(Integer.toString(revista.getNumero_exemplar_emprestado()));

    }

    public void onActionAceitar(ActionEvent event) throws DaoException {
        // Verificação de campos vazios
        if (txtISBN.getText().isEmpty() || txtCategoria.getText().isEmpty() || txtTitulo.getText().isEmpty() || txtAnoPublicacao.getText().isEmpty() || txtEditora.getText().isEmpty() || txtNumero.getText().isEmpty() || txtNumeroexemplar.getText().isEmpty() || txtNumeroexemplaremprestado.getText().isEmpty()) {
            // Exibir mensagem de aviso informando que algum campo está vazio
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha todos os campos antes de aceitar.");
            alert.showAndWait();
            return;
        }

        // Verificação de números inteiros
        boolean isAnoValido = true;
        boolean isNumeroValido = true;
        boolean isNumeroExemplarValido = true;
        boolean isNumeroExemplarEmprestadoValido = true;

        int anoPublicacao = 0;
        int numero = 0;
        int numeroExemplar = 0;
        int numeroExemplarEmprestado = 0;

        try {
            anoPublicacao = Integer.parseInt(txtAnoPublicacao.getText());
        } catch (NumberFormatException e) {
            isAnoValido = false;
        }

        try {
            numero = Integer.parseInt(txtNumero.getText());
        } catch (NumberFormatException e) {
            isNumeroValido = false;
        }

        try {
            numeroExemplar = Integer.parseInt(txtNumeroexemplar.getText());
        } catch (NumberFormatException e) {
            isNumeroExemplarValido = false;
        }

        try {
            numeroExemplarEmprestado = Integer.parseInt(txtNumeroexemplaremprestado.getText());
        } catch (NumberFormatException e) {
            isNumeroExemplarEmprestadoValido = false;
        }

        // Verificar a validade dos campos individualmente
        if (!isAnoValido && !isNumeroValido && !isNumeroExemplarValido && !isNumeroExemplarEmprestadoValido) {
            // Exibir mensagem de alerta informando que todos os campos estão inválidos
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valores inválidos");
            alert.setContentText("Os campos Ano de Publicação, Número, Número de Exemplar e Número de Exemplar Emprestado devem conter números inteiros.");
            alert.showAndWait();
            return;
        } else {
            if (!isAnoValido) {
                // Exibir mensagem de alerta informando que o campo Ano de Publicação está inválido
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText("Valor inválido");
                alert.setContentText("O campo Ano de Publicação deve conter um número inteiro.");
                alert.showAndWait();
                return;
            }

            if (!isNumeroValido) {
                // Exibir mensagem de alerta informando que o campo Número está inválido
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText("Valor inválido");
                alert.setContentText("O campo Número deve conter um número inteiro.");
                alert.showAndWait();
                return;
            }

            if (!isNumeroExemplarValido) {
                // Exibir mensagem de alerta informando que o campo Número de Exemplar está inválido
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText("Valor inválido");
                alert.setContentText("O campo Número de Exemplar deve conter um número inteiro.");
                alert.showAndWait();
                return;
            }

            if (!isNumeroExemplarEmprestadoValido) {
                // Exibir mensagem de alerta informando que o campo Número de Exemplar Emprestado está inválido
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText("Valor inválido");
                alert.setContentText("O campo Número de Exemplar Emprestado deve conter um número inteiro.");
                alert.showAndWait();
                return;
            }
        }

        // Verificar se houve alguma alteração nos dados antes de atualizar
        boolean isAtualizacaoSucesso = false;

        // Verificar se algum dado da revista foi alterado
        if (!revista.getISBN().equals(txtISBN.getText()) || !revista.getCategoria().equals(txtCategoria.getText()) || !revista.getTitulo().equals(txtTitulo.getText()) || revista.getAnoPublicacao() != anoPublicacao || !revista.getEditora().equals(txtEditora.getText()) || revista.getNumero() != numero || revista.getNumero_exemplar() != numeroExemplar || revista.getNumero_exemplar_emprestado() != numeroExemplarEmprestado) {

            // Atualizar os dados da revista
            RevistaDAOJdbc rev = new RevistaDAOJdbc();
            revista.setISBN(txtISBN.getText());
            revista.setCategoria(txtCategoria.getText());
            revista.setTitulo(txtTitulo.getText());
            revista.setAnoPublicacao(anoPublicacao);
            revista.setEditora(txtEditora.getText());
            revista.setNumero(numero);
            revista.setNumero_exemplar(numeroExemplar);
            revista.setNumero_exemplar_emprestado(numeroExemplarEmprestado);
            rev.update(revista);
            isAtualizacaoSucesso = true;
        }

        // Exibir mensagem de sucesso ou informação
        if (isAtualizacaoSucesso) {
            // Exibir mensagem de atualização da revista com sucesso
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Sucesso");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Atualização da revista realizada com sucesso!");
            successAlert.showAndWait();
        } else {
            // Exibir mensagem informando que nenhum dado foi atualizado
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Informação");
            alert.setHeaderText(null);
            alert.setContentText("Nenhum dado da revista foi atualizado.");
            alert.showAndWait();
        }

        // Fechar a janela atual
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma publicacao que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
