/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.FuncionarioDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Funcionario;
import com.sgdb.gestaodebibliotecas.service.FuncionarioService;
import com.sgdb.gestaodebibliotecas.service.IFuncionarioService;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class ListarFuncionarioVistasControladores implements Initializable {

//Listar uma Funcionario-------------------------------------------------------------------------------
//    private final ObservableList<Funcionario> listaFuncionario = FXCollections.observableArrayList();
    @FXML
    private TableView<Funcionario> tblListaFuncionario;

    @FXML
    private TableColumn<Funcionario, Integer> idColumn;
    @FXML
    private TableColumn<Funcionario, String> nomeColumn;

    @FXML
    private TableColumn<Funcionario, String> cargoColumn;

    @FXML
    private RadioButton rbId;

    @FXML
    private RadioButton rbNome;

    @FXML
    private RadioButton rbCargo;

    @FXML
    private RadioButton rbTodos;
    @FXML
    private TextField txtBuscar;

    //------------------------------------------------------------------------------------
    private ObservableList<Funcionario> listaFuncionario;

    private final List<Funcionario> oldListaFuncionario = new ArrayList<>();

    private final List<Funcionario> toRemoveListaFuncionario = new ArrayList<>();

    private IFuncionarioService funcionarioService;

    public void handleRadioButtonAction() {
        txtBuscar.clear();
    }

    //Buscar um Funcionário-------------------------------------------------------------------------------
    public void handleBuscarFuncionarioButtonAction() {
        try {
            listaFuncionario.clear();
            if (rbTodos.isSelected()) {
                txtBuscar.clear();
                oldListaFuncionario.clear();
                listaFuncionario.setAll(funcionarioService.findAll());
                oldListaFuncionario.addAll(listaFuncionario);
            } else if (!txtBuscar.getText().isBlank()) {
                if (rbNome.isSelected()) {
                    listaFuncionario.setAll(funcionarioService.findByNome(txtBuscar.getText()));
                } else if (rbCargo.isSelected()) {
                    listaFuncionario.setAll(funcionarioService.findByCargo(txtBuscar.getText()));
                } else {
                    int id = Integer.parseInt(txtBuscar.getText());
                    Optional<Funcionario> optionalFuncionario = funcionarioService.findById(id);
                    optionalFuncionario.ifPresent((funcionario) -> {
                        listaFuncionario.add(funcionario);
                    });
                }
            }
        } catch (NumberFormatException ex) {
            String mssg = "O valor inserido não tem o formato correto";
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando um funcionario", mssg);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando um funcionario", ex.getMessage());
        }
    }

//Adicionar um Funcionário-------------------------------------------------------------------------------
    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AdicionarFuncionarioVistas.fxml"));
        Parent root = loader.load();
        AdicionarFuncionarioVistasControladores controller = loader.getController();
        controller.setListaFuncionario(listaFuncionario);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Adicionar Um Funcionario");
        stage.setScene(scene);
        stage.showAndWait();

    }

    //eliminar uma publicacao-------------------------------------------------------------------------------
    public void onActionExcluir() {
        if (tblListaFuncionario.getSelectionModel().isEmpty()) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro ao excluir o funcionário", "Selecione um funcionário que desejas eliminar");
        } else {
            Funcionario funcionarioSelecionado = tblListaFuncionario.getSelectionModel().getSelectedItem();

            try {
                funcionarioService.remove(funcionarioSelecionado.getID());
                listaFuncionario.remove(funcionarioSelecionado);
                toRemoveListaFuncionario.add(funcionarioSelecionado);

                showAlertMessage(Alert.AlertType.INFORMATION, "Sucesso",
                        "Funcionário excluído", "O funcionário foi excluído com sucesso");
            } catch (ServiceException ex) {
                showAlertMessage(Alert.AlertType.ERROR, "Erro",
                        "Erro ao excluir o funcionário", ex.getMessage());
            }
        }
    }

//    public void onActionExcluir() {
//         if (tblListaFuncionario.getSelectionModel().isEmpty()) {
//            showAlertMessage(Alert.AlertType.ERROR, "Error",
//                    "Error excluindo o fornecedor", "Deve selecionar um fornecedor");
//        } else {
//            
//            toRemoveListaFuncionario.add(tblListaFuncionario.getSelectionModel().getSelectedItem());
//            listaFuncionario.remove(tblListaFuncionario.getSelectionModel().getSelectedItem());
//        }
//
//    }
//--------------------------------------------------------------
//        if (tblListaFuncionario.getSelectionModel().getSelectedItems().isEmpty()) {
//            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona o Funcionario que deseja Eliminar ", ButtonType.OK);
//            alert.showAndWait();
//        } else {
//            ObservableList<Funcionario> listaSelecionada = tblListaFuncionario.getSelectionModel().getSelectedItems();
//            listaFuncionario.removeAll(listaSelecionada);             //paga os dados selecionados 
//            //permite apagar mais de que um tuplo /  linha de informacao
//
////        Publicacao publicacaoSelecionado =tblListaPublicacao.getSelectionModel().getSelectedItem();
////        listaPublicacao.remove(publicacaoSelecionado);                                      //paga os dados um a um 
//        }
    //Atualizar uma publicacao-------------------------------------------------------------------------------
    public void onActionAtualizar() throws IOException {
        if (tblListaFuncionario.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona o Funcionario que deseja Atualizar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AtualizarFuncionarioVistas.fxml"));
            Parent root = loader.load();
            AtualizarFuncionarioVistasControladores controller = loader.getController();
            Funcionario funcionario = tblListaFuncionario.getSelectionModel().getSelectedItem();
            controller.setFuncionario(funcionario);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Atualizar Um Funcionario");
            stage.setScene(scene);
            stage.showAndWait();
        }
    }
//    
//    public void handleCancelarButtonAction() {
//        listaFuncionario.clear();
//        listaFuncionario.setAll(oldListaFuncionario);
//        tblListaFuncionario.setDisable(false);
//        btnAdicionar.setDisable(false);
//        toRemoveListaFuncionario.clear();
//    }

    public void onActionVoltar(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarComecoVistas.fxml"));
        Parent root = loader.load();
        ListarComecoVistasControladores controller = loader.getController();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Pagina Começo");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    //----------------------------------------------------------------------------
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

//        //------------Permite aparecer dados na tabela de lista Funcionarios--------------------
        funcionarioService = new FuncionarioService(new FuncionarioDAOJdbc());
        listaFuncionario = FXCollections.emptyObservableList();
        try {
            listaFuncionario = FXCollections.observableList(funcionarioService.findAll());
            oldListaFuncionario.addAll(listaFuncionario);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os funcionarios", ex.getMessage());
        }

        idColumn.setCellValueFactory(new PropertyValueFactory<>("ID"));
        nomeColumn.setCellValueFactory(new PropertyValueFactory<>("Nome"));
        cargoColumn.setCellValueFactory(new PropertyValueFactory<>("Cargo"));
        tblListaFuncionario.setItems(listaFuncionario);

        //--------------------------------
//        tblListaFuncionario.getSelectionModel().selectedItemProperty().addListener((ov, oldValue, newValue) -> {
//            if (oldValue != null) {
//                txtID.clear();
//                txtNome.clear();
//                txtCargo.clear();
//            }
//            if (newValue != null) {
//                txtID.setText(Integer.toString(newValue.getID()));
//                txtNome.setText(newValue.getNome());
//                txtCargo.setText(newValue.getCargo());
//            }
//        });
    }

    //--------------------------------------------------------
//        departamentoService = ServiceManager.getServiceManager().getDepartamentoService();
//        DepartamentoDAOJdbc f = new DepartamentoDAOJdbc();
//        listaDepartamento = FXCollections.observableArrayList();
//        try {
//            listaDepartamento.setAll(f.findAll());
//            oldListDepartamento.addAll(listaDepartamento);
//        } catch (DaoException ex) {
//            Logger.getLogger(FuncaoDepartamentoViewController.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    @Override
//    public void initialize(URL url, ResourceBundle rb) {
//        populateListaFuncionario();
//        idColumn.setCellValueFactory(new PropertyValueFactory<Funcionario, Integer>("ID"));
//        nomeColumn.setCellValueFactory(new PropertyValueFactory("Nome"));
//        cargoColumn.setCellValueFactory(new PropertyValueFactory("Cargo"));
//        tblListaFuncionario.setItems(listaFuncionario);
//        tblListaFuncionario.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//    }
    //----------------------------------------------------------------------------
//    private void populateListaFuncionario() {
//        listaFuncionario.add(new Funcionario(111, "Carlos", "Bibliotecario"));
//    }
//---------------------------------------------------------------------------------------
    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }

}
