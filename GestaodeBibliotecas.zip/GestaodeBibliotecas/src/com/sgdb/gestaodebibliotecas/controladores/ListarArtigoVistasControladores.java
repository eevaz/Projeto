/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.ArtigoDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Artigo;
import com.sgdb.gestaodebibliotecas.service.ArtigoService;
import com.sgdb.gestaodebibliotecas.service.IArtigoService;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class ListarArtigoVistasControladores implements Initializable {

    @FXML
    private ImageView artigoa;
//    private final ObservableList<Artigo> listaArtigo = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Artigo, Integer> isbnColumn;

    @FXML
    private TableColumn<Artigo, String> anoPublicacaoColumn;

    @FXML
    private TableColumn<Artigo, String> categoriaColumn;

    @FXML
    private TableColumn<Artigo, String> arbitroColumn;

    @FXML
    private TableColumn<Artigo, Integer> numeroexemplarColumn;

    @FXML
    private TableColumn<Artigo, Integer> numeroexemplaremprestadoColumn;

    @FXML
    private TableView<Artigo> tblListaArtigo;

    @FXML
    private TableColumn<Artigo, String> tituloColumn;

    @FXML
    private RadioButton rbArbitro;

    @FXML
    private RadioButton rbISBN;

    @FXML
    private RadioButton rbTitulo;

    @FXML
    private RadioButton rbTodos;

    @FXML
    private TextField txtBuscar;

//------------------------------------------------------------------------------------
    private ObservableList<Artigo> listaArtigo;

    private final List<Artigo> oldListaArtigo = new ArrayList<>();

    private final List<Artigo> toRemoveListaArtigo = new ArrayList<>();

    private IArtigoService artigoService;
    
      public void handleRadioButtonAction() {
        txtBuscar.clear();
    }


    //------------------------------------------------------------------------------------
    //Buscar um Artigo-------------------------------------------------------------------------------
    public void handleBuscarArtigoButtonAction() {
        try {
            listaArtigo.clear();
            if (rbTodos.isSelected()) {
                txtBuscar.clear();
                oldListaArtigo.clear();
                listaArtigo.setAll(artigoService.findAll());
                oldListaArtigo.addAll(listaArtigo);
            } else if (!txtBuscar.getText().isBlank()) {
                if (rbISBN.isSelected()) {
                    listaArtigo.setAll(artigoService.findByISBN(txtBuscar.getText()));
                } else if (rbTitulo.isSelected()) {
                    listaArtigo.setAll(artigoService.findByTitulo(txtBuscar.getText()));
                } else if (rbArbitro.isSelected())  { 
                    listaArtigo.setAll(artigoService.findByArbitro(txtBuscar.getText()));
                } 
            }
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando o artigo", ex.getMessage());
        }
    }
//Adicionar um Artigo-------------------------------------------------------------------------------
    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AdicionarArtigoVistas.fxml"));
        Parent root = loader.load();
        AdicionarArtigoVistasControladores controller = loader.getController();
        controller.setListaArtigo(listaArtigo);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Adicionar um Artigo");
        stage.setScene(scene);
        stage.showAndWait();
    }

    //eliminar um Artigo-------------------------------------------------------------------------------
    public void onActionExcluir() {
        if (tblListaArtigo.getSelectionModel().isEmpty()) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro ao excluir o artigo", "Selecione o artigo que desejas eliminar");
        } else {
            Artigo artigoSelecionado = tblListaArtigo.getSelectionModel().getSelectedItem();

            try {
                artigoService.removeAll(artigoSelecionado.getISBN());

                listaArtigo.remove(artigoSelecionado);
                toRemoveListaArtigo.add(artigoSelecionado);

                showAlertMessage(Alert.AlertType.INFORMATION, "Sucesso",
                        "Artigo excluído", " O Artigo foi excluído com sucesso");
            } catch (ServiceException ex) {
                showAlertMessage(Alert.AlertType.ERROR, "Erro",
                        "Erro ao excluir  o Artigo", ex.getMessage());
            }
        }
    }
    //Atualizar um Artigo-------------------------------------------------------------------------------

    public void onActionAtualizar() throws IOException {
        if (tblListaArtigo.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona o Artigo que deseja Atualizar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AtualizarArtigoVistas.fxml"));
            Parent root = loader.load();
            AtualizarArtigoVistasControladores controller = loader.getController();
            Artigo artigo = tblListaArtigo.getSelectionModel().getSelectedItem();
            controller.setArtigo(artigo);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Atualizar um Artigo");
            stage.setScene(scene);
            stage.showAndWait();
        }
    }

    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarPublicacaoVistas.fxml"));
        Parent root = loader.load();
        ListarPublicacaoVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de publicacoes");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        //        //------------Permite aparecer dados na tabela de lista Artigo--------------------
        artigoService = new ArtigoService(new ArtigoDAOJdbc());
        listaArtigo = FXCollections.emptyObservableList();
        try {
            listaArtigo = FXCollections.observableList(artigoService.findAll());
            oldListaArtigo.addAll(listaArtigo);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os artigos", ex.getMessage());
        }

        isbnColumn.setCellValueFactory(new PropertyValueFactory<>("ISBN"));
        categoriaColumn.setCellValueFactory(new PropertyValueFactory<>("Categoria"));
        tituloColumn.setCellValueFactory(new PropertyValueFactory<>("Titulo"));
        anoPublicacaoColumn.setCellValueFactory(new PropertyValueFactory<>("AnoPublicacao"));
        arbitroColumn.setCellValueFactory(new PropertyValueFactory<>("Arbitro"));
        numeroexemplarColumn.setCellValueFactory(new PropertyValueFactory<>("Numero_exemplar"));
        numeroexemplaremprestadoColumn.setCellValueFactory(new PropertyValueFactory<>("Numero_exemplar_emprestado"));
        tblListaArtigo.setItems(listaArtigo);

        //--------IMAGENS-----------------------
        String imag3Path = "../vistas/artigoa.jpg"; // Especifique o caminho correto da imagem

        Image artig = new Image(getClass().getResourceAsStream(imag3Path));
        artigoa.setImage(artig);
        //-------------------------------
    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }

//        tblListaArtigo.setItems(listaArtigo);
//        tblListaArtigo.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//    }
//
//    private void populateListaArtigo() {
//
//listaArtigo.add(new Artigo("9788535944151", "Generalidades", "A Importância da Leitura", 2010, "John Smith",  9, 1, "Tipo","9"));
//listaArtigo.add(new Artigo("9788535944152", "Filosofia", "A Ética do Utilitarismo", 2005, "Jane Doe", 9, 0, "Tipo","9"));
//listaArtigo.add(new Artigo("9788535944153", "Religião", "O Papel da Oração na Vida Espiritual", 2018, "Michael Johnson", 9, 0, "Tipo","9"));
//listaArtigo.add(new Artigo("9788535944154", "Ciências Sociais", "Impacto das Mídias Sociais na Sociedade", 2014, "Emily Davis", 9, 2, "Tipo","9"));
//listaArtigo.add(new Artigo("9788535944155", "Filologia", "Análise Linguística de um Poema Clássico", 2009, "Robert Wilson", 9, 0, "Tipo","9"));
//listaArtigo.add(new Artigo("9788535944156", "Ciências naturais", "A Influência do Clima nas Migrações de Aves", 2016, "Maria Garcia", 9, 0, "Tipo","9"));
//listaArtigo.add(new Artigo("9788535944157", "Ciências Técnicas e Práticas", "Tendências Tecnológicas para o Futuro", 2022, "David Thompson",9, 0, "Tipo","9"));
//listaArtigo.add(new Artigo("9788535944158", "Arte e Literatura", "A Simbologia nas Obras de Shakespeare", 2011, "Samantha Brown", 9, 0, "Tipo","9"));
//listaArtigo.add(new Artigo("9788535944159", "História", "A Revolução Industrial e suas Consequências", 2007, "Daniel Wilson", 9, 0, "Tipo","9"));
}
