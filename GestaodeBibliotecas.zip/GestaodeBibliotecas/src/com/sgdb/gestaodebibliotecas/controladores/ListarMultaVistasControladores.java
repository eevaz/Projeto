/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.MultaDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Multa;
import com.sgdb.gestaodebibliotecas.service.IMultaService;
import com.sgdb.gestaodebibliotecas.service.MultaService;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class ListarMultaVistasControladores implements Initializable {

    @FXML
    private TableColumn<Multa, LocalDate> dataaplicacaoColumn;

    @FXML
    private TableColumn<Multa, Integer> funcionarioidColumn;

    @FXML
    private TableColumn<Multa, Integer> idColumn;

    @FXML
    private TableColumn<Multa, String> publicacaoisbnColumn;

    @FXML
    private TableView<Multa> tblListaMulta;

    @FXML
    private TableColumn<Multa, Integer> usuarioidColumn;

    @FXML
    private TableColumn<Multa, Integer> valorColumn;

    @FXML
    private RadioButton rbId;

    @FXML
    private RadioButton rbTodos;
    
    @FXML
    private TextField txtBuscar;
    
     private ObservableList<Multa> listaMulta; //= FXCollections.observableArrayList();
    
    private final List<Multa> oldListaMulta = new ArrayList<>();

    private final List<Multa> toRemoveListaMulta = new ArrayList<>();
    
    private IMultaService multaService;
    
        public void handleRadioButtonAction() {
        txtBuscar.clear();
    }
        
         public void handleBuscarMultaButtonAction() {
        try {
            listaMulta.clear();
            if (rbTodos.isSelected()) {
                txtBuscar.clear();
                oldListaMulta.clear();
                listaMulta.setAll(multaService.findAll());
                oldListaMulta.addAll(listaMulta);
            } else {
                    int id = Integer.parseInt(txtBuscar.getText());
                    Optional<Multa> optionalMulta = multaService.findById(id);
                    optionalMulta.ifPresent((multa) -> {
                        listaMulta.add(multa);
                    });
                }
            
        } catch (NumberFormatException ex) {
            String mssg = "O valor inserido não tem o formato correto";
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando Multa", mssg);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando  Multa", ex.getMessage());
        }
    }


    //Adicionar uma Multa-------------------------------------------------------------------------------
    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AdicionarMultaVistas.fxml"));
        Parent root = loader.load();
        AdicionarMultaVistasControladores controller = loader.getController();
        controller.setListaMulta(listaMulta);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Adicionar uma Multa");
        stage.setScene(scene);
        stage.showAndWait();
    }

    //eliminar uma Multa-------------------------------------------------------------------------------
    public void onActionExcluir() {
        if (tblListaMulta.getSelectionModel().isEmpty()) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro ao excluir a Multa", "Selecione uma Multa que deseja eliminar");
        } else {
            Multa multaSelecionado = tblListaMulta.getSelectionModel().getSelectedItem();

            try {
                multaService.remove(multaSelecionado.getID());

                listaMulta.remove(multaSelecionado);
                toRemoveListaMulta.add(multaSelecionado);

                showAlertMessage(Alert.AlertType.INFORMATION, "Sucesso",
                        "Multa excluído", "A Multa foi excluído com sucesso");
            } catch (ServiceException ex) {
                showAlertMessage(Alert.AlertType.ERROR, "Erro",
                        "Erro ao excluir o Multa", ex.getMessage());
            }
        }
    }
    //Atualizar um Artigo-------------------------------------------------------------------------------

    public void onActionAtualizar() throws IOException {
        if (tblListaMulta.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona Multa que deseja Atualizar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AtualizarMultaVistas.fxml"));
            Parent root = loader.load();
            AtualizarMultaVistasControladores controller = loader.getController();
            Multa multa = tblListaMulta.getSelectionModel().getSelectedItem();
            controller.setMulta(multa);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Atualizar uma Multa");
            stage.setScene(scene);
            stage.showAndWait();
        }
    }

    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarInicialVistas.fxml"));
        Parent root = loader.load();
        ListarInicialVistasControladores controller = loader.getController();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Pagina Inicial");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        multaService = new MultaService(new MultaDAOJdbc());
        listaMulta = FXCollections.emptyObservableList();
        try {
            listaMulta = FXCollections.observableList(multaService.findAll());
            oldListaMulta.addAll(listaMulta);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando Multa", ex.getMessage());

        }
        idColumn.setCellValueFactory(new PropertyValueFactory<>("ID"));
        valorColumn.setCellValueFactory(new PropertyValueFactory<>("Valor"));
        usuarioidColumn.setCellValueFactory(new PropertyValueFactory<>("UsuarioID"));
        publicacaoisbnColumn.setCellValueFactory(new PropertyValueFactory<>("PublicacaoISBN"));
        funcionarioidColumn.setCellValueFactory(new PropertyValueFactory<>("FuncionarioID"));
        dataaplicacaoColumn.setCellValueFactory(new PropertyValueFactory<>("DataAplicacao"));
        tblListaMulta.setItems(listaMulta);
    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }

}
