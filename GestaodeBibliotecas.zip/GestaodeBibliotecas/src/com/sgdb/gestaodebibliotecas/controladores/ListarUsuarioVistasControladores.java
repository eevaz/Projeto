/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.UsuarioDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Usuario;
import com.sgdb.gestaodebibliotecas.service.IUsuarioService;
import com.sgdb.gestaodebibliotecas.service.UsuarioService;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class ListarUsuarioVistasControladores implements Initializable {

//------------------------------------------------------------------------------
    /**
     * FXML Controller class
     *
     * @author EDSON VAZ
     */
//Listar uma Usuario-------------------------------------------------------------------------------
//    private final ObservableList<Usuario> listaUsuario = FXCollections.observableArrayList();
    @FXML
    private ImageView imgazul;
    @FXML
    private ImageView trab;
    @FXML
    private ImageView estud;

    @FXML
    private TableView<Usuario> tblListaUsuario;

    @FXML
    private TableColumn<Usuario, String> tipousuarioColumn;

    @FXML
    private TableColumn<Usuario, Integer> idColumn;

    private ObservableList<Usuario> listaUsuario;

    private final List<Usuario> oldListaUsuario = new ArrayList<>();

    private final List<Usuario> toRemoveListaUsuario = new ArrayList<>();

    private IUsuarioService usuarioService;

    // apresentar e listar somente Estudantes
    public void onActionListarEstudante(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarEstudanteVistas.fxml"));
        Parent root = loader.load();
        ListarEstudanteVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de Estudantes");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }
    // apresentar e listar somente Trabalhadores

    public void onActionListarTrabalhador(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarTrabalhadorVistas.fxml"));
        Parent root = loader.load();
        ListarTrabalhadorVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de Trabalhadores");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    //Adicionar um usuário-------------------------------------------------------------------------------
    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AdicionarUsuarioVistas.fxml"));
        Parent root = loader.load();
        AdicionarUsuarioVistasControladores controller = loader.getController();
        controller.setListaUsuario(listaUsuario);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Adicionar Um Usuario");
        stage.setScene(scene);
        stage.showAndWait();

    }

    //eliminar um usuario-------------------------------------------------------------------------------
    public void onActionExcluir() {

        if (tblListaUsuario.getSelectionModel().isEmpty()) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro ao excluir o usuário", "Selecione um Usuário que desejas eliminar");
        } else {
            Usuario usuarioSelecionado = tblListaUsuario.getSelectionModel().getSelectedItem();

            try {
                usuarioService.remove(usuarioSelecionado.getUsuarioID());

                listaUsuario.remove(usuarioSelecionado);
                toRemoveListaUsuario.add(usuarioSelecionado);

                showAlertMessage(Alert.AlertType.INFORMATION, "Sucesso",
                        "Usuário excluído", "O usuário foi excluído com sucesso");
            } catch (ServiceException ex) {
                showAlertMessage(Alert.AlertType.ERROR, "Erro",
                        "Erro ao excluir o usuário", ex.getMessage());
            }
        }
    }

//        if (tblListaUsuario.getSelectionModel().getSelectedItems().isEmpty()) {
//            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona o Usuario que deseja Eliminar ", ButtonType.OK);
//            alert.showAndWait();
//        } else {
//            ObservableList<Usuario> listaSelecionada = tblListaUsuario.getSelectionModel().getSelectedItems();
//            listaUsuario.removeAll(listaSelecionada);             //paga os dados selecionados 
//            //permite apagar mais de que um tuplo /  linha de informacao
//
////        Publicacao publicacaoSelecionado =tblListaPublicacao.getSelectionModel().getSelectedItem();
////        listaPublicacao.remove(publicacaoSelecionado);                                      //paga os dados um a um 
//        }
//    }
    //Atualizar uma publicacao-------------------------------------------------------------------------------
    public void onActionAtualizar() throws IOException {
        if (tblListaUsuario.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona o Usuario que deseja Atualizar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AtualizarUsuarioVistas.fxml"));
            Parent root = loader.load();
            AtualizarUsuarioVistasControladores controller = loader.getController();
            Usuario usuario = tblListaUsuario.getSelectionModel().getSelectedItem();
            controller.setUsuario(usuario);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Atualizar Um Usuario");
            stage.setScene(scene);
            stage.showAndWait();
        }
    }

    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarInicialVistas.fxml"));
        Parent root = loader.load();
        ListarInicialVistasControladores controller = loader.getController();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Pagina Inicial");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    //----------------------------------------------------------------------------
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

//        //------------Permite aparecer dados na tabela de lista Usuarios--------------------
        usuarioService = new UsuarioService(new UsuarioDAOJdbc());
        listaUsuario = FXCollections.emptyObservableList();
        try {
            listaUsuario = FXCollections.observableList(usuarioService.findAll());
            oldListaUsuario.addAll(listaUsuario);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os usuários", ex.getMessage());
        }

        idColumn.setCellValueFactory(new PropertyValueFactory<Usuario, Integer>("UsuarioID"));
        tipousuarioColumn.setCellValueFactory(new PropertyValueFactory<>("TipoUsuario"));
        tblListaUsuario.setItems(listaUsuario);

        //---------------------------------------------------------------
//        populateListaUsuario();
//        idColumn.setCellValueFactory(new PropertyValueFactory<Usuario, Integer>("UsuarioID"));
//        tipousuarioColumn.setCellValueFactory(new PropertyValueFactory("TipoUsuario"));
//        tblListaUsuario.setItems(listaUsuario);
//        tblListaUsuario.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        //--------IMAGENS-----------------------
        String imagazuPath = "../vistas/branco.jpg"; // Especifique o caminho correto da imagem
        Image imagea = new Image(getClass().getResourceAsStream(imagazuPath));
        imgazul.setImage(imagea);

        String estud1Path = "../vistas/estud.jpg"; // Especifique o caminho correto da imagem
        Image image = new Image(getClass().getResourceAsStream(estud1Path));
        estud.setImage(image);

        String trab1Path = "../vistas/Trabalhadorr.jpg"; // Especifique o caminho correto da imagem
        Image imageb = new Image(getClass().getResourceAsStream(trab1Path));
        trab.setImage(imageb);

    }

    //----------------------------------------------------------------------------
//    private void populateListaUsuario() {
//        // ISBN de  Livrosadicionados na tabela publicacao
//        listaUsuario.add(new Usuario(2001, "João Silva", "joao.silva@gmail.com", "Estudante"));
//        listaUsuario.add(new Usuario(2002, "Maria Santos", "maria.santos@gmail.com", "Estudante"));
//        listaUsuario.add(new Usuario(2003, "Pedro Almeida", "pedro.almeida@gmail.com", "Estudante"));
//        listaUsuario.add(new Usuario(2004, "Ana Oliveira", "ana.oliveira@gmail.com", "Estudante"));
//        listaUsuario.add(new Usuario(2005, "Rafaela Costa", "rafaela.costa@gmail.com", "Estudante"));
//        listaUsuario.add(new Usuario(2006, "Daniel Pereira", "daniel.pereira@gmail.com", "Estudante"));
//        listaUsuario.add(new Usuario(2007, "Carolina Santos", "carolina.santos@gmail.com", "Estudante"));
//        listaUsuario.add(new Usuario(2008, "Guilherme Ferreira", "guilherme.ferreira@gmail.com", "Estudante"));
//        listaUsuario.add(new Usuario(2009, "Lúcia Sousa", "lucia.sousa@gmail.com", "Estudante"));
//        listaUsuario.add(new Usuario(2010, "Fernando Mendes", "fernando.mendes@gmail.com", "Estudante"));
//        listaUsuario.add(new Usuario(2011, "André Costa", "andre.costa@gmail.com", "Trabalhador"));
//        listaUsuario.add(new Usuario(2012, "Mariana Santos", "mariana.santos@gmail.com", "Trabalhador"));
//        listaUsuario.add(new Usuario(2013, "Ricardo Pereira", "ricardo.pereira@gmail.com", "Trabalhador"));
//        listaUsuario.add(new Usuario(2014, "Sofia Fernandes", "sofia.fernandes@gmail.com", "Trabalhador"));
//        listaUsuario.add(new Usuario(2015, "Gustavo Silva", "gustavo.silva@gmail.com", "Trabalhador"));
//        listaUsuario.add(new Usuario(2016, "Isabel Santos", "isabel.santos@gmail.com", "Trabalhador"));
//
//    }
    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }
}
