/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class LoginVistasControladores implements Initializable {

    @FXML
    private ImageView imglogin;

    @FXML
    private ImageView imglogo;

    @FXML
    private TextField campoUsuario;

    @FXML
    private PasswordField campoSenha;

    @FXML
    public void onActionfazerLogin(ActionEvent event) throws IOException {
        String usuario = campoUsuario.getText();
        String senha = campoSenha.getText();

        // Aqui você deve implementar a lógica de validação das credenciais
        // Exemplo de verificação simples (não seguro, apenas para ilustração):
        if (usuario.equals("Evaz") && senha.equals("2003")) {
            // Se as credenciais estiverem corretas, navegue para a página inicial
//            App.setRoot("PaginaInicial");

            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarComecoVistas.fxml"));
            Parent root = loader.load();
            ListarComecoVistasControladores controller = loader.getController();
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Pagina Começo");
            stage.setScene(scene);
            stage.show();

            // Fechar a tela anterior
            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();
            
        } else if (campoUsuario.getText().isEmpty() || campoSenha.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Informação");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha os respectivos campos para fazer o login.");
            alert.showAndWait();
            
        }else{
             Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText(null);
            alert.setContentText("Credenciais inválidas. Tente novamente");
            alert.showAndWait();
            
            // Caso contrário, exiba uma mensagem de erro ou faça outra ação
            System.out.println("Credenciais invalidas. Tente novamente.");
        }
    }
    
        //Fechar-------------------------------------------------------------------------------
    public void onActionVoltar(ActionEvent event)  {
        
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    currentStage.close(); // serve para fechar uma tela 
    } 

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        String imagePath = "../vistas/imglogin.jpg"; // Especifique o caminho correto da imagem
        Image image = new Image(getClass().getResourceAsStream(imagePath));
        imglogin.setImage(image);

        String image1Path = "../vistas/imglogo.jpg"; // Especifique o caminho correto da imagem
        Image imagee = new Image(getClass().getResourceAsStream(image1Path));
        imglogo.setImage(imagee);

    }

}
