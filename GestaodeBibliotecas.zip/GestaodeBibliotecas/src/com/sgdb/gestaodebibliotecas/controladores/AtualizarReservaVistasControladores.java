/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */ 
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.ReservaDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Reserva;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AtualizarReservaVistasControladores implements Initializable {

    private Reserva reserva;
    

    @FXML
    private DatePicker txtDataReserva;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtPublicacaoISBN;

    @FXML
    private TextField txtUsuarioID;
    
     public void setReserva(Reserva reserva) {
        this.reserva = reserva;
        txtID.setText(Integer.toString(reserva.getID()));
        txtUsuarioID.setText(Integer.toString(reserva.getUsuarioID()));
        txtPublicacaoISBN.setText(reserva.getPublicacaoISBN());
        txtDataReserva.setValue(reserva.getDataReserva());
       
    }
     
     public void onActionAceitar(ActionEvent event) throws DaoException {
         
                 // Verificação de campos vazios
        if ( txtDataReserva.getValue()==null|| txtUsuarioID.getText().isEmpty() || txtPublicacaoISBN.getText().isEmpty()) {
            // Exibir mensagem de aviso informando que algum campo está vazio
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha todos os campos antes de aceitar.");
            alert.showAndWait();
            return;
        }

        // Verificação de números inteiros
        boolean isIDValido = true;
        boolean isUsuarioIDValido = true;

        int ID = 0;
        int usuarioID = 0;

        try {
            ID = Integer.parseInt(txtID.getText());
        } catch (NumberFormatException e) {
            isIDValido = false;
        }

        try {
            usuarioID = Integer.parseInt(txtUsuarioID.getText());
        } catch (NumberFormatException e) {
            isUsuarioIDValido = false;
        }

        // Verificar a validade dos campos individualmente
        if (!isIDValido && !isUsuarioIDValido) {
            // Exibir mensagem de alerta informando que todos os campos estão inválidos
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valores inválidos");
            alert.setContentText("Os campos ID, UsuarioID devem conter números inteiros.");
            alert.showAndWait();
            return;
        } else if (!isIDValido) {
            // Exibir mensagem de alerta informando que o campo ID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo ID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isUsuarioIDValido) {
            // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo UsuarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } 

        // Verificar se houve alguma alteração nos dados antes de atualizar
        boolean isAtualizacaoSucesso = false;

        // Verificar se algum dado da notificação foi alterado
        if (reserva.getID() != ID || reserva.getUsuarioID() != usuarioID || !reserva.getPublicacaoISBN().equals(txtPublicacaoISBN.getText()) || !reserva.getDataReserva().equals(txtDataReserva.getValue())) {
            // Atualizar os dados da notificação
            ReservaDAOJdbc reservar = new ReservaDAOJdbc();
            reserva.setID(ID);
            reserva.setUsuarioID(usuarioID);
            reserva.setPublicacaoISBN(txtPublicacaoISBN.getText());
            reserva.setDataReserva(txtDataReserva.getValue());
            reservar.update(reserva);

            isAtualizacaoSucesso = true;
        }

        // Exibir mensagem de sucesso ou informação
        if (isAtualizacaoSucesso) {
            // Exibir mensagem de atualização da notificação com sucesso
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Sucesso");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Reserva atualizada com sucesso!");
            successAlert.showAndWait();
        } else {
            // Exibir mensagem informando que nenhum dado foi atualizado
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Informação");
            alert.setHeaderText(null);
            alert.setContentText("Nenhum dado da Reserva foi atualizado.\nReserva não foi atualizada");
            alert.showAndWait();
        }

        // Fechar a janela atual
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
  
    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma publicacao que nao quer adicionar  
    }

    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
