/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class ListarInicialVistasControladores implements Initializable {
       @FXML
    private ImageView imagem;

   //gerir Publicacoes-------------------------------------------------------------------------------

public void onActionGerirPublicacoes(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarPublicacaoVistas.fxml"));
        Parent root = loader.load();
        ListarPublicacaoVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de publicacoes");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    currentStage.close(); // serve para fechar uma tela 
    }

   //gerir Usuarios-------------------------------------------------------------------------------

public void onActionGerirUsuarios(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarUsuarioVistas.fxml"));
        Parent root = loader.load();
        ListarUsuarioVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de Usuario");
        stage.setScene(scene);
       stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    currentStage.close(); // serve para fechar uma tela 
    }

 //gerir Emprestimo-------------------------------------------------------------------------------
   public void onActionEmprestimo(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarEmprestimoVistas.fxml"));
        Parent root = loader.load();
        ListarEmprestimoVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Listar Emprestimo");
        stage.setScene(scene);
       stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    currentStage.close(); // serve para fechar uma tela 
    }
   
    //gerir Reserva-------------------------------------------------------------------------------
      public void onActionReserva(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarReservaVistas.fxml"));
        Parent root = loader.load();
        ListarReservaVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de Reserva");
        stage.setScene(scene);
       stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    currentStage.close(); // serve para fechar uma tela 
    }
      
       //gerir Notificacao-------------------------------------------------------------------------------
     public void onActionNotificacao(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarNotificacaoVistas.fxml"));
        Parent root = loader.load();
        ListarNotificacaoVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de Notificacao");
        stage.setScene(scene);
       stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    currentStage.close(); // serve para fechar uma tela 
    }
     
      //gerir Devolucao-------------------------------------------------------------------------------
     public void onActionDevolucao(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarDevolucaoVistas.fxml"));
        Parent root = loader.load();
        ListarDevolucaoVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de Devolucao");
        stage.setScene(scene);
       stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    currentStage.close(); // serve para fechar uma tela 
    }
    
      //gerir Multa-------------------------------------------------------------------------------
     public void onActionMulta(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarMultaVistas.fxml"));
        Parent root = loader.load();
        ListarMultaVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de Multa");
        stage.setScene(scene);
       stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    currentStage.close(); // serve para fechar uma tela 
    }
     
      //VOLTAR-------------------------------------------------------------------------------
    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarComecoVistas.fxml"));
        Parent root = loader.load();
        ListarComecoVistasControladores controller = loader.getController();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Pagina Começo");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    currentStage.close(); // serve para fechar uma tela 
    } 
     //VOLTAR-------------------------------------------------------------------------------
    public void onActionSair(ActionEvent event) throws IOException {
         
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/LoginVistas.fxml"));
        Parent root = loader.load();
        LoginVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Página Login");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         String imagePath = "../vistas/castanho.jpg"; // Especifique o caminho correto da imagem

    Image image = new Image(getClass().getResourceAsStream(imagePath));
    imagem.setImage(image);
    }    
    
}
