/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.FuncionarioDAOJdbc;
import com.sgdb.gestaodebibliotecas.data.PublicacaoDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;

import com.sgdb.gestaodebibliotecas.modelo.Publicacao;
import com.sgdb.gestaodebibliotecas.service.FuncionarioService;

import com.sgdb.gestaodebibliotecas.service.IPublicacaoService;
import com.sgdb.gestaodebibliotecas.service.PublicacaoService;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

//------------------------------------------------------------------------------
/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
//Listar uma publicacao-------------------------------------------------------------------------------
public class ListarPublicacaoVistasControladores implements Initializable {

    @FXML
    private ImageView imgazul;

    @FXML
    private ImageView imgl1;

    @FXML
    private ImageView imgl2;

    @FXML
    private ImageView imgl3;
//    private final ObservableList<Publicacao> listaPublicacao = FXCollections.observableArrayList();

    @FXML
    private TableView<Publicacao> tblListaPublicacao;

    @FXML
    private TableColumn<Publicacao, String> isbnColumn;

    @FXML
    private TableColumn<Publicacao, String> tipoColumn;

    private ObservableList<Publicacao> listaPublicacao;

    private final List<Publicacao> oldListaPublicacao = new ArrayList<>();

    private final List<Publicacao> toRemoveListaPublicacao = new ArrayList<>();

    private IPublicacaoService publicacaoService;

//------------------------------------------------------------------------------------
    // apresentar e listar somente livros
    public void onActionListarLivro(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarLivroVistas.fxml"));
        Parent root = loader.load();
        ListarLivroVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de Livros");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    // apresentar e listar somente revistas
    public void onActionListarRevista(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarRevistaVistas.fxml"));
        Parent root = loader.load();
        ListarRevistaVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de Revistas");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    // apresentar e listar somente artigos
    public void onActionListarArtigo(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarArtigoVistas.fxml"));
        Parent root = loader.load();
        ListarArtigoVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de Artigos");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    //Adicionar uma publicacao-------------------------------------------------------------------------------
    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AdicionarPublicacaoVistas.fxml"));
        Parent root = loader.load();
        AdicionarPublicacaoVistasControladores controller = loader.getController();
        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Adicionar Um Publicacao");
        stage.setScene(scene);
        stage.showAndWait();

    }

    //eliminar uma publicacao-------------------------------------------------------------------------------
    public void onActionExcluir() {
        if (tblListaPublicacao.getSelectionModel().isEmpty()) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro ao excluir a publicação", "Selecione a publicação que desejas eliminar");
        } else {
            Publicacao publicacaoSelecionado = tblListaPublicacao.getSelectionModel().getSelectedItem();

            try {
                publicacaoService.removeAll(publicacaoSelecionado.getISBN());

                listaPublicacao.remove(publicacaoSelecionado);
                toRemoveListaPublicacao.add(publicacaoSelecionado);

                showAlertMessage(Alert.AlertType.INFORMATION, "Sucesso",
                        "Publicação excluído", " A publicação foi excluído com sucesso");
            } catch (ServiceException ex) {
                showAlertMessage(Alert.AlertType.ERROR, "Erro",
                        "Erro ao excluir  a publicação", ex.getMessage());
            }
        }
    }

    //antigo excluir
//      // -------------------------
//        if (tblListaPublicacao.getSelectionModel().getSelectedItems().isEmpty()) {
//            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona a Publicacao que deseja Eliminar ", ButtonType.OK);
//            alert.showAndWait();} else{
//        ObservableList<Publicacao> listaSelecionada = tblListaPublicacao.getSelectionModel().getSelectedItems();
//        listaPublicacao.removeAll(listaSelecionada);             //paga os dados selecionados 
//        //permite apagar mais de que um tuplo /  linha de informacao
//
////        Publicacao publicacaoSelecionado =tblListaPublicacao.getSelectionModel().getSelectedItem();
////        listaPublicacao.remove(publicacaoSelecionado);                                      //paga os dados um a um 
//    }
//        }
    //Atualizar uma publicacao-------------------------------------------------------------------------------
    public void onActionAtualizar() throws IOException {
        if (tblListaPublicacao.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona a Publicação que deseja Atualizar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AtualizarPublicacaoVistas.fxml"));
            Parent root = loader.load();
            AtualizarPublicacaoVistasControladores controller = loader.getController();
            Publicacao publicacao = tblListaPublicacao.getSelectionModel().getSelectedItem();
            controller.setPublicacao(publicacao);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Atualizar Um Publicacao");
            stage.setScene(scene);
            stage.showAndWait();
        }
    }

    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarInicialVistas.fxml"));
        Parent root = loader.load();
        ListarInicialVistasControladores controller = loader.getController();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Pagina Inicial");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //--------IMAGENS-----------------------
        String imagazuPath = "../vistas/azul.jpg"; // Especifique o caminho correto da imagem
        Image imagea = new Image(getClass().getResourceAsStream(imagazuPath));
        imgazul.setImage(imagea);

        String imageePath = "../vistas/Livro.jpg"; // Especifique o caminho correto da imagem
        Image image = new Image(getClass().getResourceAsStream(imageePath));
        imgl1.setImage(image);
//    //-------------------------------
        String image1Path = "../vistas/Revista.jpg"; // Especifique o caminho correto da imagem
        Image image1 = new Image(getClass().getResourceAsStream(image1Path));
        imgl2.setImage(image1);
        //-------------------------------
        String image2Path = "../vistas/Artigo.jpg"; // Especifique o caminho correto da imagem
        Image image2 = new Image(getClass().getResourceAsStream(image2Path));
        imgl3.setImage(image2);

//           //------------Permite aparecer dados na tabela de lista Publicacao--------------------
        publicacaoService = new PublicacaoService(new PublicacaoDAOJdbc());
        listaPublicacao = FXCollections.emptyObservableList();
        try {
            listaPublicacao = FXCollections.observableList(publicacaoService.findAll());
            oldListaPublicacao.addAll(listaPublicacao);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando as publicações", ex.getMessage());
        }

        isbnColumn.setCellValueFactory(new PropertyValueFactory<>("ISBN"));
        tipoColumn.setCellValueFactory(new PropertyValueFactory<>("Tipo"));
        tblListaPublicacao.setItems(listaPublicacao);

    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }
}

//----------------ANTIGO INICIALIZACAO------------------------------------------------------------
/**
 * Initializes the controller class.
 */
//    @Override
//    public void initialize(URL url, ResourceBundle rb) {
//        populateListaPubliccao();
//        isbnColumn.setCellValueFactory(new PropertyValueFactory<Publicacao, String>("ISBN"));
//        tipoColumn.setCellValueFactory(new PropertyValueFactory("Tipo"));
//        tblListaPublicacao.setItems(listaPublicacao);
//        tblListaPublicacao.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//    }
//----------------------------------------------------------------------------
//    private void populateListaPubliccao() {
//        // ISBN de  Livrosadicionados na tabela publicacao
//        listaPublicacao.add(new Publicacao("9788535920400", "Livro"));
//        listaPublicacao.add(new Publicacao("9788530939755", "Livro"));
//        listaPublicacao.add(new Publicacao("9788573256139", "Livro"));
//        listaPublicacao.add(new Publicacao("9788535921063", "Livro"));
//        listaPublicacao.add(new Publicacao("9788535932820", "Livro"));
//        listaPublicacao.add(new Publicacao("9788533936642", "Livro"));
//        listaPublicacao.add(new Publicacao("9788525066262", "Livro"));
//        listaPublicacao.add(new Publicacao("9788539004116", "Livro"));
//        listaPublicacao.add(new Publicacao("9788556510170", "Livro"));
//        // ISBN de Revistas adicionados na tabela publicacao
//        listaPublicacao.add(new Publicacao("9788535919510", "Revista"));
//        listaPublicacao.add(new Publicacao("9788535919511", "Revista"));
//        listaPublicacao.add(new Publicacao("9788535919512", "Revista"));
//        listaPublicacao.add(new Publicacao("9788535919513", "Revista"));
//        listaPublicacao.add(new Publicacao("9788535919514", "Revista"));
//        listaPublicacao.add(new Publicacao("9788535919515", "Revista"));
//        listaPublicacao.add(new Publicacao("9788535919516", "Revista"));
//        listaPublicacao.add(new Publicacao("9788535919517", "Revista"));
//        listaPublicacao.add(new Publicacao("9788535919518", "Revista"));
//
//        // ISBN de Artigos adicionados na tabela publicacao
//        listaPublicacao.add(new Publicacao("9788535944151", "Artigo"));
//        listaPublicacao.add(new Publicacao("9788535944152", "Artigo"));
//        listaPublicacao.add(new Publicacao("9788535944153", "Artigo"));
//        listaPublicacao.add(new Publicacao("9788535944154", "Artigo"));
//        listaPublicacao.add(new Publicacao("9788535944155", "Artigo"));
//        listaPublicacao.add(new Publicacao("9788535944156", "Artigo"));
//        listaPublicacao.add(new Publicacao("9788535944157", "Artigo"));
//        listaPublicacao.add(new Publicacao("9788535944158", "Artigo"));
//        listaPublicacao.add(new Publicacao("9788535944159", "Artigo"));
//---------------------------------------------------------------------------------------

