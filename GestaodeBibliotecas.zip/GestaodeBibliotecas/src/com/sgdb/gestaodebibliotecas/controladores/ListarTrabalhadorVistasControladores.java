/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.TrabalhadorDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Trabalhador;
import com.sgdb.gestaodebibliotecas.service.ITrabalhadorService;
import com.sgdb.gestaodebibliotecas.service.TrabalhadorService;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class ListarTrabalhadorVistasControladores implements Initializable {

        @FXML
    private ImageView Trabalhadores;

//    private final ObservableList<Trabalhador> listaTrabalhador = FXCollections.observableArrayList();
    @FXML
    private TableView<Trabalhador> tblListaTrabalhador;

    @FXML
    private TableColumn<Trabalhador, Integer> idColumn;

    @FXML
    private TableColumn<Trabalhador, Integer> usuarioidColumn;

    @FXML
    private TableColumn<Trabalhador, String> nomeColumn;

    @FXML
    private TableColumn<Trabalhador, String> cargoColumn;

    @FXML
    private TableColumn<Trabalhador, String> centrotrabalhoColumn;

    @FXML
    private TableColumn<Trabalhador, String> emailColumn;

    @FXML
    private TableColumn<Trabalhador, String> telefoneColumn;

    @FXML
    private TableColumn<Trabalhador, String> moradaColumn;

    @FXML
    private TableColumn<Trabalhador, String> cniColumn;

    @FXML
    private RadioButton rbId;

    @FXML
    private RadioButton rbNome;

    @FXML
    private RadioButton rbCargo;

    @FXML
    private RadioButton rbCentroDeTrabalho;

    @FXML
    private RadioButton rbTodos;

    @FXML
    private TextField txtBuscar;

    //------------------------------------------------------------------------------------
    private ObservableList<Trabalhador> listaTrabalhador;

    private final List<Trabalhador> oldListaTrabalhador = new ArrayList<>();

    private final List<Trabalhador> toRemoveListaTrabalhador = new ArrayList<>();

    private ITrabalhadorService trabalhadorService;

    public void handleRadioButtonAction() {
        txtBuscar.clear();
    }

//    @FXML
//    private TableColumn<Trabalhador, String> tipousuarioColumn;
    //------------------------------------------------------------------------------------
    //Buscar um Trabalhador-------------------------------------------------------------------------------
    public void handleBuscarTrabalhadorButtonAction() {
        try {
            listaTrabalhador.clear();
            if (rbTodos.isSelected()) {
                txtBuscar.clear();
                oldListaTrabalhador.clear();
                listaTrabalhador.setAll(trabalhadorService.findAll());
                oldListaTrabalhador.addAll(listaTrabalhador);
            } else if (!txtBuscar.getText().isBlank()) {
                if (rbNome.isSelected()) {
                    listaTrabalhador.setAll(trabalhadorService.findByNome(txtBuscar.getText()));
                } else if (rbCargo.isSelected()) {
                    listaTrabalhador.setAll(trabalhadorService.findByCargo(txtBuscar.getText()));
                } else if (rbCentroDeTrabalho.isSelected()) {
                    listaTrabalhador.setAll(trabalhadorService.findByCentroDeTrabalho(txtBuscar.getText()));
                } else {
                    int id = Integer.parseInt(txtBuscar.getText());
                    Optional<Trabalhador> optionalTrabalhador = trabalhadorService.findById(id);
                    optionalTrabalhador.ifPresent((trabalhador) -> {
                        listaTrabalhador.add(trabalhador);
                    });
                }
            }
        } catch (NumberFormatException ex) {
            String mssg = "O valor inserido não tem o formato correto";
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando um trabalhador", mssg);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando um trabalhador", ex.getMessage());
        }
    }

//Adicionar um Trabalhador-------------------------------------------------------------------------------
    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AdicionarTrabalhadorVistas.fxml"));
        Parent root = loader.load();
        AdicionarTrabalhadorVistasControladores controller = loader.getController();
        controller.setListaTrabalhador(listaTrabalhador);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Adicionar um Trbalhador");
        stage.setScene(scene);
        stage.showAndWait();

    }

    //eliminar um Trabalhador------------------------------------------------------------------------------
    public void onActionExcluir() {
        if (tblListaTrabalhador.getSelectionModel().isEmpty()) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro ao excluir o Trabalhador", "Selecione um Trabalhador que desejas eliminar");
        } else {
            Trabalhador trabalhadorSelecionado = tblListaTrabalhador.getSelectionModel().getSelectedItem();

            try {
                trabalhadorService.remove(trabalhadorSelecionado.getUsuarioID());
                listaTrabalhador.remove(trabalhadorSelecionado);
                toRemoveListaTrabalhador.add(trabalhadorSelecionado);

                showAlertMessage(Alert.AlertType.INFORMATION, "Sucesso",
                        "Trabalhador excluído", "O Trabalhador foi excluído com sucesso");
            } catch (ServiceException ex) {
                showAlertMessage(Alert.AlertType.ERROR, "Erro",
                        "Erro ao excluir o estudante", ex.getMessage());
            }
        }

    }

    //Atualizar um Trabalhador-------------------------------------------------------------------------------
    public void onActionAtualizar() throws IOException {
        if (tblListaTrabalhador.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona Trabalhador que deseja Atualizar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AtualizarTrabalhadorVistas.fxml"));
            Parent root = loader.load();
            AtualizarTrabalhadorVistasControladores controller = loader.getController();
            Trabalhador trabalhador = tblListaTrabalhador.getSelectionModel().getSelectedItem();
            controller.setTrabalhador(trabalhador);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Atualizar um Trabalhador");
            stage.setScene(scene);
            stage.showAndWait();
        }
    }

    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarUsuarioVistas.fxml"));
        Parent root = loader.load();
        ListarUsuarioVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de Usuario");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
//        
//        //------------Permite aparecer dados na tabela de lista Estudante--------------------
        trabalhadorService = new TrabalhadorService(new TrabalhadorDAOJdbc());
        listaTrabalhador = FXCollections.emptyObservableList();
        try {
            listaTrabalhador = FXCollections.observableList(trabalhadorService.findAll());
            oldListaTrabalhador.addAll(listaTrabalhador);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os trabalhadores", ex.getMessage());
        }

        idColumn.setCellValueFactory(new PropertyValueFactory<Trabalhador, Integer>("ID"));
        usuarioidColumn.setCellValueFactory(new PropertyValueFactory<>("UsuarioID"));
        nomeColumn.setCellValueFactory(new PropertyValueFactory<>("Nome"));
        cargoColumn.setCellValueFactory(new PropertyValueFactory<>("Cargo"));
        centrotrabalhoColumn.setCellValueFactory(new PropertyValueFactory<>("CentroDeTrabalho"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("Email"));
        telefoneColumn.setCellValueFactory(new PropertyValueFactory<>("Telefone"));
        moradaColumn.setCellValueFactory(new PropertyValueFactory<>("Morada"));
        cniColumn.setCellValueFactory(new PropertyValueFactory<>("CNI"));
        tblListaTrabalhador.setItems(listaTrabalhador);

        
        //--------IMAGENS-----------------------
        String trabPath = "../vistas/trabalhador.jpg"; // Especifique o caminho correto da imagem
        Image imagea = new Image(getClass().getResourceAsStream(trabPath));
        Trabalhadores.setImage(imagea);
        
    }
//        
//          //------------Permite aparecer dados na tabela de lista Estudante--------------------
//        trabalhadorService = new TrabalhadorService(new TrabalhadorDAOJdbc());
//        listaTrabalhador = FXCollections.emptyObservableList();
//        try {
//            listaTrabalhador = FXCollections.observableList(trabalhadorService.findAll());
//            oldListaTrabalhador.addAll(listaTrabalhador);
//        } catch (ServiceException ex) {
//            showAlertMessage(Alert.AlertType.ERROR, "Erro",
//                    "Erro carregando os estudantes", ex.getMessage());
//        }
//        
//        idColumn.setCellValueFactory(new PropertyValueFactory<Trabalhador, Integer>("ID"));
//        usuarioidColumn.setCellValueFactory(new PropertyValueFactory<>("UsuarioID"));
//        nomeColumn.setCellValueFactory(new PropertyValueFactory<>("Nome"));
//        nomeescolaColumn.setCellValueFactory(new PropertyValueFactory<>("NomeDaEscola"));
//        emailColumn.setCellValueFactory(new PropertyValueFactory<>("Email"));
//        telefoneColumn.setCellValueFactory(new PropertyValueFactory<>("Telefone"));
//        moradaColumn.setCellValueFactory(new PropertyValueFactory<>("Morada"));
//        cniColumn.setCellValueFactory(new PropertyValueFactory<>("CNI"));
//        tblListaEstudante.setItems(listaEstudante);
// 

//        populateListaTrabalhador();
//        idColumn.setCellValueFactory(new PropertyValueFactory<Trabalhador, Integer>("ID"));
//        usuarioidColumn.setCellValueFactory(new PropertyValueFactory("UsuarioID"));
//        nomeColumn.setCellValueFactory(new PropertyValueFactory("Nome"));
//        cargoColumn.setCellValueFactory(new PropertyValueFactory("Cargo"));
//        centrotrabalhoColumn.setCellValueFactory(new PropertyValueFactory("CentroDeTrabalho"));
//        emailColumn.setCellValueFactory(new PropertyValueFactory("Email"));
//        telefoneColumn.setCellValueFactory(new PropertyValueFactory("Telefone"));
//        moradaColumn.setCellValueFactory(new PropertyValueFactory("Morada"));
//        cniColumn.setCellValueFactory(new PropertyValueFactory("CNI"));
////        tipousuarioColumn.setCellValueFactory(new PropertyValueFactory("TipoUsuario"));
//
//        tblListaTrabalhador.setItems(listaTrabalhador);
//        tblListaTrabalhador.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//
//    }
//
//    private void populateListaTrabalhador() {
//
//        listaTrabalhador.add(new Trabalhador(2201, 2011, "André Costa", "Gerente de Contas", "Banco do Cabo Verde", "andre.costa@gmail.com", "9876541", "Achada Santo António", "20031103M001P", "Trabalhador"));
//        listaTrabalhador.add(new Trabalhador(2202, 2012, "Mariana Santos", "Analista de Crédito", "Banco do Cabo Verde", "mariana.santos@gmail.com", "9876542", "Achadinha", "20031103F002P", "Trabalhador"));
//        listaTrabalhador.add(new Trabalhador(2203, 2013, "Ricardo Pereira", "Caixa Bancário", "Banco do Cabo Verde", "ricardo.pereira@gmail.com", "9876543", "Achada Eugénio Lima", "20031103M003P", "Trabalhador"));
//        listaTrabalhador.add(new Trabalhador(2204, 2014, "Sofia Fernandes", "Médico Clínico Geral", "Hospital Agostinho Neto", "sofia.fernandes@gmail.com", "9876544", "Achada Eugénio Lima", "20031103F004P", "Trabalhador"));
//        listaTrabalhador.add(new Trabalhador(2205, 2015, "Gustavo Silva", "Enfermeiro de Cuidados Intensivos", "Hospital Agostinho Neto", "gustavo.silva@gmail.com", "9876545", "Achada Grande Frente", "20031103M005P", "Trabalhador"));
//        listaTrabalhador.add(new Trabalhador(2206, 2016, "Isabel Santos", "Técnico de Radiologia", "Hospital Agostinho Neto", "isabel.santos@gmail.com", "9876546", "Achada Grande Frente", "20031103F006P", "Trabalhador"));
//
//    }
    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }
}
