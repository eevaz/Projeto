/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.NotificacaoDAOJdbc;
import com.sgdb.gestaodebibliotecas.modelo.Notificacao;
import com.sgdb.gestaodebibliotecas.modelo.Usuario;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class AenviarNotificacaoVistasControladores implements Initializable {

    private final List<Usuario> listaUsuarioExistente = new ArrayList<>();

    private ObservableList<Notificacao> listaNotificacao;
    @FXML
    private DatePicker txtDataNotificacao;

    @FXML
    private TextField txtFuncionarioID;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtPublicacaoISBN;

    @FXML
    private TextField txtTipoNotificacao;

    @FXML
    private TextField txtUsuarioID;

    public void setListaNotificacao(ObservableList<Notificacao> listaNotificacao) {
        this.listaNotificacao = listaNotificacao;
    }

    //-------------------------------------------------------------------------------------
    public void onActionAceitar(ActionEvent event) {
        boolean isIdValid = true;
        boolean isUsuarioIdValid = true;
        boolean isFuncionarioIdValid = true;
        boolean isPublicacaoISBNValid = true;

        int id = 0;
        int usuarioID = 0;
        int funcionarioID = 0;
        String publicacaoISBN = null;

        if (txtID.getText().isEmpty() || txtUsuarioID.getText().isEmpty() || txtFuncionarioID.getText().isEmpty() || txtPublicacaoISBN.getText().isEmpty() || txtTipoNotificacao.getText().isEmpty()) {
            // Exibir mensagem de aviso informando que algum campo está vazio
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha todos os campos antes de aceitar.");
            alert.showAndWait();
            return;
        }

        try {
            id = Integer.parseInt(txtID.getText());
        } catch (NumberFormatException e) {
            isIdValid = false;
        }

        try {
            usuarioID = Integer.parseInt(txtUsuarioID.getText());
        } catch (NumberFormatException e) {
            isUsuarioIdValid = false;
        }

        try {
            funcionarioID = Integer.parseInt(txtFuncionarioID.getText());
        } catch (NumberFormatException e) {
            isFuncionarioIdValid = false;
        }
        
                try {
            publicacaoISBN =(txtPublicacaoISBN.getText());
        } catch (NumberFormatException e) {
            isPublicacaoISBNValid = false;
        }

        // Verificar a validade dos campos individualmente
        if (!isIdValid && !isUsuarioIdValid && !isFuncionarioIdValid && !isPublicacaoISBNValid) {
            // Exibir mensagem de alerta informando que todos os campos estão inválidos
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valores inválidos");
            alert.setContentText("Os campos ID, UsuarioID, FuncionarioID e PublicacaoISBN devem conter números.");
            alert.showAndWait();
            return;
        } else if (!isIdValid) {
            // Exibir mensagem de alerta informando que o campo ID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo ID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isUsuarioIdValid) {
            // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo UsuarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isFuncionarioIdValid) {
            // Exibir mensagem de alerta informando que o campo FuncionarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo FuncionarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isPublicacaoISBNValid) {
            // Exibir mensagem de alerta informando que o campo FuncionarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo PublicacaoISBN deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

//   // Verificar se o usuário com o UsuarioID informado existe
        Usuario usuarioCorrespondente = null;
        for (Usuario usuario : listaUsuarioExistente) {
            if (usuario.getUsuarioID() == usuarioID) {
                usuarioCorrespondente = usuario;
                break;
            }
        }

        if (usuarioCorrespondente == null) {
            // Exibir mensagem de alerta informando que o usuário não foi encontrado
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Usuário não encontrado");
            alert.setContentText("O usuário com o ID informado não foi encontrado. Verifique o ID do usuário e tente novamente.");
            alert.showAndWait();
            return;
        } else {
            // Obter o nome e email do usuário correspondente
            String nomeUsuario = usuarioCorrespondente.getNome();
            String emailUsuario = usuarioCorrespondente.getEmail();

            // Adicionar a notificação apenas se os campos forem válidos
            NotificacaoDAOJdbc notifica = new NotificacaoDAOJdbc();
            Notificacao notificacao = new Notificacao();
            notificacao.setID(id);
            notificacao.setUsuarioID(usuarioID);
            notificacao.setFuncionarioID(funcionarioID);
            notificacao.setPublicacaoISBN(publicacaoISBN);
            notificacao.setTipoNotificacao(txtTipoNotificacao.getText());
            notificacao.setDataNotificacao(txtDataNotificacao.getValue());
            listaNotificacao.add(notificacao);
            notifica.add(notificacao);

            // Exibir mensagem de sucesso com o nome e email do usuário correspondente
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Sucesso");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Notificação enviada com sucesso");

            successAlert.showAndWait();
        }

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para fechar a tela depois de aceitar uma notificação que se quer adicionar
    }

    //        Node source = (Node) event.getSource();
//        Scene scene = source.getScene();
//        Stage stage = (Stage)scene.getWindow();
    //-------------------------------------------------------------------------------------
    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma 1 que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        populateListaUsuarioExistente();

    }

    private void populateListaUsuarioExistente() {
        // Adicione os usuários existentes na lista
        listaUsuarioExistente.add(new Usuario(2001, "João Silva", "joao.silva@gmail.com", "Estudante"));
        listaUsuarioExistente.add(new Usuario(2002, "Maria Santos", "maria.santos@gmail.com", "Estudante"));
        listaUsuarioExistente.add(new Usuario(2003, "Pedro Almeida", "pedro.almeida@gmail.com", "Estudante"));
        listaUsuarioExistente.add(new Usuario(2004, "Ana Oliveira", "ana.oliveira@gmail.com", "Estudante"));
        listaUsuarioExistente.add(new Usuario(2005, "Rafaela Costa", "rafaela.costa@gmail.com", "Estudante"));
        listaUsuarioExistente.add(new Usuario(2006, "Daniel Pereira", "daniel.pereira@gmail.com", "Estudante"));
        listaUsuarioExistente.add(new Usuario(2007, "Carolina Santos", "carolina.santos@gmail.com", "Estudante"));
        listaUsuarioExistente.add(new Usuario(2008, "Guilherme Ferreira", "guilherme.ferreira@gmail.com", "Estudante"));
        listaUsuarioExistente.add(new Usuario(2009, "Lúcia Sousa", "lucia.sousa@gmail.com", "Estudante"));
        listaUsuarioExistente.add(new Usuario(2010, "Fernando Mendes", "fernando.mendes@gmail.com", "Estudante"));
        listaUsuarioExistente.add(new Usuario(2011, "André Costa", "andre.costa@gmail.com", "Trabalhador"));
        listaUsuarioExistente.add(new Usuario(2012, "Mariana Santos", "mariana.santos@gmail.com", "Trabalhador"));
        listaUsuarioExistente.add(new Usuario(2013, "Ricardo Pereira", "ricardo.pereira@gmail.com", "Trabalhador"));
        listaUsuarioExistente.add(new Usuario(2014, "Sofia Fernandes", "sofia.fernandes@gmail.com", "Trabalhador"));
        listaUsuarioExistente.add(new Usuario(2015, "Gustavo Silva", "gustavo.silva@gmail.com", "Trabalhador"));
        listaUsuarioExistente.add(new Usuario(2016, "Isabel Santos", "isabel.santos@gmail.com", "Trabalhador"));
    }

}
