/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.RevistaDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Revista;
import com.sgdb.gestaodebibliotecas.service.IRevistaService;
import com.sgdb.gestaodebibliotecas.service.RevistaService;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class ListarRevistaVistasControladores implements Initializable {
//    private final ObservableList<Revista> listaRevista = FXCollections.observableArrayList();

    @FXML
    private ImageView revistar;

    @FXML
    private TableColumn<Revista, String> anoPublicacaoColumn;

    @FXML
    private TableColumn<Revista, String> categoriaColumn;

    @FXML
    private TableColumn<Revista, String> editoraColumn;

    @FXML
    private TableColumn<Revista, Integer> isbnColumn;

    @FXML
    private TableColumn<Revista, Integer> numeroColumn;

    @FXML
    private TableColumn<Revista, Integer> numeroexemplarColumn;

    @FXML
    private TableColumn<Revista, Integer> numeroexemplaremprestadoColumn;

    @FXML
    private TableView<Revista> tblListaRevista;

    @FXML
    private TableColumn<Revista, String> tituloColumn;
    
    
    @FXML
    private RadioButton rbEditora;

    @FXML
    private RadioButton rbISBN;

    @FXML
    private RadioButton rbTitulo;

    @FXML
    private RadioButton rbTodos;

     
    @FXML
    private TextField txtBuscar;

    //------------------------------------------------------------------------------------
   
    private ObservableList<Revista> listaRevista;

    private final List<Revista> oldListaRevista = new ArrayList<>();

    private final List<Revista> toRemoveListaRevista = new ArrayList<>();

    private IRevistaService revistaService;
    
    public void handleRadioButtonAction() {
        txtBuscar.clear();
    }

    //------------------------------------------------------------------------------------
   //Buscar um Revista-------------------------------------------------------------------------------
    public void handleBuscarRevistaButtonAction() {
        try {
            listaRevista.clear();
            if (rbTodos.isSelected()) {
                txtBuscar.clear();
                oldListaRevista.clear();
                listaRevista.setAll(revistaService.findAll());
                oldListaRevista.addAll(listaRevista);
            } else if (!txtBuscar.getText().isBlank()) {
                if (rbISBN.isSelected()) {
                    listaRevista.setAll(revistaService.findByISBN(txtBuscar.getText()));
                } else if (rbTitulo.isSelected()) {
                    listaRevista.setAll(revistaService.findByTitulo(txtBuscar.getText()));
                } else if (rbEditora.isSelected())  { 
                    listaRevista.setAll(revistaService.findByEditora(txtBuscar.getText()));
                } 
            }
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando o revista", ex.getMessage());
        }
    }

//Adicionar uma Revista-------------------------------------------------------------------------------
    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AdicionarRevistaVistas.fxml"));
        Parent root = loader.load();
        AdicionarRevistaVistasControladores controller = loader.getController();
        controller.setListaRevista(listaRevista);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Adicionar uma Revista");
        stage.setScene(scene);
        stage.showAndWait();

    }

    //eliminar uma revista-------------------------------------------------------------------------------
    public void onActionExcluir() {
        if (tblListaRevista.getSelectionModel().isEmpty()) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro ao excluir a revista", "Selecione a revista que desejas eliminar");
        } else {
            Revista revistaSelecionado = tblListaRevista.getSelectionModel().getSelectedItem();

            try {
                revistaService.removeAll(revistaSelecionado.getISBN());

                listaRevista.remove(revistaSelecionado);
                toRemoveListaRevista.add(revistaSelecionado);

                showAlertMessage(Alert.AlertType.INFORMATION, "Sucesso",
                        "Revista excluído", " A Revista foi excluído com sucesso");
            } catch (ServiceException ex) {
                showAlertMessage(Alert.AlertType.ERROR, "Erro",
                        "Erro ao excluir  a Revista", ex.getMessage());
            }
        }
    }

    //Atualizar uma Revista-------------------------------------------------------------------------------
    public void onActionAtualizar() throws IOException {
        if (tblListaRevista.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona a Revista que deseja Atualizar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AtualizarRevistaVistas.fxml"));
            Parent root = loader.load();
            AtualizarRevistaVistasControladores controller = loader.getController();
            Revista revista = tblListaRevista.getSelectionModel().getSelectedItem();
            controller.setRevista(revista);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Atualizar uma Revista");
            stage.setScene(scene);
            stage.showAndWait();
        }
    }

    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarPublicacaoVistas.fxml"));
        Parent root = loader.load();
        ListarPublicacaoVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de publicacoes");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //------------Permite aparecer dados na tabela de lista Livro--------------------
        revistaService = new RevistaService(new RevistaDAOJdbc());
        listaRevista = FXCollections.emptyObservableList();
        try {
            listaRevista = FXCollections.observableList(revistaService.findAll());
            oldListaRevista.addAll(listaRevista);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando as Revistas", ex.getMessage());
        }

        isbnColumn.setCellValueFactory(new PropertyValueFactory<>("ISBN"));
        categoriaColumn.setCellValueFactory(new PropertyValueFactory<>("Categoria"));
        tituloColumn.setCellValueFactory(new PropertyValueFactory<>("Titulo"));
        anoPublicacaoColumn.setCellValueFactory(new PropertyValueFactory<>("AnoPublicacao"));
        editoraColumn.setCellValueFactory(new PropertyValueFactory<>("Editora"));
        numeroColumn.setCellValueFactory(new PropertyValueFactory<>("Numero"));
        numeroexemplarColumn.setCellValueFactory(new PropertyValueFactory<>("Numero_exemplar"));
        numeroexemplaremprestadoColumn.setCellValueFactory(new PropertyValueFactory<>("Numero_exemplar_emprestado"));
        tblListaRevista.setItems(listaRevista);

        //--------IMAGENS-----------------------
        String imag2Path = "../vistas/revistar.jpg"; // Especifique o caminho correto da imagem

        Image revis = new Image(getClass().getResourceAsStream(imag2Path));
        revistar.setImage(revis);
        //-------------------------------
    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }
}
//         populateListaRevista();

//
//        tblListaRevista.setItems(listaRevista);
//        tblListaRevista.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//    }
//    
//private void populateListaRevista() {
//
//        // Adicionar as revistas
//
//listaRevista.add(new Revista("9788535919511", "Filosofia", "Philosophical Review", 1892, "Duke University Press", "Duke University Press", 02, 10, 3, "Revista"));
//listaRevista.add(new Revista("9788535919512", "Religião", "Christianity Today", 1956, "Christianity Today International", "Christianity Today International", 03, 10, 0, "Revista"));
//listaRevista.add(new Revista("9788535919513", "Ciências Sociais", "Social Forces", 1922, "Oxford University Press", "Oxford University Press", 04, 10, 0, "Revista"));
//listaRevista.add(new Revista("9788535919514", "Filologia", "Modern Philology", 1903, "University of Chicago Press", "University of Chicago Press", 05, 10, 1, "Revista"));
//listaRevista.add(new Revista("9788535919515", "Ciências naturais", "Scientific American", 1845, "Springer Nature", "Springer Nature", 6, 10, 0, "Revista"));
//listaRevista.add(new Revista("9788535919516", "Ciências Técnicas e Práticas", "Popular Mechanics", 1902, "Hearst Communications", "Hearst Communications", 07, 10, 0, "Revista"));
//listaRevista.add(new Revista("9788535919517", "Arte e Literatura", "Artforum", 1962, "Autor 8"," Artforum International Magazine", 8, 10, 0, "Revista"));
//listaRevista.add(new Revista("9788535919518", "História", "History Today", 1951, "Autor 9", "History Today Ltd.", 9, 10, 0, "Revista"));
//
//    }    
//    
//}
