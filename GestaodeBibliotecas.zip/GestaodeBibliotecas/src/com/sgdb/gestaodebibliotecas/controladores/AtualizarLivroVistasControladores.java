/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.CategoriaDAOJdbc;
import com.sgdb.gestaodebibliotecas.data.LivroDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Categoria;
import com.sgdb.gestaodebibliotecas.modelo.Livro;
import com.sgdb.gestaodebibliotecas.service.CategoriaService;
import com.sgdb.gestaodebibliotecas.service.ICategoriaService;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AtualizarLivroVistasControladores implements Initializable {
    
    private Livro livro;

   @FXML
    private TextField txtISBN;

    @FXML
    private TextField txtCategoria;

    @FXML
    private TextField txtTitulo;
             
    @FXML
    private TextField txtAnoPublicacao;

    @FXML
    private TextField txtEditora;       
    
    @FXML
    private TextField txtAutor;
    
    @FXML
    private TextField txtNumeroexemplar;

    @FXML
    private TextField txtNumeroexemplaremprestado;

            @FXML
    private ComboBox<String> cmbCategoria;
//    @FXML
//    private TextField txtTipo;


    /**
     * @param Livro the Livro to set
     */
    public void setLivro(Livro livro) {
        this.livro = livro;
        txtISBN.setText(livro.getISBN());
        cmbCategoria.setValue(livro.getCategoria());
        txtTitulo.setText(livro.getTitulo());
        txtAnoPublicacao.setText(Integer.toString(livro.getAnoPublicacao()));
        txtEditora.setText(livro.getEditora());
        txtAutor.setText(livro.getAutor());
        txtNumeroexemplar.setText(Integer.toString(livro.getNumero_exemplar()));
        txtNumeroexemplaremprestado.setText(Integer.toString(livro.getNumero_exemplar_emprestado()));
//        txtTipo.setText(livro.getTipo());
    }
   //----------------------------------------------- 
   //------------------------------------------------------------------
        private ObservableList<Categoria> listaCategoria;

    private final List<Categoria> oldListaCategoria= new ArrayList<>();
    
    private final List<String> listaCategoriaNome = new ArrayList<>();

        private ICategoriaService categoriaService;
        
//-----------------------------------------
public void onActionAceitar(ActionEvent event) throws DaoException {
    // Verificação de campos vazios
    if (txtISBN.getText().isEmpty() || cmbCategoria.getValue().isEmpty() || txtTitulo.getText().isEmpty() || txtAnoPublicacao.getText().isEmpty() || txtEditora.getText().isEmpty() || txtAutor.getText().isEmpty() || txtNumeroexemplar.getText().isEmpty() || txtNumeroexemplaremprestado.getText().isEmpty()) {
        // Exibir mensagem de aviso informando que algum campo está vazio
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Campos vazios");
        alert.setContentText("Preencha todos os campos antes de aceitar.");
        alert.showAndWait();
        return;
    }

    // Verificação de números inteiros
    boolean isAnoValido = true;
    boolean isNumeroExemplarValido = true;
    boolean isNumeroExemplarEmprestadoValido = true;

    int anoPublicacao = 0;
    int numeroExemplar = 0;
    int numeroExemplarEmprestado = 0;

    try {
        anoPublicacao = Integer.parseInt(txtAnoPublicacao.getText());
    } catch (NumberFormatException e) {
        isAnoValido = false;
    }

    try {
        numeroExemplar = Integer.parseInt(txtNumeroexemplar.getText());
    } catch (NumberFormatException e) {
        isNumeroExemplarValido = false;
    }

    try {
        numeroExemplarEmprestado = Integer.parseInt(txtNumeroexemplaremprestado.getText());
    } catch (NumberFormatException e) {
        isNumeroExemplarEmprestadoValido = false;
    }

    // Verificar a validade dos campos individualmente
    if (!isAnoValido && !isNumeroExemplarValido && !isNumeroExemplarEmprestadoValido) {
        // Exibir mensagem de alerta informando que todos os campos estão inválidos
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Valores inválidos");
        alert.setContentText("Os campos Ano de Publicação, Número de Exemplar e Número de Exemplar Emprestado devem conter números inteiros.");
        alert.showAndWait();
        return;
    } else {
        if (!isAnoValido) {
            // Exibir mensagem de alerta informando que o campo Ano de Publicação está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo Ano de Publicação deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

        if (!isNumeroExemplarValido) {
            // Exibir mensagem de alerta informando que o campo Número de Exemplar está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo Número de Exemplar deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

        if (!isNumeroExemplarEmprestadoValido) {
            // Exibir mensagem de alerta informando que o campo Número de Exemplar Emprestado está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo Número de Exemplar Emprestado deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }
    }

    // Verificar se houve alguma alteração nos dados antes de atualizar
    boolean isAtualizacaoSucesso = false;

    // Verificar se algum dado do livro foi alterado
    if (!livro.getISBN().equals(txtISBN.getText()) || !livro.getCategoria().equals(cmbCategoria.getValue()) || !livro.getTitulo().equals(txtTitulo.getText()) || livro.getAnoPublicacao() != anoPublicacao || !livro.getEditora().equals(txtEditora.getText()) || !livro.getAutor().equals(txtAutor.getText()) || livro.getNumero_exemplar() != numeroExemplar || livro.getNumero_exemplar_emprestado() != numeroExemplarEmprestado) {
       
        // Atualizar os dados do livro
        
        LivroDAOJdbc liv = new LivroDAOJdbc();
        livro.setISBN(txtISBN.getText());
        livro.setCategoria(cmbCategoria.getValue());
        livro.setTitulo(txtTitulo.getText());
        livro.setAnoPublicacao(anoPublicacao);
        livro.setEditora(txtEditora.getText());
        livro.setAutor(txtAutor.getText());
        livro.setNumero_exemplar(numeroExemplar);
        livro.setNumero_exemplar_emprestado(numeroExemplarEmprestado);
        liv.update(livro);
        isAtualizacaoSucesso = true;
    }

    // Exibir mensagem de sucesso ou informação
    if (isAtualizacaoSucesso) {
        // Exibir mensagem de atualização do livro com sucesso
        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
        successAlert.setTitle("Sucesso");
        successAlert.setHeaderText(null);
        successAlert.setContentText("Atualização do livro realizada com sucesso!");
        successAlert.showAndWait();
    } else {
        // Exibir mensagem informando que nenhum dado foi atualizado
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informação");
        alert.setHeaderText(null);
        alert.setContentText("Nenhum dado do livro foi atualizado.");
        alert.showAndWait();
    }

    // Fechar a janela atual
    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    stage.close();
}
//-----------------------------------------------

    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma livro que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    populateListaCategoriaNome ();
    }
  private void populateListaCategoriaNome() {
 categoriaService = new CategoriaService(new CategoriaDAOJdbc());
        listaCategoria = FXCollections.emptyObservableList();
        try {
            listaCategoria = FXCollections.observableList(categoriaService.findAll());
            oldListaCategoria.addAll(listaCategoria);
//------------------------------------------------------------
    // Preencher a lista de CtegoriaNome com os ISBN
            for (Categoria categoria : listaCategoria) {
                listaCategoriaNome.add(categoria.getNomeCategoria());
            }
            cmbCategoria.getItems().setAll(listaCategoriaNome);
        
 } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando as Categorias", ex.getMessage());
        }
    }
 //------------------------------------------------------------
private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }
}

