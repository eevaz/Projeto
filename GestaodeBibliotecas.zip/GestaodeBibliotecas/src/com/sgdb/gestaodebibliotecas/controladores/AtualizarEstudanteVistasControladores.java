/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.EstudanteDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Estudante;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AtualizarEstudanteVistasControladores implements Initializable {

    private Estudante estudante;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtUsuarioID;

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtNomeDaEscola;

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtTelefone;

    @FXML
    private TextField txtMorada;

    @FXML

    private TextField txtCNI;

//    @FXML
//    private TextField txtTipoUsuario;
    /**
     */
    public void setEstudante(Estudante estudante) {
        this.estudante = estudante;
        txtID.setText(Integer.toString(estudante.getID()));
        txtUsuarioID.setText(Integer.toString(estudante.getUsuarioID()));
        txtNome.setText(estudante.getNome());
        txtNomeDaEscola.setText(estudante.getNomeDaEscola());
        txtEmail.setText(estudante.getEmail());
        txtTelefone.setText(estudante.getTelefone());
        txtMorada.setText(estudante.getMorada());
        txtCNI.setText(Integer.toString(estudante.getCNI()));
//        txtTipoUsuario.setText(estudante.getTipoUsuario());

    }
    //----------------------------------------------------------

    public void onActionAceitar(ActionEvent event) throws DaoException {
        // Verificação de campos vazios
        if (txtID.getText().isEmpty() || txtUsuarioID.getText().isEmpty() || txtNome.getText().isEmpty() || txtNomeDaEscola.getText().isEmpty() || txtEmail.getText().isEmpty() || txtTelefone.getText().isEmpty() || txtMorada.getText().isEmpty() || txtCNI.getText().isEmpty()) {
            // Exibir mensagem de aviso informando que algum campo está vazio
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha todos os campos antes de aceitar.");
            alert.showAndWait();
            return;
        }

        // Verificação de números inteiros
        boolean isIDValido = true;
        boolean isUsuarioIDValido = true;
        boolean isCNIValido = true;

        int ID = 0;
        int usuarioID = 0;
        int cni = 0;
        try {
            ID = Integer.parseInt(txtID.getText());
        } catch (NumberFormatException e) {
            isIDValido = false;
        }

        try {
            usuarioID = Integer.parseInt(txtUsuarioID.getText());
        } catch (NumberFormatException e) {
            isUsuarioIDValido = false;
        }
        try {
            cni = Integer.parseInt(txtCNI.getText());
        } catch (NumberFormatException e) {
            isCNIValido = false;
        }

        // Verificar a validade dos campos individualmente
        if (!isIDValido && !isUsuarioIDValido) {
            // Exibir mensagem de alerta informando que ambos os campos estão inválidos
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valores inválidos");
            alert.setContentText("Os campos ID e UsuarioID devem conter números inteiros.");
            alert.showAndWait();
            return;
        } else if (!isIDValido) {
            // Exibir mensagem de alerta informando que o campo ID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo ID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isUsuarioIDValido) {
            // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo UsuarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isCNIValido) {
            // Exibir mensagem de alerta informando que o campo CNI está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo CNI deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

        // Verificar se houve alguma alteração nos dados antes de atualizar
        boolean isAtualizacaoSucesso = false;

        // Verificar se algum dado do estudante foi alterado
        if (estudante.getID() != ID || estudante.getUsuarioID() != usuarioID || !estudante.getNome().equals(txtNome.getText()) || !estudante.getNomeDaEscola().equals(txtNomeDaEscola.getText()) || !estudante.getEmail().equals(txtEmail.getText()) || !estudante.getTelefone().equals(txtTelefone.getText()) || !estudante.getMorada().equals(txtMorada.getText()) || estudante.getCNI() != cni) {

            // Atualizar os dados do estudante
            // EstudanteDAOJdbc permite atualizar estudante na base de dados 
            EstudanteDAOJdbc estu = new EstudanteDAOJdbc();
            estudante.setID(ID);
            estudante.setUsuarioID(usuarioID);
            estudante.setNome(txtNome.getText());
            estudante.setNomeDaEscola(txtNomeDaEscola.getText());
            estudante.setEmail(txtEmail.getText());
            estudante.setTelefone(txtTelefone.getText());
            estudante.setMorada(txtMorada.getText());
            estudante.setCNI(cni);
            estu.update(estudante);
            isAtualizacaoSucesso = true;
        }

        // Exibir mensagem de sucesso ou informação
        if (isAtualizacaoSucesso) {
            // Exibir mensagem de atualização do estudante com sucesso
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Sucesso");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Atualização do estudante realizada com sucesso!");
            successAlert.showAndWait();
        } else {
            // Exibir mensagem informando que nenhum dado foi atualizado
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Informação");
            alert.setHeaderText(null);
            alert.setContentText("Nenhum dado do estudante foi atualizado.");
            alert.showAndWait();
        }

        // Fechar a janela atual
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
    //----------------------------------------------------------

    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar um Estudante que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
