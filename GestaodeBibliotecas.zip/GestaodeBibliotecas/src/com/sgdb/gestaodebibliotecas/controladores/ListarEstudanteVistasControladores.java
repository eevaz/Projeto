/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.EstudanteDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Estudante;
import com.sgdb.gestaodebibliotecas.modelo.Usuario;
import com.sgdb.gestaodebibliotecas.service.EstudanteService;
import com.sgdb.gestaodebibliotecas.service.IEstudanteService;
import com.sgdb.gestaodebibliotecas.service.IUsuarioService;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class ListarEstudanteVistasControladores implements Initializable {

     @FXML
    private ImageView estud;
//    private final ObservableList<Estudante> listaEstudante = FXCollections.observableArrayList();
    @FXML
    private TableView<Estudante> tblListaEstudante;

    @FXML
    private TableColumn<Estudante, Integer> idColumn;

    @FXML
    private TableColumn<Estudante, Integer> usuarioidColumn;

    @FXML
    private TableColumn<Estudante, String> nomeColumn;

    @FXML
    private TableColumn<Estudante, String> nomeescolaColumn;

    @FXML
    private TableColumn<Estudante, String> emailColumn;

    @FXML
    private TableColumn<Estudante, String> telefoneColumn;

    @FXML
    private TableColumn<Estudante, String> moradaColumn;

    @FXML
    private TableColumn<Estudante, String> cniColumn;

    @FXML
    private RadioButton rbId;

    @FXML
    private RadioButton rbNome;

    @FXML
    private RadioButton rbNomeDaEscola;

    @FXML
    private RadioButton rbTodos;

    @FXML
    private TextField txtBuscar;

    //------------------------------------------------------------------------------------
    private ObservableList<Estudante> listaEstudante;

    private final List<Estudante> oldListaEstudante = new ArrayList<>();

    private final List<Estudante> toRemoveListaEstudante = new ArrayList<>();

    private IEstudanteService estudanteService;

    public void handleRadioButtonAction() {
        txtBuscar.clear();
    }

    
    
//    @FXML
//    private TableColumn<Estudante, String> tipousuarioColumn;
    //------------------------------------------------------------------------------------
     //Buscar um Estudante-------------------------------------------------------------------------------
    public void handleBuscarEstudanteButtonAction() {
        try {
            listaEstudante.clear();
            if (rbTodos.isSelected()) {
                txtBuscar.clear();
                oldListaEstudante.clear();
                listaEstudante.setAll(estudanteService.findAll());
                oldListaEstudante.addAll(listaEstudante);
            } else if (!txtBuscar.getText().isBlank()) {
                if (rbNome.isSelected()) {
                    listaEstudante.setAll(estudanteService.findByNome(txtBuscar.getText()));
                } else if (rbNomeDaEscola.isSelected()) {
                    listaEstudante.setAll(estudanteService.findByNomeDaEscola(txtBuscar.getText()));
                } else {
                    int id = Integer.parseInt(txtBuscar.getText());
                    Optional<Estudante> optionalEstudante = estudanteService.findById(id);
                    optionalEstudante.ifPresent((estudante) -> {
                        listaEstudante.add(estudante);
                    });
                }
            }
        } catch (NumberFormatException ex) {
            String mssg = "O valor inserido não tem o formato correto";
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando um estudante", mssg);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando um estudante", ex.getMessage());
        }
    }



//Adicionar um Estudante-------------------------------------------------------------------------------
    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AdicionarEstudanteVistas.fxml"));
        Parent root = loader.load();
        AdicionarEstudanteVistasControladores controller = loader.getController();
        controller.setListaEstudante(listaEstudante);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Adicionar Um Estudante");
        stage.setScene(scene);
        stage.showAndWait();

    }

    //eliminar um Estudante-------------------------------------------------------------------------------
    public void onActionExcluir() {
        if (tblListaEstudante.getSelectionModel().isEmpty()) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro ao excluir o Estudante", "Selecione um Estudante que desejas eliminar");
        } else {
            Estudante estudanteSelecionado = tblListaEstudante.getSelectionModel().getSelectedItem();

            try {
                estudanteService.remove(estudanteSelecionado.getUsuarioID());
                listaEstudante.remove(estudanteSelecionado);
                toRemoveListaEstudante.add(estudanteSelecionado);

                showAlertMessage(Alert.AlertType.INFORMATION, "Sucesso",
                        "Estudante excluído", "O Estudante foi excluído com sucesso");
            } catch (ServiceException ex) {
                showAlertMessage(Alert.AlertType.ERROR, "Erro",
                        "Erro ao excluir o estudante", ex.getMessage());
            }
        }

        //  antigoexcluir
//        if (tblListaEstudante.getSelectionModel().getSelectedItems().isEmpty()) {
//            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona o Estudante que deseja Eliminar ", ButtonType.OK);
//            alert.showAndWait();
//        } else {
//            ObservableList<Estudante> listaSelecionada = tblListaEstudante.getSelectionModel().getSelectedItems();
//            listaEstudante.removeAll(listaSelecionada);             //paga os dados selecionados 
//            //permite apagar mais de que um tuplo /  linha de informacao
//        Publicacao publicacaoSelecionado =tblListaPublicacao.getSelectionModel().getSelectedItem();
//        listaPublicacao.remove(publicacaoSelecionado);                                      //paga os dados um a um 
    }

    //Atualizar um Estudante-------------------------------------------------------------------------------
    public void onActionAtualizar() throws IOException {
        if (tblListaEstudante.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona Estudante que deseja Atualizar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AtualizarEstudanteVistas.fxml"));
            Parent root = loader.load();
            AtualizarEstudanteVistasControladores controller = loader.getController();
            Estudante estudante = tblListaEstudante.getSelectionModel().getSelectedItem();
            controller.setEstudante(estudante);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Atualizar Um Estudante");
            stage.setScene(scene);
            stage.showAndWait();
        }
    }

    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarUsuarioVistas.fxml"));
        Parent root = loader.load();
        ListarUsuarioVistasControladores controller = loader.getController();
//        controller.setListaPublicacao(listaPublicacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Lista de Usuario");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }
// public void onActionCancelar1(ActionEvent event) throws IOException {
//    listaEstudante.clear();
//    listaEstudante.setAll(oldListaEstudante);
//}
    //----------------------------------------------------------------------------
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

//        //------------Permite aparecer dados na tabela de lista Estudante--------------------
        estudanteService = new EstudanteService(new EstudanteDAOJdbc());
        listaEstudante = FXCollections.emptyObservableList();
        try {
            listaEstudante = FXCollections.observableList(estudanteService.findAll());
            oldListaEstudante.addAll(listaEstudante);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os estudantes", ex.getMessage());
        }

        idColumn.setCellValueFactory(new PropertyValueFactory<>("ID"));
        usuarioidColumn.setCellValueFactory(new PropertyValueFactory<>("UsuarioID"));
        nomeColumn.setCellValueFactory(new PropertyValueFactory<>("Nome"));
        nomeescolaColumn.setCellValueFactory(new PropertyValueFactory<>("NomeDaEscola"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("Email"));
        telefoneColumn.setCellValueFactory(new PropertyValueFactory<>("Telefone"));
        moradaColumn.setCellValueFactory(new PropertyValueFactory<>("Morada"));
        cniColumn.setCellValueFactory(new PropertyValueFactory<>("CNI"));
        tblListaEstudante.setItems(listaEstudante);

        
         //--------IMAGENS-----------------------
        String imagazuPath = "../vistas/Estudante.jpg"; // Especifique o caminho correto da imagem
        Image imagea = new Image(getClass().getResourceAsStream(imagazuPath));
        estud.setImage(imagea);
        
        
    }

//        populateListaEstudante();
//        idColumn.setCellValueFactory(new PropertyValueFactory<Estudante, Integer>("ID"));
//        usuarioidColumn.setCellValueFactory(new PropertyValueFactory("UsuarioID"));
//        nomeColumn.setCellValueFactory(new PropertyValueFactory("Nome"));
//        nomeescolaColumn.setCellValueFactory(new PropertyValueFactory("NomeDaEscola"));
//        emailColumn.setCellValueFactory(new PropertyValueFactory("Email"));
//        telefoneColumn.setCellValueFactory(new PropertyValueFactory("Telefone"));
//        moradaColumn.setCellValueFactory(new PropertyValueFactory("Morada"));
//        cniColumn.setCellValueFactory(new PropertyValueFactory("CNI"));
////        tipousuarioColumn.setCellValueFactory(new PropertyValueFactory("TipoUsuario"));
//////////////        
//        tblListaEstudante.setItems(listaEstudante);
//        tblListaEstudante.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
//
//    private void populateListaEstudante() {
//
//        listaEstudante.add(new Estudante(2101, 2001, "João Silva", "Universidade de Cabo Verde", "joao.silva@gmail.com", "9876551", "Achada Santo António", "20031103M001P", "Estudante"));
//        listaEstudante.add(new Estudante(2102, 2002, "Maria Santos", "Universidade Jean Piaget de Cabo Verde", "maria.santos@gmail.com", "9876552", "Achadinha", "20031103M002P", "Estudante"));
//        listaEstudante.add(new Estudante(2103, 2003, "Pedro Almeida", "Universidade Lusófona de Cabo Verde", "pedro.almeida@gmail.com", "9876553", "Achada Eugénio Lima", "20031103M003P", "Estudante"));
//        listaEstudante.add(new Estudante(2104, 2004, "Ana Oliveira", "Universidade de Santiago", "ana.oliveira@gmail.com", "9876554", "Achada Grande Frente", "20031103M004P", "Estudante"));
//        listaEstudante.add(new Estudante(2105, 2005, "Rafaela Costa", "Liceu Domingos Ramos", "rafaela.costa@gmail.com", "9876555", "Achada Grande Trás", "20031103M005P", "Estudante"));
//        listaEstudante.add(new Estudante(2106, 2006, "Daniel Pereira", "Liceu José Augusto Pinto", "daniel.pereira@gmail.com", "9876556", "Achada Mato", "20031103M006P", "Estudante"));
//        listaEstudante.add(new Estudante(2107, 2007, "Carolina Santos", "Liceu Amílcar Cabral", "carolina.santos@gmail.com", "9876557", "Achada São Filipe", "20031103M007P", "Estudante"));
//        listaEstudante.add(new Estudante(2108, 2008, "Guilherme Ferreira", "Liceu Ludgero Lima", "guilherme.ferreira@gmail.com", "9876558", "Bela Vista", "20031103M008P", "Estudante"));
//        listaEstudante.add(new Estudante(2109, 2009, "Lúcia Sousa", "Escola Secundária Abílio Duarte", "lucia.sousa@gmail.com", "9876559", "Lém Cachorro", "20031103M009P", "Estudante"));
//        listaEstudante.add(new Estudante(2110, 2010, "Fernando Mendes", "Escola Secundária Pedro Gomes", "fernando.mendes@gmail.com", "9876560", "Vila Nova", "20031103M010P", "Estudante"));
//
//    }
    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }
}
