/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.NotificacaoDAOJdbc;

import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Notificacao;

import com.sgdb.gestaodebibliotecas.service.INotificacaoService;
import com.sgdb.gestaodebibliotecas.service.NotificacaoService;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class ListarNotificacaoVistasControladores implements Initializable {

//   private final ObservableList<Notificacao> listaNotificacaos = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Notificacao, LocalDate> datanotificacaoColumn;

    @FXML
    private TableColumn<Notificacao, Integer> publicacaoisbnColumn;

    @FXML
    private TableColumn<Notificacao, Integer> funcionarioidColumn;

    @FXML
    private TableColumn<Notificacao, Integer> idColumn;

    @FXML

    private TableView<Notificacao> tblListaNotificacao;

    @FXML
    private TableColumn<Notificacao, String> tiponotificacaoColumn;

    @FXML
    private RadioButton rbId;
    
    @FXML
    private RadioButton rbTipoNotificacao;

    @FXML
    private RadioButton rbTodos;

    @FXML
    private TextField txtBuscar;

    @FXML
    private TableColumn<Notificacao, Integer> usuarioidColumn;

    private ObservableList<Notificacao> listaNotificacao;

    private final List<Notificacao> oldListaNotificacao = new ArrayList<>();

    private final List<Notificacao> toRemoveListaNotificacao = new ArrayList<>();

    private INotificacaoService notificacaoService;

    public void handleRadioButtonAction() {
        txtBuscar.clear();
    }

    //Buscar uma Notificacao-------------------------------------------------------------------------------
    public void handleBuscarNotificacaoButtonAction() throws ServiceException {
        try {
            listaNotificacao.clear();
            if (rbTodos.isSelected()) {
                txtBuscar.clear();
                oldListaNotificacao.clear();
                listaNotificacao.setAll(notificacaoService.findAll());
                oldListaNotificacao.addAll(listaNotificacao);
            } else if (!txtBuscar.getText().isBlank()) {
                if (rbTipoNotificacao.isSelected()) {
                    listaNotificacao.setAll(notificacaoService.findByTipoNotificacao(txtBuscar.getText()));

                } else {
                    int id = Integer.parseInt(txtBuscar.getText());
                    Optional<Notificacao> optionalNotificacao = notificacaoService.findById(id);
                    optionalNotificacao.ifPresent((notificacao) -> {
                        listaNotificacao.add(notificacao);

                    });

                }
            }
        } catch (NumberFormatException ex) {
            String mssg = "O valor inserido não tem o formato correto";
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando Notificacao", mssg);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando Notificacao", ex.getMessage());
        }

    }

    //Adicionar um Livro-------------------------------------------------------------------------------
    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AenviarNotificacaoVistas.fxml"));
        Parent root = loader.load();
        AenviarNotificacaoVistasControladores controller = loader.getController();
        controller.setListaNotificacao(listaNotificacao);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Enviar Notificacao ");
        stage.setScene(scene);
        stage.showAndWait();

    }

    public void onActionAtualizar() throws IOException {
        if (tblListaNotificacao.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona Notificacão que deseja Atualizar e Reenviar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AreenviarNotificacaoVistas.fxml"));
            Parent root = loader.load();
            AreenviarNotificacaoVistasControladores controller = loader.getController();
            Notificacao notificacao = tblListaNotificacao.getSelectionModel().getSelectedItem();
            controller.setNotificacao(notificacao);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Reenviar Notificacao");
            stage.setScene(scene);
            stage.showAndWait();
        }

    }

    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarInicialVistas.fxml"));
        Parent root = loader.load();
        ListarInicialVistasControladores controller = loader.getController();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Pagina Inicial");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    public void onActionExcluir() throws DaoException {
        if (tblListaNotificacao.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona Notificacao que deseja Eliminar ", ButtonType.OK);
            alert.showAndWait();
        } else {
            NotificacaoDAOJdbc selectenotificacao = new NotificacaoDAOJdbc();

            Notificacao notificacao = tblListaNotificacao.getSelectionModel().getSelectedItem();
            selectenotificacao.remove(notificacao.getID());
            listaNotificacao.remove(tblListaNotificacao.getSelectionModel().getSelectedItem());
        }        //paga os dados selecionados 
        //permite apagar mais de que um tuplo /  linha de informacao

//        Publicacao publicacaoSelecionado =tblListaPublicacao.getSelectionModel().getSelectedItem();
//        listaPublicacao.remove(publicacaoSelecionado);                                      //paga os dados um a um 
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        notificacaoService = new NotificacaoService(new NotificacaoDAOJdbc());
        listaNotificacao = FXCollections.emptyObservableList();
        try {
            listaNotificacao = FXCollections.observableList(notificacaoService.findAll());
            oldListaNotificacao.addAll(listaNotificacao);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando as notificacoes", ex.getMessage());

        }
        idColumn.setCellValueFactory(new PropertyValueFactory<>("ID"));
        usuarioidColumn.setCellValueFactory(new PropertyValueFactory<>("UsuarioID"));
        funcionarioidColumn.setCellValueFactory(new PropertyValueFactory<>("FuncionarioID"));
        publicacaoisbnColumn.setCellValueFactory(new PropertyValueFactory<>("PublicacaoISBN"));
        tiponotificacaoColumn.setCellValueFactory(new PropertyValueFactory<>("TipoNotificacao"));
        datanotificacaoColumn.setCellValueFactory(new PropertyValueFactory<>("DataNotificacao"));
        tblListaNotificacao.setItems(listaNotificacao);
    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }

}
