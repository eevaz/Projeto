/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.NotificacaoDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Notificacao;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author user
 */
public class AreenviarNotificacaoVistasControladores implements Initializable {

    private Notificacao notificacao;

    @FXML
    private DatePicker txtDataNotificacao;

    @FXML
    private TextField txtFuncionarioID;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtPublicacaoISBN;

    @FXML
    private TextField txtTipoNotificacao;

    @FXML
    private TextField txtUsuarioID;

    public void setNotificacao(Notificacao notificacao) {
        this.notificacao = notificacao;
        txtID.setText(Integer.toString(notificacao.getID()));
        txtUsuarioID.setText(Integer.toString(notificacao.getUsuarioID()));
        txtFuncionarioID.setText(Integer.toString(notificacao.getFuncionarioID()));
        txtPublicacaoISBN.setText(notificacao.getPublicacaoISBN());
        txtTipoNotificacao.setText(notificacao.getTipoNotificacao());
        txtDataNotificacao.setValue(notificacao.getDataNotificacao());

    }

    public void onActionAceitar(ActionEvent event) throws DaoException {
        // Verificação de campos vazios
        if ( txtTipoNotificacao.getText().isEmpty()) {
            // Exibir mensagem de aviso informando que algum campo está vazio
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha todos os campos antes de aceitar.");
            alert.showAndWait();
            return;
        }

        // Verificação de números inteiros
        boolean isIDValido = true;
        boolean isUsuarioIDValido = true;
        boolean isFuncionarioIDValido = true;

        int ID = 0;
        int usuarioID = 0;
        int funcionarioID = 0;

        try {
            ID = Integer.parseInt(txtID.getText());
        } catch (NumberFormatException e) {
            isIDValido = false;
        }

        try {
            usuarioID = Integer.parseInt(txtUsuarioID.getText());
        } catch (NumberFormatException e) {
            isUsuarioIDValido = false;
        }

        try {
            funcionarioID = Integer.parseInt(txtFuncionarioID.getText());
        } catch (NumberFormatException e) {
            isFuncionarioIDValido = false;
        }

        // Verificar a validade dos campos individualmente
        if (!isIDValido && !isUsuarioIDValido && !isFuncionarioIDValido) {
            // Exibir mensagem de alerta informando que todos os campos estão inválidos
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valores inválidos");
            alert.setContentText("Os campos ID, UsuarioID e FuncionarioID devem conter números inteiros.");
            alert.showAndWait();
            return;
        } else if (!isIDValido) {
            // Exibir mensagem de alerta informando que o campo ID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo ID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isUsuarioIDValido) {
            // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo UsuarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isFuncionarioIDValido) {
            // Exibir mensagem de alerta informando que o campo FuncionarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo FuncionarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

        // Verificar se houve alguma alteração nos dados antes de atualizar
        boolean isAtualizacaoSucesso = false;

        // Verificar se algum dado da notificação foi alterado
        if (notificacao.getID() != ID || notificacao.getUsuarioID() != usuarioID || notificacao.getFuncionarioID() != funcionarioID || !notificacao.getPublicacaoISBN().equals(txtPublicacaoISBN.getText()) || !notificacao.getTipoNotificacao().equals(txtTipoNotificacao.getText()) || !notificacao.getDataNotificacao().equals(txtDataNotificacao.getValue())) {
            // Atualizar os dados da notificação
            NotificacaoDAOJdbc notifica = new NotificacaoDAOJdbc();
            notificacao.setID(ID);
            notificacao.setUsuarioID(usuarioID);
            notificacao.setFuncionarioID(funcionarioID);
            notificacao.setPublicacaoISBN(txtPublicacaoISBN.getText());
            notificacao.setTipoNotificacao(txtTipoNotificacao.getText());
            notificacao.setDataNotificacao(txtDataNotificacao.getValue());
            notifica.update(notificacao);

            isAtualizacaoSucesso = true;
        }

        // Exibir mensagem de sucesso ou informação
        if (isAtualizacaoSucesso) {
            // Exibir mensagem de atualização da notificação com sucesso
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Sucesso");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Notificação reenviado com sucesso!");
            successAlert.showAndWait();
        } else {
            // Exibir mensagem informando que nenhum dado foi atualizado
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Informação");
            alert.setHeaderText(null);
            alert.setContentText("Nenhum dado da notificação foi atualizado.\nNotificação não foi reenviado");
            alert.showAndWait();
        }

        // Fechar a janela atual
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma publicacao que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
