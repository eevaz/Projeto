/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.FuncionarioDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Funcionario;
import com.sgdb.gestaodebibliotecas.service.IFuncionarioService;
import java.net.URL;

import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AtualizarFuncionarioVistasControladores implements Initializable {

    private Funcionario funcionario;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtNome;
    @FXML
    private TextField txtCargo;

    /**
     * @param Funcionario the Funcionario to set
     */
    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
        txtID.setText(Integer.toString(funcionario.getID()));
        txtNome.setText(funcionario.getNome());
        txtCargo.setText(funcionario.getCargo());

    }

    //-----------------------------------------------------------------
    public void onActionAceitar(ActionEvent event) throws ServiceException, DaoException {

        try {
            // Seu código de atualização dos dados do funcionário aqui
            // Verificação de campos vazios
            if (txtID.getText().isEmpty() || txtNome.getText().isEmpty() || txtCargo.getText().isEmpty()) {
                // Exibir mensagem de aviso informando que algum campo está vazio
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText("Campos vazios");
                alert.setContentText("Preencha todos os campos antes de aceitar.");
                alert.showAndWait();
                return;
            }

            // Verificação de número inteiro
            boolean isIdValido = true;

            int id = 0;

            try {
                id = Integer.parseInt(txtID.getText());
            } catch (NumberFormatException e) {
                isIdValido = false;
            }

            // Verificar a validade do campo UsuarioID
            if (!isIdValido) {
                // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText("Valor inválido");
                alert.setContentText("O campo ID deve conter um número inteiro.");
                alert.showAndWait();
                return;
            }

            // Verificar se houve alguma alteração nos dados antes de atualizar
            boolean isAtualizacaoSucesso = false;

            // Verificar se algum dado do usuário foi alterado
            if (funcionario.getID() != id) {
                // Exibir mensagem informando que o ID do funcionario nao pode ser mudado 
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText("Mudança de ID");
                alert.setContentText("O ID do funcionário não pode ser mudado.");
                alert.showAndWait();
                return;
            } else if (!funcionario.getNome().equals(txtNome.getText()) || !funcionario.getCargo().equals(txtCargo.getText())) {

                // Atualizar os dados do Funcionario
                FuncionarioDAOJdbc func = new FuncionarioDAOJdbc();

                funcionario.setNome(txtNome.getText());
                funcionario.setCargo(txtCargo.getText());
                func.update(funcionario);

                isAtualizacaoSucesso = true;
            }

            // Exibir mensagem de sucesso ou informação
            if (isAtualizacaoSucesso) {
                // Exibir mensagem de atualização do usuário com sucesso
                Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                successAlert.setTitle("Sucesso");
                successAlert.setHeaderText(null);
                successAlert.setContentText("Atualização do funcionário realizada com sucesso!");
                successAlert.showAndWait();
            } else {
                // Exibir mensagem informando que nenhum dado foi atualizado
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Informação");
                alert.setHeaderText(null);
                alert.setContentText("Nenhum dado do funcionário foi atualizado.");
                alert.showAndWait();
            }
            

        } catch (NumberFormatException ex) {
            String mssg = "O valor inserido não tem o formato correto";
            showAlertMessage(Alert.AlertType.ERROR, "Erro", "Erro atualizando o funcionário", mssg);
        }
        
        // Fechar a janela atual
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
    }
//} catch (ServiceException ex) {
//    showAlertMessage(Alert.AlertType.ERROR, "Erro", "Erro atualizando o funcionário", ex.getMessage());

//        try {
//            Funcionario selectedFuncionario = tblListaFuncionario.getSelectionModel().getSelectedItem();
//            selectedFuncionario.setID(Integer.parseInt(txtID.getText()));
//            selectedFuncionario.setNome(txtNome.getText());
//            selectedFuncionario.setCargo(txtCargo.getText());
//            if (selectedFuncionario.getID() == 0) {
//                funcionarioService.add(selectedFuncionario);
//            } else {
//                funcionarioService.update(selectedFuncionario);
//            }
//            for (Funcionario funcionario : toRemoveListaFuncionario) {
//                funcionarioService.remove(funcionario.getID());
//            }
//            oldListaFuncionario.clear();
//            oldListaFuncionario.addAll(listaFuncionario);
//            tblListaFuncionario.setDisable(false);
////            btnAdicionar.setDisable(false);
//        } catch (NumberFormatException ex) {
//            String mssg = "O valor inserido não tem o formato correto";
//            showAlertMessage(Alert.AlertType.ERROR, "Error",
//                    "Erro atualizando um fornecedor", mssg);
//        } catch (ServiceException ex) {
//            showAlertMessage(Alert.AlertType.ERROR, "Error",
//                    "Error atualizando o fornecedor", ex.getMessage());
//        }
    // Fechar a janela atual
//-----------------------------------------------------------------
    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma funcionario que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }

}
