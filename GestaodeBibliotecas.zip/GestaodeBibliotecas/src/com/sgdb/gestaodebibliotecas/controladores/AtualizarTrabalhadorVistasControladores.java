/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.TrabalhadorDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Trabalhador;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AtualizarTrabalhadorVistasControladores implements Initializable {

    private Trabalhador trabalhador;

    @FXML
    private TextField txtCNI;

    @FXML
    private TextField txtCargo;

    @FXML
    private TextField txtCentroDeTrabalho;

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtMorada;

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtTelefone;
//
//    @FXML
//    private TextField txtTipoUsuario;

    @FXML
    private TextField txtUsuarioID;

    /**
     */
    public void setTrabalhador(Trabalhador trabalhador) {
        this.trabalhador = trabalhador;
        txtID.setText(Integer.toString(trabalhador.getID()));
        txtUsuarioID.setText(Integer.toString(trabalhador.getUsuarioID()));
        txtNome.setText(trabalhador.getNome());
        txtCargo.setText(trabalhador.getCargo());
        txtCentroDeTrabalho.setText(trabalhador.getCentroDeTrabalho());
        txtEmail.setText(trabalhador.getEmail());
        txtTelefone.setText(trabalhador.getTelefone());
        txtMorada.setText(trabalhador.getMorada());
        txtCNI.setText(Integer.toString(trabalhador.getCNI()));
//        txtTipoUsuario.setText(trabalhador.getTipoUsuario());

    }

    //-------------------------------------------------------------
    public void onActionAceitar(ActionEvent event) throws DaoException {
        // Verificação de campos vazios
        if (txtID.getText().isEmpty() || txtUsuarioID.getText().isEmpty() || txtCargo.getText().isEmpty() || txtCentroDeTrabalho.getText().isEmpty() || txtEmail.getText().isEmpty() || txtTelefone.getText().isEmpty() || txtMorada.getText().isEmpty() || txtCNI.getText().isEmpty()) {
            // Exibir mensagem de aviso informando que algum campo está vazio
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha todos os campos antes de aceitar.");
            alert.showAndWait();
            return;
        }

        // Verificação de números inteiros
        boolean isIDValido = true;
        boolean isUsuarioIDValido = true;
        boolean isCNIValido = true;

        int ID = 0;
        int usuarioID = 0;
        int cni = 0;

        try {
            ID = Integer.parseInt(txtID.getText());
        } catch (NumberFormatException e) {
            isIDValido = false;
        }

        try {
            usuarioID = Integer.parseInt(txtUsuarioID.getText());
        } catch (NumberFormatException e) {
            isUsuarioIDValido = false;
        }
        try {
            cni = Integer.parseInt(txtCNI.getText());
        } catch (NumberFormatException e) {
            isCNIValido = false;
        }

        // Verificar a validade dos campos individualmente
        if (!isIDValido && !isUsuarioIDValido) {
            // Exibir mensagem de alerta informando que ambos os campos estão inválidos
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valores inválidos");
            alert.setContentText("Os campos ID e UsuarioID devem conter números inteiros.");
            alert.showAndWait();
            return;
        } else if (!isIDValido) {
            // Exibir mensagem de alerta informando que o campo ID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo ID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isUsuarioIDValido) {
            // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo UsuarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isCNIValido) {
            // Exibir mensagem de alerta informando que o campo CNI está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo CNI deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

        // Verificar se houve alguma alteração nos dados antes de atualizar
        boolean isAtualizacaoSucesso = false;

        // Verificar se algum dado do trabalhador foi alterado
      
 if (trabalhador.getID() != ID || trabalhador.getUsuarioID() != usuarioID || !trabalhador.getNome().equals(txtNome.getText()) || !trabalhador.getCargo().equals(txtCargo.getText()) || !trabalhador.getCentroDeTrabalho().equals(txtCentroDeTrabalho.getText()) || !trabalhador.getEmail().equals(txtEmail.getText()) || !trabalhador.getTelefone().equals(txtTelefone.getText()) || !trabalhador.getMorada().equals(txtMorada.getText()) || trabalhador.getCNI() != cni) {
            // Atualizar os dados do trabalhador
            // TrabalhadorDAOJdbc permite atualizar trabalhador na base de dados 
            TrabalhadorDAOJdbc trab = new TrabalhadorDAOJdbc();
            trabalhador.setID(ID);
            trabalhador.setUsuarioID(usuarioID);
            trabalhador.setNome(txtNome.getText());
            trabalhador.setCargo(txtCargo.getText());
            trabalhador.setCentroDeTrabalho(txtCentroDeTrabalho.getText());
            trabalhador.setEmail(txtEmail.getText());
            trabalhador.setTelefone(txtTelefone.getText());
            trabalhador.setMorada(txtMorada.getText());
            trabalhador.setCNI(cni);
            trab.update(trabalhador);
            isAtualizacaoSucesso = true;
        }

        // Exibir mensagem de sucesso ou informação
        if (isAtualizacaoSucesso) {
            // Exibir mensagem de atualização do trabalhador com sucesso
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Sucesso");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Atualização do trabalhador realizada com sucesso!");
            successAlert.showAndWait();
        } else {
            // Exibir mensagem informando que nenhum dado foi atualizado
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Informação");
            alert.setHeaderText(null);
            alert.setContentText("Nenhum dado do trabalhador foi atualizado.");
            alert.showAndWait();
        }

        // Fechar a janela atual
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }
    //-------------------------------------------------------------

    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar um Estudante que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
