/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.CategoriaDAOJdbc;
import com.sgdb.gestaodebibliotecas.data.LivroDAOJdbc;
import com.sgdb.gestaodebibliotecas.data.PublicacaoDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Categoria;
import com.sgdb.gestaodebibliotecas.modelo.Livro;
import com.sgdb.gestaodebibliotecas.modelo.Publicacao;
import com.sgdb.gestaodebibliotecas.service.CategoriaService;
import com.sgdb.gestaodebibliotecas.service.ICategoriaService;
import com.sgdb.gestaodebibliotecas.service.IPublicacaoService;
import com.sgdb.gestaodebibliotecas.service.PublicacaoService;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AdicionarLivroVistasControladores implements Initializable {

    private ObservableList<Livro> listaLivro;

    @FXML
    private TextField txtISBN;

    @FXML
    private TextField txtCategoria;

    @FXML
    private TextField txtTitulo;
             
    @FXML
    private TextField txtAnoPublicacao;

    @FXML
    private TextField txtEditora;       
    
    @FXML
    private TextField txtAutor;
    
    @FXML
    private TextField txtNumeroexemplar;

    @FXML
    private TextField txtNumeroexemplaremprestado;

    @FXML
    private TextField txtTipo;

        @FXML
    private ComboBox<String> cmbCategoria;

    public void setListaLivro(ObservableList<Livro> listaLivro) {
        this.listaLivro = listaLivro;
    }
    
    private ObservableList<Publicacao> listaPublicacao;

    private final List<Publicacao> oldListaPublicacao = new ArrayList<>();
    
    private final List<String> listaPublicacaoExistente = new ArrayList<>();

        private IPublicacaoService publicacaoService;
//------------------------------------------------------------------
        private ObservableList<Categoria> listaCategoria;

    private final List<Categoria> oldListaCategoria= new ArrayList<>();
    
    private final List<String> listaCategoriaNome = new ArrayList<>();

        private ICategoriaService categoriaService;
        
//-----------------------------------------
    //acao para aceitar um livro que se quer adicionar
        //-----------------------------------------
    public void onActionAceitar(ActionEvent event) throws DaoException {
    boolean isAnoPublicacaoValid = true;
    boolean isNumeroExemplarValid = true;
    boolean isNumeroExemplarEmprestadoValid = true;

    int anoPublicacao = 0;
    int numeroExemplar = 0;
    int numeroExemplarEmprestado = 0;

    if (txtISBN.getText().isEmpty() || cmbCategoria.getValue().isEmpty() || txtTitulo.getText().isEmpty() || txtAnoPublicacao.getText().isEmpty() || txtEditora.getText().isEmpty() || txtAutor.getText().isEmpty() || txtNumeroexemplar.getText().isEmpty() || txtNumeroexemplaremprestado.getText().isEmpty()) {
        // Exibir mensagem de aviso informando que algum campo está vazio
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Campos vazios");
        alert.setContentText("Preencha todos os campos antes de aceitar.");
        alert.showAndWait();
        return;
    }

    try {
        anoPublicacao = Integer.parseInt(txtAnoPublicacao.getText());
    } catch (NumberFormatException e) {
        isAnoPublicacaoValid = false;
    }

    try {
        numeroExemplar = Integer.parseInt(txtNumeroexemplar.getText());
    } catch (NumberFormatException e) {
        isNumeroExemplarValid = false;
    }

    try {
        numeroExemplarEmprestado = Integer.parseInt(txtNumeroexemplaremprestado.getText());
    } catch (NumberFormatException e) {
        isNumeroExemplarEmprestadoValid = false;
    }

    // Verificar a validade dos campos individualmente
    if (!isAnoPublicacaoValid) {
        // Exibir mensagem de alerta informando que o campo Ano de Publicação está inválido
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Valor inválido");
        alert.setContentText("O campo Ano de Publicação deve conter um número inteiro.");
        alert.showAndWait();
        return;
    } else if (!isNumeroExemplarValid) {
        // Exibir mensagem de alerta informando que o campo Número de Exemplar está inválido
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Valor inválido");
        alert.setContentText("O campo Número de Exemplar deve conter um número inteiro.");
        alert.showAndWait();
        return;
    } else if (!isNumeroExemplarEmprestadoValid) {
        // Exibir mensagem de alerta informando que o campo Número de Exemplar Emprestado está inválido
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Valor inválido");
        alert.setContentText("O campo Número de Exemplar Emprestado deve conter um número inteiro.");
        alert.showAndWait();
        return;
    }
    
     // Verificar se a Publicacao com o ISBN informado existe
            boolean publicacaoExiste = listaPublicacaoExistente.contains(txtISBN.getText());
            if (!publicacaoExiste) {

                // Publicacao com este ISBN informado nao existe

    // Adicionar o livro apenas se os campos forem válidos
    Livro livro = new Livro();
    LivroDAOJdbc l = new LivroDAOJdbc();
    livro.setISBN(txtISBN.getText());
    livro.setCategoria(cmbCategoria.getValue());
    livro.setTitulo(txtTitulo.getText());
    livro.setAnoPublicacao(anoPublicacao);
    livro.setEditora(txtEditora.getText());
    livro.setAutor(txtAutor.getText());
    livro.setNumero_exemplar(numeroExemplar);
    livro.setNumero_exemplar_emprestado(numeroExemplarEmprestado);
    l.add(livro);
    listaLivro.add(livro);

    // Exibir mensagem de Adição de Livro com sucesso
    Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
    successAlert.setTitle("Sucesso");
    successAlert.setHeaderText(null);
    successAlert.setContentText("Adição de livro realizado com sucesso!");
    successAlert.showAndWait();

      } else {
                // Publicacao já Existe
                // Exibir mensagem de alerta informando que A Publicacao foi encontrado e que este isbn existe
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText("ISBN da Publicacão Já existe");
                alert.setContentText("A Publicacão com este ISBN informado já existe e nunca o ISBN de uma Publicacão pode ser igual a outra. Introduza um outro ISBN e tente novamente.");
                alert.showAndWait();
                return;
            }
    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    stage.close(); // serve para fechar a tela depois de aceitar um livro que se quer adicionar
}

//        Node source = (Node) event.getSource();
//        Scene scene = source.getScene();
//        Stage stage = (Stage)scene.getWindow();
    
    
    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma 1 que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         populateListaPublicacoExistente();
         populateListaCategoriaNome ();
    }
 private void populateListaPublicacoExistente() {
        //------------Permite aparecer dados na tabela de lista Livro--------------------
        publicacaoService = new PublicacaoService(new PublicacaoDAOJdbc());
        listaPublicacao = FXCollections.emptyObservableList();
        try {
            listaPublicacao = FXCollections.observableList(publicacaoService.findAll());
            oldListaPublicacao.addAll(listaPublicacao);
//------------------------------------------------------------
            // Preencher a lista de Publicacoes existentes com os ISBN
            for (Publicacao publicacao : listaPublicacao) {
                listaPublicacaoExistente.add(publicacao.getISBN());
            }
                
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando as Publicacoes", ex.getMessage());
        }
 }
 //------------------------------------------------------------------------           
       private void populateListaCategoriaNome() {
 categoriaService = new CategoriaService(new CategoriaDAOJdbc());
        listaCategoria = FXCollections.emptyObservableList();
        try {
            listaCategoria = FXCollections.observableList(categoriaService.findAll());
            oldListaCategoria.addAll(listaCategoria);
//------------------------------------------------------------
    // Preencher a lista de CtegoriaNome com os ISBN
            for (Categoria categoria : listaCategoria) {
                listaCategoriaNome.add(categoria.getNomeCategoria());
            }
            cmbCategoria.getItems().setAll(listaCategoriaNome);
        
 } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando as Categorias", ex.getMessage());
        }
    }
 //------------------------------------------------------------
private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }
}

