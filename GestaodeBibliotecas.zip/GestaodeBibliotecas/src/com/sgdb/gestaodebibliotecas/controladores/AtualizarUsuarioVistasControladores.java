/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.UsuarioDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Usuario;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AtualizarUsuarioVistasControladores implements Initializable {
  private Usuario usuario;

   @FXML
    private TextField txtUsuarioID;

    @FXML
    private TextField txtTipoUsuario;

   

    /**
     * @param Usuario the Usuario to set
     */
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
        txtUsuarioID.setText(Integer.toString(usuario.getUsuarioID()));
        txtTipoUsuario.setText(usuario.getTipoUsuario());
  

    }

    //-----------------------------------------------------------------
    public void onActionAceitar(ActionEvent event) throws DaoException {
  
         try {
        // Verificação de campos vazios
    if (txtUsuarioID.getText().isEmpty() || txtTipoUsuario.getText().isEmpty()) {
        // Exibir mensagem de aviso informando que algum campo está vazio
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Campos vazios");
        alert.setContentText("Preencha todos os campos antes de aceitar.");
        alert.showAndWait();
        return;
    }

    // Verificação de número inteiro
    boolean isUsuarioIDValido = true;

    int usuarioID = 0;

    try {
        usuarioID = Integer.parseInt(txtUsuarioID.getText());
    } catch (NumberFormatException e) {
        isUsuarioIDValido = false;
    }

    // Verificar a validade do campo UsuarioID
    if (!isUsuarioIDValido) {
        // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Valor inválido");
        alert.setContentText("O campo UsuarioID deve conter um número inteiro.");
        alert.showAndWait();
        return;
    }

    // Verificar se houve alguma alteração nos dados antes de atualizar
    boolean isAtualizacaoSucesso = false;

    // Verificar se algum dado do usuário foi alterado
    if (usuario.getUsuarioID() != usuarioID || !usuario.getTipoUsuario().equals(txtTipoUsuario.getText())) {
       
        // Atualizar os dados do usuário
        
         UsuarioDAOJdbc usua = new UsuarioDAOJdbc();
//        usuario.setUsuarioID(usuarioID);
        usuario.setTipoUsuario(txtTipoUsuario.getText());
          usua.update(usuario);  
        
        isAtualizacaoSucesso = true;
    }

    // Exibir mensagem de sucesso ou informação
    if (isAtualizacaoSucesso) {
        // Exibir mensagem de atualização do usuário com sucesso
        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
        successAlert.setTitle("Sucesso");
        successAlert.setHeaderText(null);
        successAlert.setContentText("Atualização do usuário realizada com sucesso!");
        successAlert.showAndWait();
    } else {
        // Exibir mensagem informando que nenhum dado foi atualizado
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informação");
        alert.setHeaderText(null);
        alert.setContentText("Nenhum dado do usuário foi atualizado.");
        alert.showAndWait();
    }

     } catch (NumberFormatException ex) {
            String mssg = "O valor inserido não tem o formato correto";
            showAlertMessage(Alert.AlertType.ERROR, "Erro", "Erro atualizando o usuário", mssg);
        }
        
    
    // Fechar a janela atual
    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    stage.close();
}
//-----------------------------------------------------------------
    
    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma livro que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }
}

