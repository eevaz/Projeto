/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.controladores.AdicionarReservaVistasControladores;
import com.sgdb.gestaodebibliotecas.controladores.AtualizarReservaVistasControladores;
import com.sgdb.gestaodebibliotecas.data.FuncionarioDAOJdbc;
import com.sgdb.gestaodebibliotecas.data.ReservaDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Funcionario;
import com.sgdb.gestaodebibliotecas.modelo.Reserva;
import com.sgdb.gestaodebibliotecas.service.FuncionarioService;
import com.sgdb.gestaodebibliotecas.service.IFuncionarioService;
import com.sgdb.gestaodebibliotecas.service.IReservaService;
import com.sgdb.gestaodebibliotecas.service.ReservaService;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class ListarReservaVistasControladores implements Initializable {

    private ObservableList<Reserva> listaReserva;// = FXCollections.observableArrayList();

    private final List<Reserva> oldListaReserva = new ArrayList<>();

    private final List<Reserva> toRemoveListaReserva = new ArrayList<>();

    private IReservaService reservaService;

    @FXML
    private RadioButton rbTodos;
    @FXML
    private TextField txtBuscar;

    @FXML
    private RadioButton rbId;

    @FXML
    private TableColumn<Reserva, String> datareservaColumn;

    @FXML
    private TableColumn<Reserva, Integer> idColumn;

    @FXML
    private TableColumn<Reserva, Integer> publicacaoisbnColumn;

    @FXML
    private TableColumn<Reserva, Integer> usuarioidColumn;

    @FXML
    private TableView<Reserva> tblListaReserva;

    public void handleRadioButtonAction() {
        txtBuscar.clear();
    }

    public void handleBuscarReservaButtonAction() {
        try {
             listaReserva.clear();
            if (rbTodos.isSelected()) {
                txtBuscar.clear();
                oldListaReserva.clear();
                listaReserva.setAll(reservaService.findAll());
                oldListaReserva.addAll(listaReserva);
            } else {
                int id = Integer.parseInt(txtBuscar.getText());
                Optional<Reserva> optionalReserva = reservaService.findById(id);
                optionalReserva.ifPresent((reserva) -> {
                    listaReserva.add(reserva);

                });
            
            }

        } catch (NumberFormatException ex) {
            String mssg = "O valor inserido não tem o formato correto";
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando Reserva", mssg);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Error",
                    "Erro buscando Reserva", ex.getMessage());
        }
    }

    //Adicionar um Reserva-------------------------------------------------------------------------------
    public void onActionAdicionar() throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AdicionarReservaVistas.fxml"));
        Parent root = loader.load();
        AdicionarReservaVistasControladores controller = loader.getController();
        controller.setListaReserva(listaReserva);
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Adicionar uma Reserva");
        stage.setScene(scene);
        stage.showAndWait();
    }

    //eliminar um Artigo-------------------------------------------------------------------------------
    public void onActionExcluir() {
        if (tblListaReserva.getSelectionModel().isEmpty()) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro ao excluir a Reserva", "Selecione uma Reserva que deseja eliminar");
        } else {
            Reserva reservaSelecionado = tblListaReserva.getSelectionModel().getSelectedItem();

            try {
                reservaService.remove(reservaSelecionado.getID());

                listaReserva.remove(reservaSelecionado);
                toRemoveListaReserva.add(reservaSelecionado);

                showAlertMessage(Alert.AlertType.INFORMATION, "Sucesso",
                        "Reserva excluído", "A Reserva foi excluído com sucesso");
            } catch (ServiceException ex) {
                showAlertMessage(Alert.AlertType.ERROR, "Erro",
                        "Erro ao excluir o Reserva", ex.getMessage());
            }
        }
    }
    //Atualizar um Artigo-------------------------------------------------------------------------------

    public void onActionAtualizar() throws IOException {
        if (tblListaReserva.getSelectionModel().getSelectedItems().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Seleciona a Reserva que deseja Atualizar ", ButtonType.OK);
            alert.showAndWait();                   // mostra a alerta de Atencao para selecionar uma linha primeiro para poder atualizar 
        } else {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/AtualizarReservaVistas.fxml"));
            Parent root = loader.load();
            AtualizarReservaVistasControladores controller = loader.getController();
            Reserva reserva = tblListaReserva.getSelectionModel().getSelectedItem();
            controller.setReserva(reserva);
            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Atualizar uma Reserva");
            stage.setScene(scene);
            stage.showAndWait();
        }
    }

    public void onActionVoltar(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("../vistas/ListarInicialVistas.fxml"));
        Parent root = loader.load();
        ListarInicialVistasControladores controller = loader.getController();
        Scene scene = new Scene(root);
        Stage stage = new Stage();
        stage.setTitle("Pagina Inicial");
        stage.setScene(scene);
        stage.show();
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close(); // serve para fechar uma tela 
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        reservaService = new ReservaService(new ReservaDAOJdbc());
        listaReserva = FXCollections.emptyObservableList();
        try {
            listaReserva = FXCollections.observableList(reservaService.findAll());
            oldListaReserva.addAll(listaReserva);
        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando as reservas", ex.getMessage());
        }
        // TODO

        idColumn.setCellValueFactory(new PropertyValueFactory<>("ID"));
        usuarioidColumn.setCellValueFactory(new PropertyValueFactory<>("UsuarioID"));
        publicacaoisbnColumn.setCellValueFactory(new PropertyValueFactory<>("PublicacaoISBN"));
        datareservaColumn.setCellValueFactory(new PropertyValueFactory<>("DataReserva"));

        tblListaReserva.setItems(listaReserva);
        tblListaReserva.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }

}
