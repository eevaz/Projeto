/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.EstudanteDAOJdbc;
import com.sgdb.gestaodebibliotecas.data.UsuarioDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Estudante;
import com.sgdb.gestaodebibliotecas.modelo.Usuario;
import com.sgdb.gestaodebibliotecas.service.EstudanteService;
import com.sgdb.gestaodebibliotecas.service.IEstudanteService;
import com.sgdb.gestaodebibliotecas.service.IUsuarioService;
import com.sgdb.gestaodebibliotecas.service.UsuarioService;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AdicionarEstudanteVistasControladores implements Initializable {

    private IEstudanteService estudanteService;
    private ObservableList<Estudante> listaEstudante;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtUsuarioID;

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtNomeDaEscola;

    @FXML
    private TextField txtEmail;

    @FXML
    private TextField txtTelefone;

    @FXML
    private TextField txtMorada;

    @FXML

    private TextField txtCNI;

//    @FXML
//    private TextField txtTipoUsuario;
    public void setListaEstudante(ObservableList<Estudante> listaEstudante) {
        this.listaEstudante = listaEstudante;
    }

    private ObservableList<Usuario> listaUsuario;

    private final List<Usuario> oldListaUsuario = new ArrayList<>();

    private final List<Estudante> oldListaEstudante = new ArrayList<>();

    private final List<Integer> listaUsuarioExistente = new ArrayList<>();

    private final List<Integer> listaEstudanteExistente = new ArrayList<>();

    private IUsuarioService usuarioService;

//---------------------------------------------------------
    //acao para aceitar um estudante que se quer adicionar
    public void onActionAceitar(ActionEvent event) throws DaoException {
        boolean isIdValid = true;
        boolean isUsuarioIdValid = true;
        boolean isCNIValido = true;

        int id = 0;
        int usuarioID = 0;
        int cni = 0;

        if (txtID.getText().isEmpty() || txtUsuarioID.getText().isEmpty() || txtNome.getText().isEmpty() || txtNomeDaEscola.getText().isEmpty() || txtEmail.getText().isEmpty() || txtTelefone.getText().isEmpty() || txtMorada.getText().isEmpty() || txtCNI.getText().isEmpty()) {
            // Exibir mensagem de aviso informando que algum campo está vazio
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha todos os campos antes de aceitar.");
            alert.showAndWait();
            return;
        }

        try {
            id = Integer.parseInt(txtID.getText());
        } catch (NumberFormatException e) {
            isIdValid = false;
        }

        try {
            usuarioID = Integer.parseInt(txtUsuarioID.getText());
        } catch (NumberFormatException e) {
            isUsuarioIdValid = false;
        }
        try {
            cni = Integer.parseInt(txtCNI.getText());
        } catch (NumberFormatException e) {
            isCNIValido = false;
        }

        // Verificar a validade dos campos individualmente
        if (!isIdValid) {
            // Exibir mensagem de alerta informando que o campo ID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo ID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isUsuarioIdValid) {
            // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo UsuarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        } else if (!isCNIValido) {
            // Exibir mensagem de alerta informando que o campo CNI está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo CNI deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

        // Verificar se o Estudante com ID informado existe
        boolean estudanteExiste = listaEstudanteExistente.contains(id);
        if (!estudanteExiste) {

            // Estudante com este id informado nao existe
            // Verificar se o usuário com o UsuarioID informado existe
            boolean usuarioExiste = listaUsuarioExistente.contains(usuarioID);
            if (!usuarioExiste) {

                // Usuário com este id informado nao existe
                // Adicionar o estudante apenas se os campos forem válidos
                Estudante estudante = new Estudante();
                EstudanteDAOJdbc e = new EstudanteDAOJdbc();
                estudante.setID(id);
                estudante.setUsuarioID(usuarioID);
                estudante.setNome(txtNome.getText());
                estudante.setNomeDaEscola(txtNomeDaEscola.getText());
                estudante.setEmail(txtEmail.getText());
                estudante.setTelefone(txtTelefone.getText());
                estudante.setMorada(txtMorada.getText());
                estudante.setCNI(cni);
                e.add(estudante);
                listaEstudante.add(estudante);

                // Exibir mensagem de Adição de Estudante com sucesso
                Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                successAlert.setTitle("Sucesso");
                successAlert.setHeaderText(null);
                successAlert.setContentText("Adição de estudante realizado com sucesso!");
                successAlert.showAndWait();

            } else {
                // Usuário já Existe
                // Exibir mensagem de alerta informando que o usuário foi encontrado e que este id existe
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Aviso");
                alert.setHeaderText("ID de Usuário Já existe");
                alert.setContentText("O usuário com este UsuarioID informado já existe.  Crie e Utilize um novo UsuarioID tente novamente.");
                alert.showAndWait();
                return;
            }

        } else {
                // Estudante já Existe
            // Exibir mensagem de alerta informando que o Estudante foi encontrado e que este id existe
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("ID de Estudante Já existe");
            alert.setContentText("O Estudante com este ID informado já existe. Crie e Utilize um novo ID e tente novamente.");
            alert.showAndWait();
            return;

        }

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para fechar a tela depois de aceitar um estudante que se quer adicionar
    }

    // Verificar se o usuário com o UsuarioID informado existe
//        Usuario usuarioCorrespondente = null;
//        for (Usuario usuario : listaUsuarioExistente) {
//            if (usuario.getUsuarioID() == usuarioID) {
//                usuarioCorrespondente = usuario;
//                break;
//            }
//        }
////        if (usuarioCorrespondente == null) {
//} else {
//
//            
//        }    
//---------------------------------------------------------
    //        Node source = (Node) event.getSource();
    //        Scene scene = source.getScene();
    //        Stage stage = (Stage)scene.getWindow();
    //---------------------------------------------------------
    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma 1 que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        populateListaUsuarioExistente();
        populateListaEstudanteExistente();

    }

    private void populateListaUsuarioExistente() {
        //------------Permite aparecer dados na tabela de lista Estudante--------------------
        usuarioService = new UsuarioService(new UsuarioDAOJdbc());
        listaUsuario = FXCollections.emptyObservableList();
        try {
            listaUsuario = FXCollections.observableList(usuarioService.findAll());
            oldListaUsuario.addAll(listaUsuario);

            // Preencher a lista de usuários existentes com os IDs
            for (Usuario usuario : listaUsuario) {
                listaUsuarioExistente.add(usuario.getUsuarioID());
            }

        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os usuários", ex.getMessage());
        }

    }

    private void populateListaEstudanteExistente() {
        //------------Permite aparecer dados na tabela de lista Estudante--------------------
        estudanteService = new EstudanteService(new EstudanteDAOJdbc());
        listaEstudante = FXCollections.emptyObservableList();
        try {
            listaEstudante = FXCollections.observableList(estudanteService.findAll());
            oldListaEstudante.addAll(listaEstudante);

            // Preencher a lista de estudantes existentes com os IDs
            for (Estudante estudante : listaEstudante) {
                listaEstudanteExistente.add(estudante.getID());
            }

        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os estudantes", ex.getMessage());
        }

    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }

}
