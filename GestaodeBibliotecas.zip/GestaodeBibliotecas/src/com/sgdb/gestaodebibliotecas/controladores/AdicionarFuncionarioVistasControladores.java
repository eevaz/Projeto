/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.FuncionarioDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Funcionario;
import com.sgdb.gestaodebibliotecas.service.FuncionarioService;
import com.sgdb.gestaodebibliotecas.service.IFuncionarioService;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AdicionarFuncionarioVistasControladores implements Initializable {

    private IFuncionarioService funcionarioService;
    private ObservableList<Funcionario> listaFuncionario;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtCargo;

    public void setListaFuncionario(ObservableList<Funcionario> listaFuncionario) {
        this.listaFuncionario = listaFuncionario;
    }

    private final List<Funcionario> oldListaFuncionario = new ArrayList<>();

    private final List<Integer> listaFuncionarioExistente = new ArrayList<>();

//---------------------------------------------------------
    //acao para aceitar um funionario que se quer adicionar
    public void onActionAceitar(ActionEvent event) throws DaoException {
        boolean isIdValid = true;
        int id = 0;

        if (txtID.getText().isEmpty() || txtNome.getText().isEmpty() || txtCargo.getText().isEmpty()) {
            // Exibir mensagem de aviso informando que algum campo está vazio
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Campos vazios");
            alert.setContentText("Preencha todos os campos antes de aceitar.");
            alert.showAndWait();
            return;
        }

        try {
            id = Integer.parseInt(txtID.getText());
        } catch (NumberFormatException e) {
            isIdValid = false;
        }

        // Verificar a validade do campo UsuarioID
        if (!isIdValid) {
            // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo ID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

        // Verificar se o funcionario com o ID informado existe
         boolean funcionarioExiste = listaFuncionarioExistente.contains(id);
    if (!funcionarioExiste) {
        
        // Funcionário com este id informado nao existe
        
        // Adicionar o Funcionario apenas se o campo for válido
        Funcionario funcionario = new Funcionario();
        FuncionarioDAOJdbc f = new FuncionarioDAOJdbc();
        funcionario.setID(id);
        funcionario.setNome(txtNome.getText());
        funcionario.setCargo(txtCargo.getText());
        listaFuncionario.add(funcionario);
        f.add(funcionario);
////edson atualizaco 13/07/2023 6:53
// try {
//                funcionarioService.add(funcionario);
        // Exibir mensagem de Adição de Usuário com sucesso
        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
        successAlert.setTitle("Sucesso");
        successAlert.setHeaderText(null);
        successAlert.setContentText("Adição de Funcionario realizado com sucesso!");
        successAlert.showAndWait();
        
 } else {
// Funcionário já Existe
        // Exibir mensagem de alerta informando que o Funcionário foi encontrado e que este id existe
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Funcionário Já existe");
        alert.setContentText("O Funcionário com este ID informado já existe. Utilize outro ID ou crie um novo e tente novamente.");
        alert.showAndWait();
        return;
        
    }
    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para fechar a tela depois de aceitar um usuário que se quer adicionar
    }
//            } catch (ServiceException ex) {
//                String mssg = "Verifique a conexão com a base de dados";
//                showAlertMessage(Alert.AlertType.ERROR, "Error",
//                        "Erro adicionando o Funcionario", mssg);
//            }
    //--------------------------------------------------
    //        Node source = (Node) event.getSource();
//        Scene scene = source.getScene();
//        Stage stage = (Stage)scene.getWindow();
    //--------------------------------------------------
    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma 1 que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        populateListaFuncionarioExistente();
    }

    private void populateListaFuncionarioExistente() {
        //------------Permite adicionar na lista existente de Funcionario os ID de cada Funcionario--------------------
        funcionarioService = new FuncionarioService(new FuncionarioDAOJdbc());
        listaFuncionario = FXCollections.emptyObservableList();
        try {
            listaFuncionario = FXCollections.observableList(funcionarioService.findAll());
            oldListaFuncionario.addAll(listaFuncionario);

            // Preencher a lista de usuários existentes com os IDs
            for (Funcionario funcionario : listaFuncionario) {
                listaFuncionarioExistente.add(funcionario.getID());
            }

        } catch (ServiceException ex) {
            showAlertMessage(Alert.AlertType.ERROR, "Erro",
                    "Erro carregando os usuários", ex.getMessage());
        }

    }

    private Optional<ButtonType> showAlertMessage(Alert.AlertType type, String title,
            String headerText, String mssg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.setContentText(mssg);
        return alert.showAndWait();
    }

}
