/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.controladores;

import com.sgdb.gestaodebibliotecas.data.MultaDAOJdbc;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.modelo.Multa;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author EDSON VAZ
 */
public class AtualizarMultaVistasControladores implements Initializable {

    private Multa multa;

    @FXML
    private DatePicker txtDataAplicacao;

    @FXML
    private TextField txtFuncionarioID;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtPublicacaoISBN;

    @FXML
    private TextField txtUsuarioID;

    @FXML
    private TextField txtValor;
    /**
     * @param multa
     */
    
    public void setMulta(Multa multa) {
        this.multa = multa;
        txtID.setText(Integer.toString(multa.getID()));
        txtUsuarioID.setText(Integer.toString(multa.getUsuarioID()));
        txtValor.setText(Integer.toString(multa.getValor()));
        txtFuncionarioID.setText(Integer.toString(multa.getFuncionarioID()));
        txtPublicacaoISBN.setText(multa.getPublicacaoISBN());
        txtDataAplicacao.setValue(multa.getDataAplicacao());

    }

   public void onActionAceitar(ActionEvent event) throws DaoException {
    // Verificação de campos vazios
    if (txtID.getText().isEmpty() || txtValor.getText().isEmpty() || txtUsuarioID.getText().isEmpty() || txtFuncionarioID.getText().isEmpty() || txtPublicacaoISBN.getText().isEmpty()||txtDataAplicacao.getValue()==null) {
        // Exibir mensagem de aviso informando que algum campo está vazio
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Campos vazios");
        alert.setContentText("Preencha todos os campos antes de aceitar.");
        alert.showAndWait();
        return;
    }

    // Verificação de números inteiros
    boolean isIDValido = true;
    boolean isValorValido = true;
    boolean isUsuarioIDValido = true;
    boolean isFuncionarioIDValido = true;

    int id = 0;
    int valor = 0;
    int usuarioID = 0;
    int funcionarioID = 0;

    try {
        id = Integer.parseInt(txtID.getText());
    } catch (NumberFormatException e) {
        isIDValido = false;
    }

    try {
        valor = Integer.parseInt(txtValor.getText());
    } catch (NumberFormatException e) {
        isValorValido = false;
    }

    try {
        usuarioID = Integer.parseInt(txtUsuarioID.getText());
    } catch (NumberFormatException e) {
        isUsuarioIDValido = false;
    }

    try {
        funcionarioID = Integer.parseInt(txtFuncionarioID.getText());
    } catch (NumberFormatException e) {
        isFuncionarioIDValido = false;
    }

    // Verificar a validade dos campos individualmente
    if (!isIDValido && !isValorValido && !isUsuarioIDValido && !isFuncionarioIDValido) {
        // Exibir mensagem de alerta informando que os campos estão inválidos
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Aviso");
        alert.setHeaderText("Valores inválidos");
        alert.setContentText("Os campos ID, Valor, UsuarioID e FuncionarioID devem conter números inteiros.");
        alert.showAndWait();
        return;
    } else {
        if (!isIDValido) {
            // Exibir mensagem de alerta informando que o campo ID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo ID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

        if (!isValorValido) {
            // Exibir mensagem de alerta informando que o campo Valor está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo Valor deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

        if (!isUsuarioIDValido) {
            // Exibir mensagem de alerta informando que o campo UsuarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo UsuarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }

        if (!isFuncionarioIDValido) {
            // Exibir mensagem de alerta informando que o campo FuncionarioID está inválido
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Aviso");
            alert.setHeaderText("Valor inválido");
            alert.setContentText("O campo FuncionarioID deve conter um número inteiro.");
            alert.showAndWait();
            return;
        }
    }

    // Verificar se houve alguma alteração nos dados antes de atualizar
    boolean isAtualizacaoSucesso = false;

    // Verificar se algum dado da multa foi alterado
    if (multa.getID() != id || multa.getValor() != valor || multa.getUsuarioID() != usuarioID || multa.getFuncionarioID() != funcionarioID || !multa.getPublicacaoISBN().equals(txtPublicacaoISBN.getText()) || !multa.getDataAplicacao().equals(txtDataAplicacao.getValue())) {
        // Atualizar os dados da multa
        MultaDAOJdbc multar = new MultaDAOJdbc();
        multa.setID(id);
        multa.setValor(valor);
        multa.setUsuarioID(usuarioID);
        multa.setFuncionarioID(funcionarioID);
        multa.setPublicacaoISBN(txtPublicacaoISBN.getText());
        multa.setDataAplicacao(txtDataAplicacao.getValue());
        multar.update(multa);

        isAtualizacaoSucesso = true;
    }

    // Exibir mensagem de sucesso ou informação
    if (isAtualizacaoSucesso) {
        // Exibir mensagem de atualização da multa com sucesso
        Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
        successAlert.setTitle("Sucesso");
        successAlert.setHeaderText(null);
        successAlert.setContentText("Atualização da multa realizada com sucesso!");
        successAlert.showAndWait();
    } else {
        // Exibir mensagem informando que nenhum dado foi atualizado
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informação");
        alert.setHeaderText(null);
        alert.setContentText("Nenhum dado da multa foi atualizado.");
        alert.showAndWait();
    }

    // Fechar a janela atual
    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    stage.close();
}

    

    public void onActionCancelar(ActionEvent event) {
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close(); // serve para cancelar uma publicacao que nao quer adicionar  
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
