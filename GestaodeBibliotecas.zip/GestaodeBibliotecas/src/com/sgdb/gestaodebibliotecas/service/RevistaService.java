/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.RevistaDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Revista;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public class RevistaService implements IRevistaService {

    private RevistaDAO revistaDAO;

    public RevistaService(RevistaDAO revistaDAO) {
        this.revistaDAO = revistaDAO;
    }

    @Override
    public void addAll(Revista o) throws ServiceException {
        if (o.getISBN().isBlank()) {
            throw new ServiceException("O ISBN da Revista é invalido");
        }
        try {
            revistaDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao adicionar a Revista. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
    //---------------------------------------------------------------------------------

    @Override
    public void removeAll(String ISBN) throws ServiceException {
        try {
            revistaDAO.removeAll(ISBN);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao excluir a Revista. "
                    + "Esta Revista não pode ser eliminado porque "
                    + "possui uma restrição de chave estrangeira (FOREIGN KEY) em outras tabelas. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public void update(Revista o) throws ServiceException {
        if (o.getISBN().isBlank()) {
            throw new ServiceException("O ISBN da Revista é invalido");
        }
        try {
            revistaDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao atualizar a Revista. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Revista> findAll() throws ServiceException {
        List<Revista> listaRevista = new ArrayList<>();
        try {
            listaRevista.addAll(revistaDAO.findAll());

        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler as revistas. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaRevista;
    }

    @Override
    public List<Revista> findByISBN(String isbn) throws ServiceException {
         List<Revista> listaRevista = new ArrayList<>();
        try {
            listaRevista.addAll(revistaDAO.findByISBN(isbn));
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler as revistas por isbn. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaRevista;
    }
//---------------------------------------------------------------------------------
    @Override
    public List<Revista> findByTitulo(String titulo) throws ServiceException {
       List<Revista> listaRevista = new ArrayList<>();
    try {
        listaRevista.addAll(revistaDAO.findByTitulo(titulo));
    } catch (DaoException ex) {
        throw new ServiceException("Erro ao ler as revistas por título. "
                + "Revise a conexão à base de dados", ex);
    }
    return listaRevista;
}
//---------------------------------------------------------------------------------
   

    @Override
    public List<Revista> findByEditora(String editora) throws ServiceException {
     List<Revista> listaRevista = new ArrayList<>();
    try {
        listaRevista.addAll(revistaDAO.findByEditora(editora));
    } catch (DaoException ex) {
        throw new ServiceException("Erro ao ler as revistas por editora. "
                + "Revise a conexão à base de dados", ex);
    }
    return listaRevista;
}
//---------------------------------------------------------------------------------

}
