/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Livro;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public interface ILivroService extends IService<Livro> {

    public List<Livro> findByISBN(String isbn) throws ServiceException;

    public List<Livro> findByTitulo(String titulo) throws ServiceException;

    public List<Livro> findByAutor(String autor) throws ServiceException;

}
