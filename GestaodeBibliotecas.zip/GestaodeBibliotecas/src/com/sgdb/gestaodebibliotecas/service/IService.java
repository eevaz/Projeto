
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import java.util.List;

/**
 *
 * @author user
 */
public interface IService<T>{

    void addAll(T o)throws ServiceException; 
    
    void removeAll(String ISBN)throws ServiceException;
    
    void update(T o)throws ServiceException; 
    
     List<T> findAll() throws ServiceException; 
}