/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Trabalhador;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public interface ITrabalhadorService extends IIService <Trabalhador> {
    
    public Optional<Trabalhador> findById(int id) throws ServiceException ;
    
    public List<Trabalhador> findByNome(String nome) throws ServiceException ;
    
    public List<Trabalhador> findByCargo(String cargo) throws ServiceException ;
   
    public List<Trabalhador> findByCentroDeTrabalho(String centrodetrabalho) throws ServiceException ;

    
}