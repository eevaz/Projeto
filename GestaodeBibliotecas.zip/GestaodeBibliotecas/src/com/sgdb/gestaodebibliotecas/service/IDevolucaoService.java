/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Devolucao;
import java.util.Optional;

/**
 *
 * @author user
 */
public interface IDevolucaoService extends IIService<Devolucao>{
    
    public Optional<Devolucao> findById(int id) throws ServiceException ;
}
