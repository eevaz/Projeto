/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.TrabalhadorDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Trabalhador;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public class TrabalhadorService implements ITrabalhadorService {

    private TrabalhadorDAO trabalhadorDAO;

    public TrabalhadorService(TrabalhadorDAO trabalhadorDAO) {
        this.trabalhadorDAO = trabalhadorDAO;
    }
//---------------------------------------------------------------------------------    

    @Override
    public void add(Trabalhador o) throws ServiceException {
        if (o.getNome().isBlank()) {
            throw new ServiceException("O nome do trabalhador é invalido");
        }
        try {
            trabalhadorDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao adicionar o trabalhador. "
                    + "Revise a conexão à base de dados", ex);
        }
    }

    //---------------------------------------------------------------------------------
    @Override
    public void remove(int id) throws ServiceException {
        try {
            trabalhadorDAO.remove(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao eliminar o trabalhador. "
                    + "Este trabalhador não pode ser eliminado porque "
                    + "possui uma restrição de chave estrangeira (FOREIGN KEY) em outras tabelas. "
                    + "  Revise a conexão à base de dados", ex);
        }
    }

//---------------------------------------------------------------------------------
    @Override
    public void update(Trabalhador o) throws ServiceException {
       if (o.getNome().isBlank()) {
            throw new ServiceException("O nome do trabalhador é invalido");
        }
        try {
            trabalhadorDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao atualizar o trabalhador. "
                    + "Revise a conexão à base de dados", ex);
        }
    }

    //--------------------------------------------------------------------------------------
    @Override
    public List<Trabalhador> findAll() throws ServiceException {
        List<Trabalhador> listaTrabalhador = new ArrayList<>();
        try {
            listaTrabalhador.addAll(trabalhadorDAO.findAll());

        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os trabalhadores. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaTrabalhador;
    }
    //--------------------------------------------------------------------------------------

    @Override
    public Optional<Trabalhador> get(int id) throws ServiceException {
         Optional<Trabalhador> optionalTrabalhador = Optional.empty();
        try {
            optionalTrabalhador = trabalhadorDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler o trabalhador. "
                    + "Revise a conexão à base de dados", ex);
        }
        return optionalTrabalhador;
    }
//---------------------------------------------------------------------------------

    @Override
    public Optional<Trabalhador> findById(int id) throws ServiceException {
        Optional<Trabalhador> optionalTrabalhador = Optional.empty();
        try {
            optionalTrabalhador = trabalhadorDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os trabalhadores por id. "
                    + "Revise a conexão à base de dados", ex);
        }
        return optionalTrabalhador;
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Trabalhador> findByNome(String nome) throws ServiceException {
         List<Trabalhador> listaTrabalhador = new ArrayList<>();
        try {
            listaTrabalhador.addAll(trabalhadorDAO.findByNome(nome));
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os trabalhadores por nome. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaTrabalhador;
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Trabalhador> findByCargo(String cargo) throws ServiceException {
      List<Trabalhador> listaTrabalhador = new ArrayList<>();
    try {
        listaTrabalhador.addAll(trabalhadorDAO.findByCargo(cargo));
    } catch (DaoException ex) {
        throw new ServiceException("Erro ao ler os trabalhadores por cargo. "
                + "Revise a conexão à base de dados", ex);
    }
    return listaTrabalhador;
}
//---------------------------------------------------------------------------------

    @Override
    public List<Trabalhador> findByCentroDeTrabalho(String centrodetrabalho) throws ServiceException {
     List<Trabalhador> listaTrabalhador = new ArrayList<>();
    try {
        listaTrabalhador.addAll(trabalhadorDAO.findByCentroDeTrabalho(centrodetrabalho));
    } catch (DaoException ex) {
        throw new ServiceException("Erro ao ler os trabalhadores por centro de trabalho. "
                + "Revise a conexão à base de dados", ex);
    }
    return listaTrabalhador;
}
//---------------------------------------------------------------------------------
}
