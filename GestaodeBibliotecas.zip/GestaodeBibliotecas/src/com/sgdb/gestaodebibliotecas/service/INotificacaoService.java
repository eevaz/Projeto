/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Notificacao;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author user
 */
public interface INotificacaoService extends IServiceNotificacao<Notificacao> {
    public Optional<Notificacao> findById(int id)  throws ServiceException;
    
    public List<Notificacao> findByTipoNotificacao(String tiponotificacao)  throws ServiceException;
    
    public List<Notificacao> findByDataNotificacao(LocalDate datanotificacao)  throws ServiceException;

}
