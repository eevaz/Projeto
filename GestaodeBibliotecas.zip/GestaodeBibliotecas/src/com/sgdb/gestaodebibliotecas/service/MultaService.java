/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.MultaDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Multa;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author user
 */
public class MultaService implements IMultaService{
    
    private final MultaDAO multaDAO;
    
    public MultaService(MultaDAO multaDAO){
        this.multaDAO = multaDAO;
    }

    @Override
    public Optional<Multa> findById(int id) throws ServiceException {
       Optional<Multa> optionalMulta = Optional.empty();
        try {
            optionalMulta = multaDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler Multas por id. "
                    + "Revise a conexão à base de dados", ex);
        }
        return optionalMulta;
    }

//    @Override
//    public Optional<Multa> findByValor(int valor) throws ServiceException {
//         Optional<Multa> optionalMulta = Optional.empty();
//        try {
//            optionalMulta = multaDAO.findById(valor);
//        } catch (DaoException ex) {
//            throw new ServiceException("Erro ao ler Multa por Valor. "
//                    + "Revise a conexão à base de dados", ex);
//        }
//        return optionalMulta;
//    }

    @Override
    public void add(Multa o) throws ServiceException {
        if (o.getPublicacaoISBN().isBlank()) {
            throw new ServiceException("O ISBN da Publicacao da Multa é invalido");
        }
        if (o.getDataAplicacao()== null) {
            throw new ServiceException("A data da Aplicação da Multa tem formato incorreto");
        }
        try {
            multaDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao aplicar a Multa. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
    @Override
    public Optional<Multa> get(int id) throws ServiceException {
        Optional<Multa> optionalMulta = Optional.empty();
        try {
            optionalMulta = multaDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler o Emprestimo. "
                    + "Revise a coneção à base de dados", ex);
        }
        return optionalMulta;
    }

    @Override
    public void update(Multa o) throws ServiceException {
        if (o.getPublicacaoISBN().isBlank()) {
            throw new ServiceException("A multa é invalido");
        }
        try {
            multaDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao Reaplicar a Multa. "
                    + "Revise a conexão à base de dados", ex);
        }
    }

    @Override
    public void remove(int id) throws ServiceException {
         try {
           multaDAO.remove(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao excluir a Multa. "
                    + "Revise a conexão à base de dados", ex);
        }
    }

    @Override
    public List<Multa> findAll() throws ServiceException {
        List<Multa> listaMulta = new ArrayList<>();
        try {
            listaMulta.addAll(multaDAO.findAll());

        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler as Multa. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaMulta;
    }

    
}
