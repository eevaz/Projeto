/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public interface IIService <T>{

    void add(T o)throws ServiceException;   

    Optional<T> get(int id)throws ServiceException;

    void update(T o)throws ServiceException;      

    void remove(int id)throws ServiceException; 
    
    List<T> findAll() throws ServiceException;    
   
}

