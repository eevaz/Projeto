/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.ReservaDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Reserva;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author user
 */
public class ReservaService implements IReservaService{
    
    private ReservaDAO reservaDAO;
    
    public ReservaService(ReservaDAO reservaDAO){
        this.reservaDAO = reservaDAO;
    }

    @Override
    public Optional<Reserva> findById(int id) throws ServiceException {
        Optional<Reserva> optionalReserva = Optional.empty();
        try {
            optionalReserva = reservaDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler as Reserva por id. "
                    + "Revise a conexão à base de dados", ex);
        }
        return optionalReserva;
    }

    @Override
    public void add(Reserva o) throws ServiceException {
        if (o.getPublicacaoISBN().isBlank()) {
            throw new ServiceException("A publicacaoISBN da Reserva é invalido");
        }
        try {
            reservaDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao adicionar a Reserva. "
                    + "Revise a conexão à base de dados", ex);
        }
    }

    @Override
    public void update(Reserva o) throws ServiceException {
       if (o.getPublicacaoISBN().isBlank()) {
            throw new ServiceException("O nome da Reserva é invalido");
        }
        try {
            reservaDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao atualizar a Reserva. "
                    + "Revise a conexão à base de dados", ex);
        }
    }

    @Override
    public void remove(int id) throws ServiceException {
       try {
            reservaDAO.remove(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao excluir a Reserva. "
                    + "Revise a conexão à base de dados", ex);
        }
    }

    @Override
    public Optional<Reserva> get(int id) throws ServiceException {
         Optional<Reserva> optionalReserva = Optional.empty();
        try {
            optionalReserva = reservaDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler a Reserva. "
                    + "Revise a coneção à base de dados", ex);
        }
        return optionalReserva;
    }

    @Override
    public List<Reserva> findAll() throws ServiceException {
       List<Reserva> listaReserva = new ArrayList<>();
        try {
            listaReserva.addAll(reservaDAO.findAll());

        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os funcionarios. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaReserva;
    }
    
}
