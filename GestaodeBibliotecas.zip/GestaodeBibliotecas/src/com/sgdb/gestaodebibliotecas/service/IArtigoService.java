/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Artigo;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public interface IArtigoService extends IService<Artigo>{ 
    
     public List<Artigo> findByISBN(String isbn) throws ServiceException;

    public List<Artigo> findByTitulo(String titulo) throws ServiceException;

    public List<Artigo> findByArbitro(String arbitro) throws ServiceException;

}
