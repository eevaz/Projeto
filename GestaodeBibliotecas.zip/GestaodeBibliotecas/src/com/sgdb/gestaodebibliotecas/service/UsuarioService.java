/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.UsuarioDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Usuario;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public class UsuarioService implements IUsuarioService {

    private UsuarioDAO usuarioDAO;

    public UsuarioService(UsuarioDAO usuarioDAO) {
        this.usuarioDAO = usuarioDAO;
    }

    //---------------------------------------------------------------------------------
    @Override
    public void add(Usuario o) throws ServiceException {
        if (o.getNome().isBlank()) {
            throw new ServiceException("O nome do usuario é invalido");
        }
        try {
            usuarioDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao adicionar o usuario. "
                    + "Revise a conexão à base de dados", ex);
        }
    }

    //---------------------------------------------------------------------------------
    @Override
    public void remove(int id) throws ServiceException {
        try {
            usuarioDAO.remove(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao eliminar o usuário. "
                    + "Este usuário não pode ser eliminado porque "
                    + "possui uma restrição de chave estrangeira (FOREIGN KEY) em outras tabelas."
                    + "  Revise a conexão à base de dados", ex);
        }

    }

    //--------------------------------------------------------------------------------------
    @Override
    public void update(Usuario o) throws ServiceException {
        if (o.getNome().isBlank()) {
            throw new ServiceException("O nome do usuario é invalido");
        }
        try {
            usuarioDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao atualizar o usuario. "
                    + "Revise a conexão à base de dados", ex);
        }
    }

    //--------------------------------------------------------------------------------------
    @Override
    public List<Usuario> findAll() throws ServiceException {
        List<Usuario> listaUsuario = new ArrayList<>();
        try {
            listaUsuario.addAll(usuarioDAO.findAll());

        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os usuarios. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaUsuario;
    }

    //------------------------------------------------------------------------
    @Override
    public Optional<Usuario> get(int id) throws ServiceException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    //-------------------------------------------------------------------------------
}
