/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.modelo.Publicacao;

/**
 *
 * @author user
 */
public interface IPublicacaoService extends IService<Publicacao> {
    
}
