/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.LivroDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Livro;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public class LivroService implements ILivroService{

    
    private LivroDAO livroDAO;

    public LivroService(LivroDAO livroDAO) {
        this.livroDAO = livroDAO;
    }
    
    @Override
    public void addAll(Livro o) throws ServiceException {
        if (o.getISBN().isBlank()) {
            throw new ServiceException("O ISBN do Livro é invalido");
        }
        try {
            livroDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao adicionar o Livro. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
    //---------------------------------------------------------------------------------
    @Override
    public void removeAll(String ISBN) throws ServiceException {
        try {
            livroDAO.removeAll(ISBN);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao excluir o Livro. "
                    + "Este Livro não pode ser eliminado porque "
                    + "possui uma restrição de chave estrangeira (FOREIGN KEY) em outras tabelas. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
//---------------------------------------------------------------------------------
    @Override
    public void update(Livro o) throws ServiceException {
        if (o.getISBN().isBlank()) {
            throw new ServiceException("O ISBN do Livro é invalido");
        }
        try {
            livroDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao atualizar o Livro. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
//---------------------------------------------------------------------------------
    @Override
    public List<Livro> findAll() throws ServiceException {
         List<Livro> listaLivro = new ArrayList<>();
        try {
            listaLivro.addAll(livroDAO.findAll());

        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os Livros. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaLivro;
    }
    
    //---------------------------------------------------------------------------------

    @Override
    public List<Livro> findByISBN(String isbn) throws ServiceException {
        List<Livro> listaLivro = new ArrayList<>();
        try {
            listaLivro.addAll(livroDAO.findByISBN(isbn));
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os livros por isbn. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaLivro;
    }
//---------------------------------------------------------------------------------
    @Override
    public List<Livro> findByTitulo(String titulo) throws ServiceException {
       List<Livro> listaLivro = new ArrayList<>();
    try {
        listaLivro.addAll(livroDAO.findByTitulo(titulo));
    } catch (DaoException ex) {
        throw new ServiceException("Erro ao ler os livros por título. "
                + "Revise a conexão à base de dados", ex);
    }
    return listaLivro;
}
//---------------------------------------------------------------------------------
    @Override
    public List<Livro> findByAutor(String autor) throws ServiceException {
    List<Livro> listaLivro = new ArrayList<>();
    try {
        listaLivro.addAll(livroDAO.findByAutor(autor));
    } catch (DaoException ex) {
        throw new ServiceException("Erro ao ler os livros por autor. "
                + "Revise a conexão à base de dados", ex);
    }
    return listaLivro;
}
//---------------------------------------------------------------------------------
}
