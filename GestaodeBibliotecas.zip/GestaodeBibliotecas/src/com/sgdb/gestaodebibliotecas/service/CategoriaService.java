/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.CategoriaDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Categoria;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public class CategoriaService implements ICategoriaService{

    private CategoriaDAO categoriaDAO;

    public CategoriaService(CategoriaDAO categoriaDAO) {
        this.categoriaDAO = categoriaDAO;
    }
//---------------------------------------------------------------------------------
 
    
    @Override
    public void addAll(Categoria o) throws ServiceException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void removeAll(String ISBN) throws ServiceException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(Categoria o) throws ServiceException {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Categoria> findAll() throws ServiceException {
            List<Categoria> listaCategoria = new ArrayList<>();
         try {
             listaCategoria.addAll(categoriaDAO.findAll());

         } catch (DaoException ex) {
             throw new ServiceException("Erro ao ler as Categorias. "
                     + "Revise a conexão à base de dados", ex);
         }
        return listaCategoria;
    }
    
}
