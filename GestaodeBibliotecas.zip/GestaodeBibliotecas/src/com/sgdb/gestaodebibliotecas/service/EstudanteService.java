/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.EstudanteDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Estudante;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public class EstudanteService implements IEstudanteService {

    private EstudanteDAO estudanteDAO;

    public EstudanteService(EstudanteDAO estudanteDAO) {
        this.estudanteDAO = estudanteDAO;
    }
//---------------------------------------------------------------------------------
    @Override
    public void add(Estudante o) throws ServiceException {
      if (o.getNome().isBlank()) {
            throw new ServiceException("O nome do estudante é invalido");
        }
        try {
           estudanteDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao adicionar o estudante. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
    //--------------------------------------------------------------------------------------
     @Override
    public void remove(int id) throws ServiceException {
      try {
            estudanteDAO.remove(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao eliminar o estudante. "
                    + "Este etudante não pode ser eliminado porque "
                    + "possui uma restrição de chave estrangeira (FOREIGN KEY) em outras tabelas. "
                    + " Revise a conexão à base de dados", ex);
        }
    }

//--------------------------------------------------------------------------------------

    @Override
    public void update(Estudante o) throws ServiceException {
         if (o.getNome().isBlank()) {
            throw new ServiceException("O nome do estudante é invalido");
        }
        try {
            estudanteDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao atualizar o estudante. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
    //--------------------------------------------------------------------------------------
   
    @Override
    public List<Estudante> findAll() throws ServiceException {
        List<Estudante> listaEstudante = new ArrayList<>();
        try {
            listaEstudante.addAll(estudanteDAO.findAll());

        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os estudantes. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaEstudante;
    }
    //--------------------------------------------------------------------------------------

  @Override
public Optional<Estudante> get(int id) throws ServiceException {
     Optional<Estudante> optionalEstudante = Optional.empty();
        try {
            optionalEstudante = estudanteDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler o estudante. "
                    + "Revise a conexão à base de dados", ex);
        }
        return optionalEstudante;
    }
//---------------------------------------------------------------------------------
    @Override
    public Optional<Estudante> findById(int id) throws ServiceException {
       Optional<Estudante> optionalEstudante = Optional.empty();
        try {
            optionalEstudante = estudanteDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os estudantes por id. "
                    + "Revise a conexão à base de dados", ex);
        }
        return optionalEstudante;
    }
//---------------------------------------------------------------------------------
    @Override
    public List<Estudante> findByNome(String nome) throws ServiceException {
       List<Estudante> listaEstudante = new ArrayList<>();
        try {
            listaEstudante.addAll(estudanteDAO.findByNome(nome));
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os estudantes por nome. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaEstudante;
    }
//---------------------------------------------------------------------------------
   @Override
public List<Estudante> findByNomeDaEscola(String nomedaescola) throws ServiceException {
    List<Estudante> listaEstudante = new ArrayList<>();
    try {
        listaEstudante.addAll(estudanteDAO.findByNomeDaEscola(nomedaescola));
    } catch (DaoException ex) {
        throw new ServiceException("Erro ao ler os estudantes por nome da escola. "
                + "Revise a conexão à base de dados", ex);
    }
    return listaEstudante;
}
//---------------------------------------------------------------------------------
}
