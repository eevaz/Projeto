/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.ArtigoDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Artigo;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author EDSON VAZ
 */
public class ArtigoService implements IArtigoService {

    private ArtigoDAO artigoDAO;

    public ArtigoService(ArtigoDAO artigoDAO) {
        this.artigoDAO = artigoDAO;
    }

    @Override
    public void addAll(Artigo o) throws ServiceException {
        if (o.getISBN().isBlank()) {
            throw new ServiceException("O ISBN do Artigo é invalido");
        }
        try {
            artigoDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao adicionar o Artigo. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
    //---------------------------------------------------------------------------------

    @Override
    public void removeAll(String ISBN) throws ServiceException {
        try {
            artigoDAO.removeAll(ISBN);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao excluir o Artigo. "
                    + "Este Artigo não pode ser eliminado porque "
                    + "possui uma restrição de chave estrangeira (FOREIGN KEY) em outras tabelas. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public void update(Artigo o) throws ServiceException {
        if (o.getISBN().isBlank()) {
            throw new ServiceException("O ISBN do Artigo é invalido");
        }
        try {
            artigoDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao atualizar o Artigo. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
//---------------------------------------------------------------------------------

    @Override
    public List<Artigo> findAll() throws ServiceException {
        List<Artigo> listaArtigo = new ArrayList<>();
        try {
            listaArtigo.addAll(artigoDAO.findAll());

        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os Artigos. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaArtigo;
    }
    //---------------------------------------------------------------------------------

    @Override
    public List<Artigo> findByISBN(String isbn) throws ServiceException {
         List<Artigo> listaArtigo = new ArrayList<>();
        try {
            listaArtigo.addAll(artigoDAO.findByISBN(isbn));
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os artigos por isbn. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaArtigo;
    }
//---------------------------------------------------------------------------------
 

    @Override
    public List<Artigo> findByTitulo(String titulo) throws ServiceException {
       List<Artigo> listaArtigo = new ArrayList<>();
    try {
        listaArtigo.addAll(artigoDAO.findByTitulo(titulo));
    } catch (DaoException ex) {
        throw new ServiceException("Erro ao ler os artigos por título. "
                + "Revise a conexão à base de dados", ex);
    }
    return listaArtigo;
}
//---------------------------------------------------------------------------------
    @Override
    public List<Artigo> findByArbitro(String arbitro) throws ServiceException {
    List<Artigo> listaArtigo = new ArrayList<>();
    try {
        listaArtigo.addAll(artigoDAO.findByArbitro(arbitro));
    } catch (DaoException ex) {
        throw new ServiceException("Erro ao ler os artigos por autor. "
                + "Revise a conexão à base de dados", ex);
    }
    return listaArtigo;
}
//---------------------------------------------------------------------------------

}
