/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.NotificacaoDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Notificacao;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author user
 */
public class NotificacaoService implements INotificacaoService {

    private NotificacaoDAO notificacaoDAO;

    public NotificacaoService(NotificacaoDAO notificacaoDAO) {
        this.notificacaoDAO = notificacaoDAO;
    }

    @Override
    public void add(Notificacao o) throws ServiceException {
        if (o.getTipoNotificacao().isBlank()) {
            throw new ServiceException("O Tipo da Notificacao é invalido");
        }
        try {
            notificacaoDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao adicionar a Notificacao. "
                    + "Revice a coneção à base de dados", ex);
        }

    }

    @Override
    public void remove(int ID) throws ServiceException {
        try {
            notificacaoDAO.remove(ID);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao excluir a notificacao. "
                    + "Revice a coneção à base de dados", ex);
        }
    }

    @Override
    public void update(Notificacao o) throws ServiceException {
        if (o.getTipoNotificacao().isBlank()) {
            throw new ServiceException("O Tipo da Publicacao é invalido");
        }
        try {
            notificacaoDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao reenviar a Notificacao. "
                    + "Revice a coneção à base de dados", ex);
        }
    }

    @Override
    public List<Notificacao> findAll() throws ServiceException {
        List<Notificacao> listaNotificacao = new ArrayList<>();
        try {
            listaNotificacao.addAll(notificacaoDAO.findAll());

        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler as Notificacoes. Reveja a conexão com a base de dados", ex);
        }
        return listaNotificacao;
    }

    @Override
    public Optional<Notificacao> findById(int id) throws ServiceException {
        Optional<Notificacao> optionalNotificacao = Optional.empty();
        try {
            optionalNotificacao = notificacaoDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler as Notificacoes por id. "
                    + "Revise a conexão à base de dados", ex);
        }
        return optionalNotificacao;
    }

    @Override
    public List<Notificacao> findByTipoNotificacao(String tiponotificacao) throws ServiceException {
        List<Notificacao> listaNotificacao = new ArrayList<>();
        try {
            listaNotificacao.addAll(notificacaoDAO.findByTipoNotificacao(tiponotificacao));
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler as notificacao por tipo. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaNotificacao;
    }

    @Override
    public List<Notificacao> findByDataNotificacao(LocalDate datanotificacao) throws ServiceException {
        List<Notificacao> listaNotificacao = new ArrayList<>();
        try {
            listaNotificacao.addAll(notificacaoDAO.findByDataNotificacao(datanotificacao));
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler as notoificacoes por data. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaNotificacao;
    }

    @Override
    public Optional<Notificacao> get(int id) throws ServiceException {
        Optional<Notificacao> optionalNotificacao = Optional.empty();
        try {
            optionalNotificacao = notificacaoDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler a notificacao . "
                    + "Revise a coneção à base de dados", ex);
        }
        return optionalNotificacao;
    }

}
