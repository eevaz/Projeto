/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.FuncionarioDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Funcionario;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public class FuncionarioService implements IFuncionarioService {

    private FuncionarioDAO funcionarioDAO;

    public FuncionarioService(FuncionarioDAO funcionarioDAO) {
        this.funcionarioDAO = funcionarioDAO;
    }
//---------------------------------------------------------------------------------
    @Override
    public void add(Funcionario o) throws ServiceException {
        if (o.getNome().isBlank()) {
            throw new ServiceException("O nome do funcionario é invalido");
        }
        try {
            funcionarioDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao adicionar o funcionario. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
//---------------------------------------------------------------------------------
     @Override
    public void remove(int id) throws ServiceException {
        try {
            funcionarioDAO.remove(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao excluir o funcionario. "
                   + "Este Funcionario não pode ser eliminado porque "
                    + "possui uma restrição de chave estrangeira (FOREIGN KEY) em outras tabelas. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
//--------------------------------------------------------------------------------------
    
    @Override
    public void update(Funcionario o) throws ServiceException {
        if (o.getNome().isBlank()) {
            throw new ServiceException("O nome do funcionario é invalido");
        }
        try {
            funcionarioDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao atualizar o funcionario. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
//----------------------------------------------------------------------------------
   
    @Override
    public List<Funcionario> findAll() throws ServiceException {
        List<Funcionario> listaFuncionario = new ArrayList<>();
        try {
            listaFuncionario.addAll(funcionarioDAO.findAll());

        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os funcionarios. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaFuncionario;
    }
    //------------------------------------------------------------------------
 @Override
    public Optional<Funcionario> get(int id) throws ServiceException {
        Optional<Funcionario> optionalFuncionario = Optional.empty();
        try {
            optionalFuncionario = funcionarioDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler o funcionario. "
                    + "Revise a conexão à base de dados", ex);
        }
        return optionalFuncionario;
    }
//----------------------------------------------------------------------------------------
    @Override
    public Optional<Funcionario> findById(int id) throws ServiceException {
   Optional<Funcionario> optionalFuncionario = Optional.empty();
        try {
            optionalFuncionario = funcionarioDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os funcionarios por id. "
                    + "Revise a conexão à base de dados", ex);
        }
        return optionalFuncionario;
    }
    //-------------------------------------------------------------------------------------
    @Override
    public List<Funcionario> findByNome(String nome) throws ServiceException {
        List<Funcionario> listaFuncionario = new ArrayList<>();
        try {
            listaFuncionario.addAll(funcionarioDAO.findByNome(nome));
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os funcionarios por nome. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaFuncionario;
    }
    //-----------------------------------------------------------------------------
 @Override
    public List<Funcionario> findByCargo(String cargo) throws ServiceException {
        List<Funcionario> listaFuncionario = new ArrayList<>();
        try {
            listaFuncionario.addAll(funcionarioDAO.findByCargo(cargo));
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os funcionarios por cargo. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaFuncionario;
    }
//---------------------------------------------------------------------------------
}
