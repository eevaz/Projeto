/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.PublicacaoDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Publicacao;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class PublicacaoService implements IPublicacaoService{
    
        private PublicacaoDAO publicacaoDAO;

    public PublicacaoService(PublicacaoDAO publicacaoDAO) {
        this.publicacaoDAO = publicacaoDAO;
    }
//---------------------------------------------------------------------------------
    @Override
    public void addAll(Publicacao o) throws ServiceException {
        if (o.getISBN().isBlank()) {
            throw new ServiceException("O ISBN da Publicação é invalido");
        }
        try {
            publicacaoDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao adicionar a Publicação. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
  //---------------------------------------------------------------------------------  
     @Override
    public void removeAll(String ISBN) throws ServiceException {
        try {
            publicacaoDAO.removeAll(ISBN);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao excluir a Publicação. "
                   + "Esta Publicação não pode ser eliminado porque "
                    + "possui uma restrição de chave estrangeira (FOREIGN KEY) em outras tabelas. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
//---------------------------------------------------------------------------------
    @Override
    public void update(Publicacao o) throws ServiceException {
        if (o.getISBN().isBlank()) {
            throw new ServiceException("O ISBN da Publicação é invalido");
        }
        try {
            publicacaoDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao atualizar a Publicação. "
                    + "Revise a conexão à base de dados", ex);
        }
    }
//---------------------------------------------------------------------------------
    @Override
    public List<Publicacao> findAll() throws ServiceException {
                List<Publicacao> listaPublicacaos = new ArrayList<>();
         try {
             listaPublicacaos.addAll(publicacaoDAO.findAll());

         } catch (DaoException ex) {
             throw new ServiceException("Erro ao ler as Publicacoes. "
                     + "Revise a conexão à base de dados", ex);
         }
        return listaPublicacaos;
    }
    //---------------------------------------------------------------------------------
}
