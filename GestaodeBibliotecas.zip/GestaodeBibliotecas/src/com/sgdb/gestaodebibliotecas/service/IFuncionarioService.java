/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Funcionario;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author EDSON VAZ
 */
public interface IFuncionarioService extends IIService<Funcionario>{ 
    
    public Optional<Funcionario> findById(int id) throws ServiceException ;
    
    public List<Funcionario> findByNome(String nome) throws ServiceException ;
    
    public List<Funcionario> findByCargo(String cargo) throws ServiceException ;

    
    
}

    

