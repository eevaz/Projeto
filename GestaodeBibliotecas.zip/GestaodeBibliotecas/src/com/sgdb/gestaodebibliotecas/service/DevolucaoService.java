/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.DevolucaoDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Devolucao;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author user
 */
public class DevolucaoService implements IDevolucaoService{
    
    private DevolucaoDAO devolucaoDAO;
    
    public DevolucaoService(DevolucaoDAO devolucaoDAO){
        this.devolucaoDAO = devolucaoDAO;
    }

    @Override
    public Optional<Devolucao> findById(int id) throws ServiceException {
       Optional<Devolucao> optionalDevolucao = Optional.empty();
        try {
            optionalDevolucao = devolucaoDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler Devolucao por EmprestimoID. "
                    + "Revice a conexão à base de dados", ex);
        }
        return optionalDevolucao;
    }

    @Override
    public void add(Devolucao o) throws ServiceException {
         if (o.getDataDevolucao()== null) {
            throw new ServiceException("A DateDevolucao  é invalido");
        }
        try {
            devolucaoDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao fazer Devolucao. "
                    + "Revice a coneção à base de dados", ex);
        }
    }

    @Override
    public Optional<Devolucao> get(int id) throws ServiceException {
        Optional<Devolucao> optionalDevolucao = Optional.empty();
        try {
            optionalDevolucao = devolucaoDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler o Devolucao. "
                    + "Revice a coneção à base de dados", ex);
        }
        return optionalDevolucao;
    }

    @Override
    public void update(Devolucao o) throws ServiceException {
        if (o.getDataDevolucao()== null) {
            throw new ServiceException("A data Devolucao é invalido");
        }
        try {
            devolucaoDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao atualizar o devolucao. "
                    + "Revice a coneção à base de dados", ex);
        }
    }

    @Override
    public void remove(int id) throws ServiceException {
       try {
            devolucaoDAO.remove(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao excluir o Devolucao. "
                    + "Revice a coneção à base de dados", ex);
        }
    }

    @Override
    public List<Devolucao> findAll() throws ServiceException {
         List<Devolucao> listaDevolucao = new ArrayList<>();
        try {
            listaDevolucao.addAll(devolucaoDAO.findAll());

        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler Devolucao. "
                    + "Revice a coneção à base de dados", ex);
        }
        return listaDevolucao;
    }
    
}
