/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.service;

import com.sgdb.gestaodebibliotecas.data.EmprestimoDAO;
import com.sgdb.gestaodebibliotecas.exception.DaoException;
import com.sgdb.gestaodebibliotecas.exception.ServiceException;
import com.sgdb.gestaodebibliotecas.modelo.Emprestimo;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author user
 */
public class EmprestimoService implements IEmprestimoService {

    private EmprestimoDAO emprestimoDAO;

    public EmprestimoService(EmprestimoDAO emprestimoDAO) {
        this.emprestimoDAO = emprestimoDAO;
    }

    @Override
    public Optional<Emprestimo> findById(int id) throws ServiceException {
        Optional<Emprestimo> optionalEmprestimo = Optional.empty();
        try {
            optionalEmprestimo = emprestimoDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os emprestimos por id. "
                    + "Revise a conexão à base de dados", ex);
        }
        return optionalEmprestimo;
    }

    @Override
    public void add(Emprestimo o) throws ServiceException {
        if (o.getPublicacaoISBN().isBlank()) {
            throw new ServiceException("O nome do Emprestimo é invalido");
        }
        try {
            emprestimoDAO.add(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao adicionar o Emprestimo. "
                    + "Revise a conexão à base de dados", ex);
        }
    }

    @Override
    public Optional<Emprestimo> get(int id) throws ServiceException {
        Optional<Emprestimo> optionalEmprestimo = Optional.empty();
        try {
            optionalEmprestimo = emprestimoDAO.findById(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler o Emprestimo. "
                    + "Revise a coneção à base de dados", ex);
        }
        return optionalEmprestimo;
    }

    @Override
    public void update(Emprestimo o) throws ServiceException {
        if (o.getPublicacaoISBN().isBlank()) {
            throw new ServiceException("O Emprestimo é invalido");
        }
        try {
            emprestimoDAO.update(o);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao atualizar o Emprestimo. "
                    + "Revise a conexão à base de dados", ex);
        }
    }

    @Override
    public void remove(int id) throws ServiceException {
        try {
            emprestimoDAO.remove(id);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao excluir o Emprestimo. "
                    + "Revise a conexão à base de dados", ex);
        }
    }

    @Override
    public List<Emprestimo> findAll() throws ServiceException {
        List<Emprestimo> listaEmprestimo = new ArrayList<>();
        try {
            listaEmprestimo.addAll(emprestimoDAO.findAll());

        } catch (DaoException ex) {
            throw new ServiceException("Erro ao ler os Emprestimos. "
                    + "Revise a conexão à base de dados", ex);
        }
        return listaEmprestimo;
    }

    @Override
    public Optional<Emprestimo> findByDataEmprestimo(LocalDate dataemprestimo) throws ServiceException {
        Optional<Emprestimo> opcionalEmprestimo = Optional.empty();
        try {
            opcionalEmprestimo = emprestimoDAO.findByDataEmprestimo(dataemprestimo);
        } catch (DaoException ex) {
            throw new ServiceException("Erro ao encontrar o emprestimo pela data."
                                   + "Revise a conexão à base de dados", ex);
        }
        return opcionalEmprestimo;
    }
//---------------------------------------------------------------------------------
}

    