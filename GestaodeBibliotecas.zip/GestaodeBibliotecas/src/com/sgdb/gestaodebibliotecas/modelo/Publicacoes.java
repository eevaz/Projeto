/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */ 
package com.sgdb.gestaodebibliotecas.modelo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author EDSON VAZ
 */
public abstract class Publicacoes {
     
   private final StringProperty ISBN = new SimpleStringProperty(this, "ISBN");
   private final StringProperty Categoria = new SimpleStringProperty(this, "Categoria");
   private final StringProperty Titulo = new SimpleStringProperty(this, "Titulo");;
   private final IntegerProperty AnoPublicacao = new SimpleIntegerProperty(this, "AnoPublicacao",0);
   private final StringProperty Autor = new SimpleStringProperty(this, "Autor");;
   private final IntegerProperty Numero_exemplar = new SimpleIntegerProperty(this, "Numero_exemplar",0);
   private final IntegerProperty Numero_exemplar_emprestado = new SimpleIntegerProperty(this, "Numero_exemplar_emprestado",0);
   private final StringProperty Tipo = new SimpleStringProperty(this, "Tipo");;

    public Publicacoes (String ISBN, String Categoria, String Titulo, int AnoPublicacao, String Autor, int Numero_exemplar, int Numero_exemplar_emprestado, String Tipo) {
        this.ISBN.set(ISBN);
        this.Categoria.set(Categoria);
        this.Titulo.set(Titulo);
        this.AnoPublicacao.set(AnoPublicacao);
        this.Autor.set(Autor);
        this.Numero_exemplar.set(Numero_exemplar);
        this.Numero_exemplar_emprestado.set(Numero_exemplar_emprestado);
        this.Tipo.set(Tipo);
    }

    public Publicacoes () {
    }

    
    /**
     * @return the ISBN
     */
    public String getISBN() {
        return ISBN.get();
    }

    /**
     * @param ISBN the ISBN to set
     */
    public void setISBN(String ISBN) {
         this.ISBN.set(ISBN);
    }
public StringProperty ISBNProperty(){
        return ISBN;
    }
//-------------------------------------------
    /**
     * @return the Categoria
     */
    public String getCategoria() {
        return Categoria.get();
    }

    /**
     * @param Categoria the Categoria to set
     */
    public void setCategoria(String Categoria) {
        this.Categoria.set(Categoria);
    }
public StringProperty CategoriaProperty(){
        return Categoria;
    }
    //-------------------------------------------------------------
    /**
     * @return the Titulo
     */
    public String getTitulo() {
        return Titulo.get();
    }

    /**
     * @param Titulo the Titulo to set
     */
    public void setTitulo(String Titulo) {
        this.Titulo.set(Titulo);
    }
    
    public StringProperty TituloProperty(){
        return Titulo;
    }
//-------------------------------------------------
    /**
     * @return the AnoPublicacao
     */
    public int getAnoPublicacao() {
        return AnoPublicacao.get();
    }

    /**
     * @param AnoPublicacao the AnoPublicacao to set
     */
    public void setAnoPublicacao(int AnoPublicacao) {
        this.AnoPublicacao.set(AnoPublicacao);
    }

    public final IntegerProperty AnoPublicacaoProperty(){
        return AnoPublicacao;
    }
    //----------------------------------------------------
    /**
     * @return the Autor
     */
    public String getAutor() {
        return Autor.get();
    }

    /**
     * @param Autor the Autor to set
     */
    public void setAutor(String Autor) {
        this.Autor.set(Autor);
    }
    
 
 //-----------------------------------------   

    /**
     * @return the Numero_exemplar
     */
    public int getNumero_exemplar() {
        return Numero_exemplar.get();
    }

    /**
     * @param Numero_exemplar the Numero_exemplar to set
     */
    public void setNumero_exemplar(int Numero_exemplar) {
        this.Numero_exemplar.set(Numero_exemplar);
    }
    
       public final IntegerProperty Numero_exemplarProperty(){
        return Numero_exemplar;
    }
//----------------------------------------------------------------
    /**
     * @return the Numero_exemplar_emprestado
     */
    public int getNumero_exemplar_emprestado() {
        return Numero_exemplar_emprestado.get();
    }

    /**
     * @param Numero_exemplar_emprestado the Numero_exemplar_emprestado to set
     */
    public void setNumero_exemplar_emprestado(int Numero_exemplar_emprestado) {
        this.Numero_exemplar_emprestado.set(Numero_exemplar_emprestado);
    }

     public final IntegerProperty Numero_exemplar_emprestadoProperty(){
        return Numero_exemplar_emprestado;
    }
    //------------------------------------------------------------
    
    /**
     * @return the Tipo
     */
    public String getTipo() {
        return Tipo.get();
    }

    /**
     * @param Tipo the Tipo to set
     */
    public void setTipo(String Tipo) {
        this.Tipo.set(Tipo);
    }
    public StringProperty TipoProperty(){
             return Tipo;
         }
}
   
//-----------------------------------------

    

