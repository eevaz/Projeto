/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.modelo;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author EDSON VAZ
 */
public class Categoria {
private  final StringProperty NomeCategoria = new SimpleStringProperty(this, "NomeCategoria");

  
    public Categoria(String NomeCategoria) {
        this.NomeCategoria.set(NomeCategoria);
    }

    public Categoria() {
    }

    
      /**
     * @return the NomeCategoria
     */
    public String getNomeCategoria() {
        return NomeCategoria.get();
    }

    /**
     * @param NomeCategoria the NomeCategoria to set
     */
    public void setNomeCategoria(String NomeCategoria) {
        this.NomeCategoria.set(NomeCategoria);
    }

     public StringProperty NomeCategoriaProperty() {
        return NomeCategoria;
    }

}
