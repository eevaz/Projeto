/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.modelo;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;



/**
 *
 * @author user
 */
public class Livro extends Publicacoes{
 
   private final StringProperty Editora = new SimpleStringProperty(this, "Editora");

    public Livro(String ISBN, String Categoria, String Titulo, int AnoPublicacao,String Editora, String Autor, int Numero_exemplar, int Numero_exemplar_emprestado, String Tipo) {
        super(ISBN, Categoria, Titulo, AnoPublicacao, Autor, Numero_exemplar, Numero_exemplar_emprestado, Tipo);
    
    this.Editora.set(Editora);
    }


    public Livro() {
    }

    
    /**
     * @return the Editora
     */
    public String getEditora() {
        return Editora.get();
    }

    /**
     * @param Editora the Editora to set
     */
    public void setEditora(String Editora) {
        this.Editora.set(Editora);
    }
    public final StringProperty EditoraProperty(){
        return Editora;
    }
  
}
