/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.modelo;

import java.time.LocalDate;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author user
 */
public class Emprestimo {
    private final IntegerProperty ID = new SimpleIntegerProperty(this, "ID");
   private final IntegerProperty UsuarioID = new SimpleIntegerProperty(this, "UsuarioID");
   private final StringProperty PublicacaoISBN = new SimpleStringProperty(this, "PublicacaoISBN");
   private final ObjectProperty<LocalDate> DataEmprestimo = new SimpleObjectProperty<>(this, "DataEmprestimo");;
   private final ObjectProperty<LocalDate> DataDevolucao = new SimpleObjectProperty<>(this, "DataDevolucao");
  

    public Emprestimo(int ID, int UsuarioID, String PublicacaoISBN, LocalDate DataEmprestimo, LocalDate DataDevolucao) {
         this.ID.set(ID);
       this.UsuarioID.set(UsuarioID);
      this.PublicacaoISBN.set(PublicacaoISBN);
        this.DataEmprestimo.set(DataEmprestimo);
        this.DataDevolucao.set(DataDevolucao);
    }
    
    public Emprestimo() {
    }

//-----------
    
    
   public int getID() {
    return ID.get();
}
  /**
 * @param ID o ID a definir
 */
public void setID(int ID) {
    this.ID.set(ID);
}

public IntegerProperty IDProperty() {
    return ID;
}
//-------------------------------------------


 public int getUsuarioID() {
    return UsuarioID.get();
}
 
   /**
 * @param ID o ID a definir
 */
public void setUsuarioID(int UsuarioID) {
    this.UsuarioID.set(UsuarioID);
}

public IntegerProperty UsuarioIDProperty() {
    return UsuarioID;
}
   //-----------------------------------

    public String getPublicacaoISBN() {
        return PublicacaoISBN.get();
    }

    public void setPublicacaoISBN(String PublicacaoISBN) {
        this.PublicacaoISBN.set(PublicacaoISBN); 
    }  
        public StringProperty PublicacaoISBNProperty() {
    return PublicacaoISBN;
}

    public LocalDate getDataEmprestimo() {
        return DataEmprestimo.get();
    }

    public void setDataEmprestimo(LocalDate DataEmprestimo) {
        this.DataEmprestimo.set(DataEmprestimo); 
    }
    
        public ObjectProperty<LocalDate> DataEmprestimoProperty() {
        return DataEmprestimo;
    }
//------------------------------------------
    public LocalDate getDataDevolucao() {
        return DataDevolucao.get();
    }

    public void setDataDevolucao(LocalDate DataDevolucao) {
        this.DataDevolucao.set(DataDevolucao);
    }
   
        public ObjectProperty<LocalDate> DataDevolucaoProperty() {
        return DataDevolucao;
    }
    
}
