/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.modelo;
import java.time.LocalDate;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
/**
 *
 * @author user
 */
public class Multa {
    private final IntegerProperty ID = new SimpleIntegerProperty(this,"ID");
    private final IntegerProperty Valor = new SimpleIntegerProperty(this,"Valor");
    private final IntegerProperty UsuarioID = new SimpleIntegerProperty(this,"UsuarioID");
    private final IntegerProperty FuncionarioID = new SimpleIntegerProperty(this,"FuncionarioID");
    private final StringProperty PublicacaoISBN = new SimpleStringProperty(this,"PublicaoISBN");;
    private final ObjectProperty<LocalDate> DataAplicacao = new SimpleObjectProperty<>(this,"DataAplicacao");

    public Multa(int ID, int Valor, int UsuarioID, int FuncionarioID, String PublicacaoISBN,LocalDate DataAplicacao) {
        this.ID.set(ID);
        this.Valor.set(Valor);
        this.UsuarioID.set(UsuarioID);
        this.FuncionarioID.set(FuncionarioID);
        this.PublicacaoISBN.set(PublicacaoISBN);
        this.DataAplicacao.set(DataAplicacao);
        
    }
    
        public Multa() {
       
    }

    public int getID() {
        return ID.get();
    }

    public void setID(int ID) {
        this.ID.set(ID);
    }
    
    public IntegerProperty IDProperty(){
        return ID;
    }

    public int getValor() {
        return Valor.get();
    }

    public void setValor(int Valor) {
        this.Valor.set(Valor);
    }
    
    public IntegerProperty ValorProperty(){
        return Valor;
    }

    public int getUsuarioID() {
        return UsuarioID.get();
    }

    public void setUsuarioID(int UsuarioID) {
        this.UsuarioID.set(UsuarioID);
    }
    
    public IntegerProperty UsuarioIDProperty(){
        return UsuarioID;
    }

    public int getFuncionarioID() {
        return FuncionarioID.get();
    }

    public void setFuncionarioID(int FuncionarioID) {
        this.FuncionarioID.set(FuncionarioID);
    }
    
    public IntegerProperty FuncionarioIDProperty(){
        return FuncionarioID;
    }

    public String getPublicacaoISBN() {
        return PublicacaoISBN.get();
    }

    public void setPublicacaoISBN(String PublicacaoISBN) {
        this.PublicacaoISBN.set(PublicacaoISBN);
    }
    
    public StringProperty PublicacaoISBNProperty(){
        return PublicacaoISBN;
    }
    
    public LocalDate getDataAplicacao() {
        return DataAplicacao.get();
    }

    public void setDataAplicacao(LocalDate DataAplicacao) {
        this.DataAplicacao.set(DataAplicacao); 
    }
    
    public ObjectProperty<LocalDate> DataAplicacaoProperty(){
        return DataAplicacao;
    }
    
    
    
}
