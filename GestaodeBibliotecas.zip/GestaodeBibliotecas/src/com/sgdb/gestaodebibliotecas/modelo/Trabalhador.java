/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.modelo;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleSetProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
/**
 *
 * @author user
 */
public class Trabalhador extends Usuarios  {

    private final IntegerProperty ID = new SimpleIntegerProperty(this, "ID",0);
    private final StringProperty Cargo = new SimpleStringProperty(this, "Cargo");
    private final StringProperty CentroDeTrabalho = new SimpleStringProperty(this, "CentroDeTrabalho");

    public Trabalhador(int ID, int UsuarioID, String Nome, String Cargo, String CentroDeTrabalho, String Email, String Telefone, String Morada, int CNI, String TipoUsuario)
    {
       super(UsuarioID, Nome, Email, Telefone, Morada, CNI,TipoUsuario);
        this.ID.set(ID);
        this.Cargo.set(Cargo);
        this.CentroDeTrabalho.set(CentroDeTrabalho);
    }

    public Trabalhador() {
    }

    /**
 * @return o ID
 */
public int getID() {
    return ID.get();
}

/**
 * @param ID o ID a definir
 */
public void setID(int ID) {
    this.ID.set(ID);
}

public IntegerProperty IDProperty() {
    return ID;
}
//-------------------------------------------
/**
 * @return o Cargo
 */
public String getCargo() {
    return Cargo.get();
}

/**
 * @param Cargo o Cargo a definir
 */
public void setCargo(String Cargo) {
    this.Cargo.set(Cargo);
}

public StringProperty CargoProperty() {
    return Cargo;
}
//-------------------------------------------
/**
 * @return o CentroDeTrabalho
 */
public String getCentroDeTrabalho() {
    return CentroDeTrabalho.get();
}

/**
 * @param CentroDeTrabalho o CentroDeTrabalho a definir
 */
public void setCentroDeTrabalho(String CentroDeTrabalho) {
    this.CentroDeTrabalho.set(CentroDeTrabalho);
}

public StringProperty CentroDeTrabalhoProperty() {
    return CentroDeTrabalho;
}

}
