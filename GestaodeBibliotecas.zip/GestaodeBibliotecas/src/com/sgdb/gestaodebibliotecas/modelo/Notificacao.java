/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.modelo;

import java.time.LocalDate;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author user
 */
public class Notificacao {

    private final IntegerProperty ID = new SimpleIntegerProperty(this, "ID");
    private final IntegerProperty UsuarioID = new SimpleIntegerProperty(this, "UsuarioID");
    private final IntegerProperty FuncionarioID = new SimpleIntegerProperty(this, "FuncionarioID");
    private final StringProperty TipoNotificacao = new SimpleStringProperty(this, "TipoNotificacao");
    private final StringProperty PublicacaoISBN = new SimpleStringProperty(this, "PublicacaoISBN");
    ;
    private final ObjectProperty<LocalDate>  DataNotificacao = new SimpleObjectProperty<>(this,"DataNotificacao");


    public Notificacao(int ID, int UsuarioID, int FuncionarioID, String PublicacaoISBN, String TipoNotificacao, LocalDate DataNotificacao) {
        this.ID.set(ID);
        this.UsuarioID.set(UsuarioID);
        this.FuncionarioID.set(FuncionarioID);
        this.PublicacaoISBN.set(PublicacaoISBN);
        this.TipoNotificacao.set(TipoNotificacao);
        this.DataNotificacao.set(DataNotificacao);
    }

    public Notificacao() {

    }

    public int getID() {
        return ID.get();
    }

    public void setID(int ID) {
        this.ID.set(ID);
    }

    public IntegerProperty IDProperty() {
        return ID;
    }

    public int getUsuarioID() {
        return UsuarioID.get();
    }

    public void setUsuarioID(int UsuarioID) {
        this.UsuarioID.set(UsuarioID);
    }

    public IntegerProperty UsuarioIDProperty() {
        return UsuarioID;
    }

    public int getFuncionarioID() {
        return FuncionarioID.get();
    }

    public void setFuncionarioID(int FuncionarioID) {
        this.FuncionarioID.set(FuncionarioID);
    }

    public IntegerProperty FuncionarioIDProperty() {
        return FuncionarioID;
    }

    public String getPublicacaoISBN() {
        return PublicacaoISBN.get();
    }

    public void setPublicacaoISBN(String PublicacaoISBN) {
        this.PublicacaoISBN.set(PublicacaoISBN);
    }

    public StringProperty PublicacaoISBNProperty() {
        return PublicacaoISBN;
    }

    public String getTipoNotificacao() {
        return TipoNotificacao.get();
    }

    public void setTipoNotificacao(String TipoNotificacao) {
        this.TipoNotificacao.set(TipoNotificacao);
    }

    public StringProperty TipoNotificacaoProperty() {
        return TipoNotificacao;
    }

    public LocalDate getDataNotificacao() {
        return DataNotificacao.get();
    }

    public void setDataNotificacao(LocalDate DataNotificacao) {
        this.DataNotificacao.set(DataNotificacao);
    }

    public ObjectProperty<LocalDate> DataNotificacaoProperty() {
        return DataNotificacao;
    }

}
