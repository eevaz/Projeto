/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.modelo;

import java.time.LocalDate;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author user
 */
public class Devolucao {

    private final IntegerProperty ID = new SimpleIntegerProperty(this, "ID");
    private final IntegerProperty EmprestimoID = new SimpleIntegerProperty(this, "EmprestimoID");
    private final ObjectProperty<LocalDate>  DataDevolucao = new SimpleObjectProperty<>(this,"DataDevolucao");

    public Devolucao( int ID,int EmprestimoID, LocalDate DataDevolucao) {
        this.ID.set(ID);
        this.EmprestimoID.set(EmprestimoID);
        this.DataDevolucao.set(DataDevolucao);
    }
    
    public Devolucao(){
    }
    

   
    public int getID() {
        return ID.get();
    }

    public void setID(int ID) {
        this.ID.set(ID);
    }

 public IntegerProperty IDProperty(){
        return ID;
 }
        
    public int getEmprestimoID() {
        return EmprestimoID.get();
    }

    public void setEmprestimoID(int EmprestimoID) {
        this.EmprestimoID.set(EmprestimoID);
    }

 public IntegerProperty EmprestimoIDProperty(){
        return EmprestimoID;
    }
    public LocalDate getDataDevolucao() {
        return DataDevolucao.get();
    }

    public void setDataDevolucao(LocalDate DataDevolucao) {
        this.DataDevolucao.set(DataDevolucao);
    }
    
    public ObjectProperty<LocalDate> DataDevolucaoProperty(){
        return DataDevolucao;
    }
    
}
