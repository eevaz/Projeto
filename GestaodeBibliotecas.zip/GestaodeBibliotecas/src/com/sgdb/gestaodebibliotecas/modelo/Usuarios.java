/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */
package com.sgdb.gestaodebibliotecas.modelo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleSetProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author user
 */
public abstract class Usuarios {

    private final IntegerProperty UsuarioID = new SimpleIntegerProperty(this, "UsuarioID", 0);
    private final StringProperty Nome = new SimpleStringProperty(this, "Nome");
    private final StringProperty Email = new SimpleStringProperty(this, "Email");
    private final StringProperty Telefone = new SimpleStringProperty(this, "Telefone");
    private final StringProperty Morada = new SimpleStringProperty(this, "Morada");
    private final IntegerProperty CNI = new SimpleIntegerProperty(this, "CNI",0);
    private final StringProperty TipoUsuario = new SimpleStringProperty(this, "TipoUsuario");

    public Usuarios (int UsuarioID, String Nome, String Email, String Telefone, String Morada, int CNI, String TipoUsuario) {
        this.UsuarioID.set(UsuarioID);
        this.Nome.set(Nome);
        this.Email.set(Email);
        this.Telefone.set(Telefone);
        this.Morada.set(Morada);
        this.CNI.set(CNI);
        this.TipoUsuario.set(TipoUsuario);
    }

    public Usuarios () {
    }

    public int getUsuarioID() {
        return UsuarioID.get();
    }

    public void setUsuarioID(int UsuarioID) {
        this.UsuarioID.set(UsuarioID);
    }

    public final IntegerProperty UsuarioIDProperty() {
        return UsuarioID;
    }

//-------------------------------------------
 
    public String getNome() {
        return Nome.get();
    }

    public void setNome(String Nome) {
        this.Nome.set(Nome);
    }

    public final StringProperty NomeProperty() {
        return Nome;
    }

//-------------------------------------------
    public String getEmail() {
        return Email.get();
    }

    public void setEmail(String Email) {
        this.Email.set(Email);
    }

    public final StringProperty EmailProperty() {
        return Email;
    }

//-------------------------------------------
    public String getTelefone() {
        return Telefone.get();
    }

    public void setTelefone(String Telefone) {
        this.Telefone.set(Telefone);
    }

    public final StringProperty TelefoneProperty() {
        return Telefone;
    }
//-------------------------------------------

    public String getMorada() {
        return Morada.get();
    }

    public void setMorada(String Morada) {
        this.Morada.set(Morada);
    }

    public final StringProperty MoradaProperty() {
        return Morada;
    }
//-------------------------------------------

    public int getCNI() {
        return CNI.get();
    }

    public void setCNI(int CNI) {
        this.CNI.set(CNI);
    }

    public final IntegerProperty CNIProperty() {
        return CNI;
    }
//-------------------------------------------

   public String getTipoUsuario() {
        return TipoUsuario.get();
    }

    public void setTipoUsuario(String TipoUsuario) {
        this.TipoUsuario.set(TipoUsuario);
    }

    public final StringProperty TipoUsuarioProperty() {
        return TipoUsuario;
    }

//-------------------------------------------
    }