
package com.sgdb.gestaodebibliotecas.modelo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author user
 */
public class Funcionario {
    
    private final IntegerProperty ID = new SimpleIntegerProperty(this, "ID",0);
    private final StringProperty Nome = new SimpleStringProperty(this, "Nome");
    private final StringProperty Cargo = new SimpleStringProperty(this, "Cargo");
   

    public Funcionario(int ID, String Nome, String Cargo) {
         this.ID.set(ID);
        this.Nome.set(Nome);
        this.Cargo.set(Cargo);
       
    }

     public Funcionario() {
    }

    public int getID() {
        return ID.get();
    }

    public void setID(int ID) {
        this.ID.set(ID);
    }

    public final IntegerProperty IDProperty() {
        return ID;
    }

    
//-----------------------------------------
    public String getNome() {
        return Nome.get();
    }

    public void setNome(String Nome) {
        this.Nome.set(Nome);
    }

    public final StringProperty NomeProperty() {
        return Nome;
    }
    //-----------------------------------------
    
public String getCargo() {
        return Cargo.get();
    }

    public void setCargo(String Cargo) {
        this.Cargo.set(Cargo);
    }

    public final StringProperty CargoProperty() {
        return Cargo;
    }

    
    
}
