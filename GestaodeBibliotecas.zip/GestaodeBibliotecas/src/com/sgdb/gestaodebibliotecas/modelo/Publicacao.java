/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.modelo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleSetProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author EDSON VAZ
 */
public class Publicacao {

    private final StringProperty ISBN = new SimpleStringProperty(this, "ISBN");
    private final StringProperty Tipo = new SimpleStringProperty(this, "Tipo");

    ;

    public Publicacao(String ISBN, String Tipo) {
        this.ISBN.set(ISBN);
        this.Tipo.set(Tipo);
    }

    public Publicacao() {
    }

    /**
     * @return the ISBN
     */
    public String getISBN() {
        return ISBN.get();
    }

    /**
     * @param ISBN the ISBN to set
     */
    public void setISBN(String ISBN) {
        this.ISBN.set(ISBN);
    }

    public StringProperty ISBNProperty() {
        return ISBN;
    }
//-------------------------------------------

    /**
     * @return the Tipo
     */
    public String getTipo() {
        return Tipo.get();
    }

    /**
     * @param Tipo the Tipo to set
     */
    public void setTipo(String Tipo) {
        this.Tipo.set(Tipo);
    }

    public StringProperty TipoProperty() {
        return Tipo;
    }
}
   
//-----------------------------------------
