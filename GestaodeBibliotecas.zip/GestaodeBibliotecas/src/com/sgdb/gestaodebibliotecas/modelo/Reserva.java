/*Disciplina: PROGRAMAÇÃO ORIENTADA A OBJETOS 
Projeto: Sistema_de Gestão_de_Bibliotecas 
Data de criação: 20-06-2023 
Data de modificação: 04-07-2023 
Versão:1.0
Autor(es): Faculdade de Ciências e Tecnologia 
Universidade de Cabo Verde */ 
package com.sgdb.gestaodebibliotecas.modelo;

import java.time.LocalDate;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author user
 */
public class Reserva {
    private final IntegerProperty ID = new SimpleIntegerProperty(this, "ID");
    private final IntegerProperty UsuarioID = new SimpleIntegerProperty(this, "UsuarioID");
    private final StringProperty PublicacaoISBN = new SimpleStringProperty(this, "PublicacaoISBN");
    private final ObjectProperty<LocalDate> DataReserva = new SimpleObjectProperty<>(this,"DataReserva");


    public Reserva(int ID, int UsuarioID, String PublicacaoISBN, LocalDate DataReserva) {
        this.ID.set(ID);
        this.UsuarioID.set(UsuarioID);
        this.PublicacaoISBN.set(PublicacaoISBN);
        this.DataReserva.set(DataReserva);
    }

    public Reserva() {
       
    }

    public int getID() {
        return ID.get();
    }

    public void setID(int ID) {
        this.ID.set(ID);
    }
    
    public IntegerProperty IDProperty(){
        return ID;
    }

    public int getUsuarioID() {
        return UsuarioID.get();
    }

    public void setUsuarioID(int UsuarioID) {
        this.UsuarioID.set(UsuarioID);
    }
    
    public IntegerProperty UsuarioIDProperty(){
        return UsuarioID;
    }

    public String getPublicacaoISBN() {
        return PublicacaoISBN.get();
    }

    public void setPublicacaoISBN(String PublicacaoISBN) {
        this.PublicacaoISBN.set(PublicacaoISBN);
    }
    
    public StringProperty PublicacaoISBNProperty(){
        return PublicacaoISBN;
    }

    public LocalDate getDataReserva() {
        return DataReserva.get();
    }

    public void setDataReserva(LocalDate DataReserva) {
        this.DataReserva.set(DataReserva);
    }
    
    public ObjectProperty<LocalDate> DataReservaProperty(){
        return DataReserva;
    }
    
}
