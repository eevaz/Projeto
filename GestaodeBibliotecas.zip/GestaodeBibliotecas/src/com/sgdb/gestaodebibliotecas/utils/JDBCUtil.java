/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sgdb.gestaodebibliotecas.utils;
import java.sql.*;
import java.util.Properties;

public class JDBCUtil {

    public static Connection getConnection() throws SQLException {

        //jdbc:sqlserver://[serverName[\instanceName][:portNumber]][;property=value[;property=value]]
//        String url = "jdbc:sqlserver://localhost\\SQLEXPRESS:1433";

        String host = "localhost";
        String port = "1433";
        String dbms = "sqlserver";
        Properties connProps = new Properties();
        connProps.put("DataBase", "SGDB");
        connProps.put("user", "sa");
        connProps.put("password", "6910");
        connProps.put("encrypt", "true");
        connProps.put("trustServerCertificate", "true");
         String url = String.format("jdbc:%1$s://%2$s:%3$s",
                dbms, host, port);
        Connection conn = DriverManager.getConnection(url, connProps);
        conn.setAutoCommit(false);
        return conn;
    }

    public static void commit(Connection conn) throws SQLException {

        if (conn != null) {
            conn.commit();
        }

    }

    public static void rollback(Connection conn) throws SQLException {

        if (conn != null) {
            conn.rollback();
        }
    }
}